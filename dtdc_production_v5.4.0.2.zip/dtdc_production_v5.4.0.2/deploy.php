<?php
$cmd = 'git pull';
if exec($cmd, $out){
  print_r ($out);
}else{
  echo 'failed';
}
?>
