<?php

$mysqli = new mysqli('localhost','root','root','dtdc_ctbs_plus');

if($mysqli->connect_errno){
  die('Failed to connect');
}else{
  $select_imei = "select imei from dtdc_d_smart_warrior_imei where device_type ='MOP'";
  $result_imei = $mysqli->query($select_imei);
  $imeis = array();
  if($result_imei->num_rows > 0){
    for ($i=0; $i < $result_imei->num_rows; $i++) {
      $row = $result_imei->fetch_assoc();
      $imeis[$i] = $row['imei'];
    }
  }

  foreach ($imeis as $key => $value) {
    $imei = $value;
    $query = "update dtdc_d_smart_warrior_imei set status = 0 where imei = '$imei'";
    $result = $mysqli->query($query);
    if($result){
      echo "Success";
    }else{
      echo "query failed";
    }
  }


}
