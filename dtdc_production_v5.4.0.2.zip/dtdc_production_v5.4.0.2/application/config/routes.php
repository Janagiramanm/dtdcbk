<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'welcome';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

//No changes in master data.
$route['login'] = "User/login";
$route['validate-imei'] = "User/validateImei";
$route['masterdata'] = "user/masterdata";
$route['masterdatasync'] = "user/masterdatasync";
$route['masterdatacoloader'] = "user/masterdatacoloader";
$route['masterdatatrnstime'] = "user/masterdatatrnstime";
$route['masterdataroute'] = "user/masterdataroute";
$route['masterdataotcmaster'] = "user/masterdataotcmaster";
$route['masterdatadirectconnection'] = "user/masterdatadirectconnection";
$route['masterdatastatuscode'] = "user/masterdatastatuscode";
$route['serverdateandtime'] = "user/serverdateandtime";
$route['savestatuscode'] = 'user/savestatuscode';
$route['masterdatacommodity'] = 'user/masterdatacommodity';
$route['masterdatavas'] = 'user/masterdatavas';
$route['masterdataservicemoderelation'] = 'user/masterdataservicemoderelation';

$route['devicestatus'] = "user/devicestatus";

//Incoming
$route['savemastercon'] = 'incoming/savemastercon';
$route['saveincomingbagmanifest'] = 'incoming/saveincomingbagmanifest';
$route['saveincomingpacketmanifest'] = 'incoming/saveincomingpacketmanifest';
$route['savebdm'] = 'incoming/savebdm';
$route['savefdm'] = 'incoming/savefdm';
$route['getWeightIncomingPacketManifest'] = 'incoming/getWeightIncomingPacketManifest';

//Sync has to be removed.
$route['syncmasterconreceive'] = 'sync/syncmasterconreceive';
$route['syncincomingbagmanifest'] = 'sync/syncincomingbagmanifest';
$route['incomingpacketmanifestautoinscan'] = 'incoming/incomingpacketmanifestautoinscan';

//Outgoing
$route['saveoutgoingbagmanifestfordox'] = 'outgoing/saveoutgoingbagmanifestfordox';
$route['saveoutgoingbagmanifestfornondox'] = 'outgoing/saveoutgoingbagmanifestfornondox';
$route['savemastercondispatch'] = 'outgoing/savemastercondispatch';
//Update needed.
$route['mastercondispatchchangescan'] = 'outgoing/mastercondispatchchangescan';
$route['mastercondispatchremovalscan'] = 'outgoing/mastercondispatchremovalscan';
$route['mastercondispatchupdatecdno'] = 'outgoing/mastercondispatchupdatecdno';
$route['mastercondispatchgetdocumentid'] = 'outgoing/mastercondispatchgetdocumentid';
$route['gettsroutemapping'] = 'outgoing/gettsroutemapping';
$route['outgoingbagmanifestsearch'] = 'outgoing/outgoingbagmanifestsearch';
$route['removalentity'] = 'outgoing/removalentity';
$route['getweightfordoxconsignment'] = 'outgoing/getweightfordoxconsignment';
$route['validatingsurelockpmfsticker'] = "outgoing/validatingsurelockpmfsticker";
$route['mastercondispatchvalidatecdno'] = "outgoing/mastercondispatchvalidatecdno";

//Service type
$route['servicetype'] = 'mastercondispatchservicetype/service_type';

//Autopacket manifest
$route['generateautopacketmanifest'] = 'Autopacketmanifest/generate';

//New development
$route['get_desc_goods'] = 'outgoing/get_desc_goods';
$route['get_dispatch_number'] = 'outgoing/get_dispatch_number';
$route['checkbagavailable'] = 'incoming/checkBagAvailable';
$route['get-delivery-status-before-manifest'] = 'incoming/getDeliveryStatusBeforeManifest';

//Booking 26/10/2017
$route['validate-awb-number'] = 'BookingController/validateAwbNumber';
$route['check-serviceable-pincode'] = 'BookingController/checkServiceablePincode';
$route['get-services'] = 'BookingController/getServices';
$route['get-dp-booking-risk-cover-with-maximum-invoice-value'] = 'BookingController/getDpBookingRiskCoverWithMaximumInvoiceValue';
$route['save-non-dox-booking'] = 'BookingController/saveNonDoxBooking';
$route['rlg-service-validation'] = 'BookingController/rlgServiceValidation';
$route['cod-serviceable-status-checking'] = 'BookingController/codServiceableStatusChecking';
$route['cod-serviceable-status-checking-pincode-id'] = 'BookingController/codServiceableStatusCheckingPincodeId';


//10/01/2018
$route['get-tat-for-product'] = 'BookingController/getTatForProduct';
$route['get-services-from-tat'] = 'BookingController/getServicesFromTat';
$route['get-services-for-cp'] = 'BookingController/getServicesForCp';

//2/02/2018
$route['get-pending-fdms'] = 'Incoming/getPendingFdms';
$route['handover-fdms'] = 'Incoming/handOverFdms';

//21/02/2018
$route['get-services-for-dp-or-cpdp'] = 'BookingController/getServicesForDpOrCpDp';

//05/03/2018
$route['get-service-for-e'] = 'BookingController/getServicesForE';
$route['get-cutoff-time-for-service'] = 'BookingController/getCutoffTimeForService';

//23/03/2018
$route['get-coloaders'] = 'outgoing/getCoLoaders';

//19/05/2018
$route['get-the-services-for-e-series-dp-booking'] = 'BookingController/getTheServicesForESeriesDPBooking';
$route['check-serviceability-of-pincode-for-e-series-dp-booking'] = 'BookingController/checkServiceabilityOfPincodeForESeriesDPBooking';

$route['apk_details'] = 'ApkController/apkDetails';
$route['logout'] = 'User/logout';

$route['get-in-scan-values'] = 'Incoming/getInScanValues';
$route['validate-surelock-number'] = 'Outgoing/validateSureLockNumber';
$route['manual-logout'] = 'User/manualLogout';

$route['is-session-active'] = 'ApkController/isSessionActive';
$route['get-weight-for-rto-consignments'] = 'outgoing/getTheWeightForRTOCN';

$route['get-manifest-number-received-status'] = 'incoming/getManifestNumberReceivedStatus';
$route['get-status-of-consignment'] = 'user/getStatusOfConsignment';

//17/08/2018
$route['check-branch-is-parcel-branch'] = 'Outgoing/checkBranchIsParcelBranch';
$route['get-ewb-flag'] = 'BookingController/getEwbFlag';

$route['get_consg_saved_status_in_ibm'] = 'Incoming/getConsgSavedStatusInIBM';
// 19/02/19

$route['get-direct-connection'] = 'Outgoing/getDirectConnection';
$route['get-the-otcs'] = 'Outgoing/getTheOtcs';

//01.03.19
$route['update-status-code-for-consignment'] = 'User/updateStatusCodeForConsignment';
//04.03.19
$route['get-loggedIn-office-reporting-branches'] = 'Incoming/getLoggedInOfficeReportingBranches';
$route['get-active-franchisees-of-branch'] = 'Incoming/getActivefranchiseesOfBranch';

//09.04.19
$route['get-consignment-stop-status'] = 'BookingController/getConsignmentStopStatus';

//10/04/19 Automate consolidated EWB number
$route['automate-consolidated-ewb-number'] = 'Outgoing/automateConsolidatedEwbNumber';
$route['check-automate-consolidated-ewb-number'] = 'Outgoing/checkAutomateConsolidatedEwbNumber';

// 15.04.2019
$route['save-dox-booking'] = 'BookingController/saveDoxBooking';

//23.04.19
$route['validate-consg-to-dmc'] = 'Incoming/validateConsgToDmc';
$route['get-booking-data-for-dmc-consg'] = 'Incoming/getBookingDataForDmcConsg';
$route['save-dmc'] = 'Incoming/saveDmc';
//24.04.19
$route['provide-rto-stock'] = 'Incoming/provideRtoStock';

//25/04/19
$route['check-operational-freedom-eligibility'] = 'BookingController/checkOperationalFreedomEligibility';
$route['save-operational-freedom'] = 'BookingController/saveOperationalFreedom';


$route['checkBagSaved'] = 'Incoming/checkBagSavedInIBM';

//15/05/19
$route['check-pincode-serviceability-in-delivery'] = 'Incoming/checkPincodeServiceabilityInDelivery';
$route['get-frachisee-wallet-balance'] = 'BookingController/getFrachiseeWalletBalance';

$route['get-rate'] = 'BookingController/getRate';

$route['deduct-franchisee-wallet-balance'] = 'BookingController/deductFranchiseeWalletBalance';

$route['get-booking-data'] = 'BookingController/getTheBookingDataForConsignment';

//30/09/2019
$route['check-set-rto'] = 'Incoming/checkSetRto';
$route['check-set-rto-attempt-type'] = 'Incoming/checkSetRtoAttemptType';

//30/10/2019
$route['hht-login-validate'] = 'User/hhtLoginValidation';

$route['check-spl-customer-data-central'] = 'BookingController/checkSplCustomerInCentral';

$route['check-operation-freedom-eligible-for-online-booking'] = 'BookingController/checkOperationFreedonOnlineBooking';

$route['save-dox-booking-cnc'] = 'BookingController/saveDoxBookingCNC';

$route['bag-manifest-validation-for-dox'] = "Outgoing/bagManifestValidationForDox";

$route['get-biker-details-for-bdm'] = "Incoming/getBikerDetailsForBDM";

$route['force_closer'] = 'BookingController/forceCloser';

$route['get-product-details'] ='User/getProductDetails';

$route['get-all-vehicles'] ='User/getAllVehicles';

$route['check-pincode-serviceability-in-delivery-fdm-tmp'] = 'Incoming/checkPincodeServiceabilityInDeliveryFdmTemp';

$route['validation-for-status-code'] ='User/validationForStatusCode';

$route['get-consignment-numbers'] ='User/getConsignmentNumbers';

$route['check-outgoing-data-central-ibm'] = 'Incoming/checkOutgoingDataCentralIBM';


$route['check-whether-cd-inscanned-or-not'] = 'Incoming/checkWetherCDInscannedORNot';

// 30-04-2020 
$route['masterdatacoloadersec'] = "user/masterdatacoloadersec";
$route['masterdatadirectconnectionsec'] = "user/masterdatadirectconnectionsec";
$route['masterdataotcmastersec'] = "user/masterdataotcmastersec";
$route['masterdatatrnstimesec'] = "user/masterdatatrnstimesec";
$route['masterdataroutesec'] = "user/masterdataroutesec";

// 04-05-2020
$route['master_data_for_mastercon_rec'] = "user/masterDataForMasterConRec";
$route['get_max_delivery_attempt'] = "User/getMaxDeliveryAttempt";

//29-05-2020
$route['savemasterconReceiveOfflineProcess'] = 'incoming/savemasterconReceiveOfflineProcess';
$route['send-email'] = 'incoming/testEmail';

//08-06-2020
$route['check_central_or_local'] = 'User/checkCentralOrLocal';
//08-07-2020
$route['get_manifest_number_for_incoming_packet_manifest'] = 'Incoming/getManifestNumberForIncomingPacketManifest';
$route['get_manifest_number_for_incoming_packet_manifest_central'] = 'Incoming/getManifestNumberForIncomingPacketManifestCentral';
//24-07-2020
$route['get-mode-id-for-mcd'] =  "outgoing/getModeIdForMCD";