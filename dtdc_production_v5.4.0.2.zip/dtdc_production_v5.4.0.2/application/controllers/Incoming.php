<?php
defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . 'libraries/REST_Controller.php';

class Incoming extends REST_Controller
{

    public $bookingModel;

    public function __construct()
    {
        parent::__construct();
        $this->load->model("Incoming_model");
        $this->load->model('Booking_model');
				$this->load->model("Support_model");
//        $this->load->model('Outgoing_model');
        $this->bookingModel = new Booking_model();
    }

    public function savemastercon_post()
    {
        $data = $this->post();
        $reply = $this->Incoming_model->savemastercon($data);
        $this->response($reply);
    }
    
    public function savemasterconReceiveOfflineProcess_post()
    {
        $data = $this->post();
        $reply = $this->Incoming_model->savemasterconReceiveOfflineProcess($data);
        $this->response($reply);
    }
    public function testEmail_post()
    {
        $data = $this->post();
        $reply = $this->Incoming_model->testEmail($data);
        $this->response($reply);
    }
    public function saveincomingbagmanifest_post()
    {
        $data = $this->post();
        $reply = $this->Incoming_model->saveincomingbagmanifest($data);
        $this->response($reply);
    }

    public function saveincomingpacketmanifest_post()
    {
        $data = $this->post();
        $reply = $this->Incoming_model->saveincomingpacketmanifest($data);
        $this->response($reply);
    }

    public function savebdm_post()
    {
        $data = $this->post();
        $reply = $this->Incoming_model->savebdm($data);
        $this->response($reply);
    }

    public function savefdm_post()
    {
        $data = $this->post();
        $reply = $this->Incoming_model->savefdm($data);
        $this->response($reply);
    }

    public function incomingpacketmanifestautoinscan_post()
    {
        $data = $this->post();
        $reply = $this->Incoming_model->incomingpacketmanifestautoinscan($data);
        $this->response($reply);
    }

    public function getManifestNumberForIncomingPacketManifest_post()
    {
        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $consg_number = isset($input_data['consg_number']) ? $input_data['consg_number'] : $this->error_response('consg_number is required');
        $dest_branch_id = isset($input_data['dest_branch_id']) ? $input_data['dest_branch_id'] : $this->error_response('dest_branch_id is required');
        $office_code = isset($input_data['office_code']) ? $input_data['office_code'] : $this->error_response('office_code is required');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $inscan_values = $this->Incoming_model->getManifestNumForPacketManifest($consg_number, $dest_branch_id, $office_code);
        // $inscan_values = $this->Incoming_model->getInScanValues($consg_number, $dest_branch_id, $office_code);

        $response = ['status' => 1,  'inscan_values' => $inscan_values ];

        $this->set_response($response, 200);

    }
    public function getManifestNumberForIncomingPacketManifestCentral_post()
    {
        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $consg_number = isset($input_data['consg_number']) ? $input_data['consg_number'] : $this->error_response('consg_number is required');
        $dest_branch_id = isset($input_data['dest_branch_id']) ? $input_data['dest_branch_id'] : $this->error_response('dest_branch_id is required');
        $office_code = isset($input_data['office_code']) ? $input_data['office_code'] : $this->error_response('office_code is required');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $inscan_values = $this->Incoming_model->getManifestNumForPacketManifestCentral($consg_number);
        // $inscan_values = $this->Incoming_model->getInScanValues($consg_number, $dest_branch_id, $office_code);

        $response = ['status' => 1,  'inscan_values' => $inscan_values ];

        $this->set_response($response, 200);

    }

    public function getWeightIncomingPacketManifest_post()
    {
        $data = $this->post();
        $reply = $this->Incoming_model->getWeightIncomingPacketManifest($data);
        $this->response($reply);
    }

    public function checkBagAvailable_post()
    {

        $bag_number = $this->post('BagNum');
        $logged_in_office_id = $this->post('LoggedOfficeId');
        $local_db_ip = $this->post('local_db_ip');
        $node_id = $this->post('nodeId');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
         $isBagAvail = false;
        // if(strlen($bag_number) === 8){
        //    $isBagAvail = $this->Incoming_model->toCheckIsBagAvail($bag_number);
        //    if($isBagAvail){
        //         // $response = array('status' => 0, 'message' => 'Bag data is not available');
        //         // return $this->set_response($response, REST_Controller::HTTP_OK)
        //         $result =    $this->Incoming_model->toCheckBagOrPacket($bag_number);
        //         if(!$result){
        //              $response = array('status' => 0, 'message' => 'Packet Manifest is not allowed, Please scan Bag Manifest or AWB No');
        //              return $this->set_response($response, REST_Controller::HTTP_OK);
        //         }
        //     }
        // }

        if ($this->Incoming_model->isBagAvailable($bag_number, $logged_in_office_id, $node_id)) {

            //Already exists

            $response = array('status' => 0, 'message' => 'Already exist');

            $this->set_response($response, REST_Controller::HTTP_CONFLICT);

        } else {

            //Does not exist

            if(($node_id != 'MOPA') && ($this->bookingModel->getBookingIdFromConsgNumber($bag_number)) ) {
                $response = array('status' => 0, 'message' => 'The Mother consignment is not allowed to process further. Please scan child consignments"');
                $this->set_response($response, REST_Controller::HTTP_OK);
            }

            $bag_weight = false;
            $outgoing_status = false;
            $ewb_status = false;

            if (((strlen($bag_number) === 9) || (strlen($bag_number) === 12)) && ($node_id === 'MOP')) {
                $bag_weight = $this->Incoming_model->getBookingWeight($bag_number);
                $outgoing_status = $this->Incoming_model->getOutboundRecordStatusOfConsignment($bag_number, $logged_in_office_id) ? true : false;
             
                // $bag_number_start = substr($bag_number,0,2);
                // if($bag_number_start == 'I3' || $bag_number_start == '70' ){
                //     $ewb_status = $this->Incoming_model->checkConsignIsEway($bag_number);
                // }else{
                //     $bagNumber_nine = substr($bag_number,0,9);
                //     $ewb_status = $this->Incoming_model->checkConsignIsEway($bagNumber_nine);
                // }
            }

            // if (((strlen($bag_number) === 8) && ($node_id === 'MOP'))) {
            //     $ewb_status = $this->Incoming_model->checkWvcFlagForManifestNumber($bag_number);
            // }

            $response = array('status' => 1, 'message' => 'Does not exist', 'bag_weight' => $bag_weight, 'outgoing_status' => $outgoing_status, 'ewb_status' => $ewb_status, 'bag_status' => $isBagAvail);

            $this->set_response($response, REST_Controller::HTTP_OK);
        }

    }

    public function getDeliveryStatusBeforeManifest_post()
    {
        $input_data = $this->post();

        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $consignment_number = isset($input_data['consgNum']) ? $input_data['consgNum'] : $this->error_response('consgNum is required');
        $logged_in_office_id = isset($input_data['loggedInOfficeId']) ? $input_data['loggedInOfficeId'] : $this->error_response('loggedInOfficeId is required');
        $selected_office_id = isset($input_data['selectedOfficeId']) ? $input_data['selectedOfficeId'] : $this->error_response('selectedOfficeId is required');
        $max_delivery_attempts = isset($input_data['max_delivery_attempts']) ? $input_data['max_delivery_attempts'] : $this->error_response('max_delivery_attempts is required');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }


        if($this->Incoming_model->getDeliveryStatusBeforeManifest($consignment_number)){
            $response = array(
                'status' => 0,
                'message' => 'This consignment already saved to deliver',
            );

            $this->set_response($response, REST_Controller::HTTP_OK);
            return;

        }

        if( $this->Incoming_model->getDeliveredStatus($consignment_number)) {
            $response = array(
                'status' => 0,
                'message' => "Shipment is Already delivered",
            );

            $this->set_response($response, REST_Controller::HTTP_OK);
            return;
        }


        $bookingModel = new Booking_model();
        if($bookingModel->getBookingIdFromConsgNumber($consignment_number)){
            $response = array(
                'status' => 0,
                'message' => "The Mother consignment is not allowed to process further. Please scan child consignments"
            );

            $this->set_response($response, REST_Controller::HTTP_OK);
            return;
        }

        if($this->Incoming_model->checkNumberOfAttempts($consignment_number,$max_delivery_attempts)){
            $response = array(
                'status' => 0,
                'message' => "Maximum Number of Delivery attempts reached",
            );

            $this->set_response($response, REST_Controller::HTTP_OK);
            return;
        }



        if ($this->Incoming_model->getEwbStatusForDelivery($consignment_number, $logged_in_office_id)) {
            $response = array(
                'status' => 0,
                'message' => "This Eway Bill shipment pending for confirmation",
            );

            $this->set_response($response, REST_Controller::HTTP_OK);
            return;
        }

        $outgoingModel = new Outgoing_model();

        if($outgoingModel->getDmcIdFromDmcTable($consignment_number)) {
            $response = array(
                'status' => 0,
                'message' => "Please scan RTO Consignment",
            );

            $this->set_response($response, REST_Controller::HTTP_OK);
            return;
        }


        $bagAvailableStatusValues = $this->Incoming_model->getBagAvailableStatus($logged_in_office_id, $consignment_number);

        if(count($bagAvailableStatusValues) === 0) {

					if($this->Support_model->checkBookingDataIsAvailableForOPF($consignment_number)) {
						$response = array(
			        'status' => 0,
			        'message' => "The shipment details not found in neither Manifest nor Booking",
		        );
					} else {
						$response = array(
			        'status' => 0,
			        'message' => "Do OPF. The shipment details not found in neither Manifest nor Booking",
		        );
					}

            $this->set_response($response, REST_Controller::HTTP_OK);
            return;
        }

				$pincodeDetails = $this->Incoming_model->getThePincodeDetails($consignment_number, $selected_office_id);
				$consignment_numbers_association =  $this->Incoming_model->getAllTheConsignmentNumbersAssociated($consignment_number);

        $consg_number_start = substr($consignment_number,0,2);

        if($consg_number_start == 'I3' || $consg_number_start == '70' ){
            $ewb_status = $this->Incoming_model->checkConsignIsEway($consignment_number);
        }else{
            $consgNumber_nine = substr($consignment_number,0,9);
            $ewb_status = $this->Incoming_model->checkConsignIsEway($consgNumber_nine);
        }

	    	$response = array(
                'status' => 1,
                'message' => 'All validations passed',
                'weight' => $bagAvailableStatusValues[0]['PHY_WEIGHT'],
								'consignment_numbers_association' => $consignment_numbers_association,
								'pincode' => $pincodeDetails,
                                'ewb_status' => $ewb_status
            );

        $this->set_response($response, REST_Controller::HTTP_OK);

    }

    public function error_response($e)
    {
        $response = array('status' => 0, 'message' => $e);
        echo json_encode($response);
        exit;
    }

    public function getPendingFdms_post()
    {
        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $franchisee_code = isset($input_data['franchiseeCode']) ? $input_data['franchiseeCode'] : $this->error_response('franchiseeCode is required');


        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
        if ($this->Incoming_model->getFranchiseeAdmStatus($franchisee_code)) {
            $response = array('status' => 0, 'message' => 'FDM handover is not allowed for ADM codes');
        } else {
            $pending_fdms = $this->Incoming_model->getPendingFdms($franchisee_code);
            $response = array('status' => 1, 'fdms' => $pending_fdms);
        }

        $this->set_response($response, 200);

    }

    public function handOverFdms_post()
    {

        $updated_fdms = [];

        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $loginUserId = isset($input_data['login_user_id']) ? $input_data['login_user_id'] : $this->error_response('login_user_id is required');
        $franchisee_code = isset($input_data['franchiseeCode']) ? $input_data['franchiseeCode'] : $this->error_response('franchiseeCode is required');
        $fdms = isset($input_data['fdms']) ? $input_data['fdms'] : $this->error_response('fdms is required');

       

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        

        for ($i = 0; $i < count($fdms); $i++) {

            $franchiseeId = $this->Incoming_model->getFranchiseeId($franchisee_code);
            $dateObj = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $handover_num = $franchiseeId.($dateObj->format('dmyHis')+$i);

            if ($this->Incoming_model->handOverFdm($handover_num, $franchisee_code, $fdms[$i], $loginUserId )) {
                array_push($updated_fdms, [
                    [
                        "fdm" => $fdms[$i],
                        "status" => 'Updated'
                    ]
                ]);
            } else {
                array_push($updated_fdms, [
                    [
                        "fdm" => $fdms[$i],
                        "status" => 'Not Updated'
                    ]
                ]);
            }
        }

        $response = ['status' => 1, 'fdms_status' => $updated_fdms];

        $this->set_response($response, 200);
    }

    public function getInScanValues_post()
    {
        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $consg_number = isset($input_data['consg_number']) ? $input_data['consg_number'] : $this->error_response('consg_number is required');
        $dest_branch_id = isset($input_data['dest_branch_id']) ? $input_data['dest_branch_id'] : $this->error_response('dest_branch_id is required');
        $office_code = isset($input_data['office_code']) ? $input_data['office_code'] : $this->error_response('office_code is required');
        $manifest_number =isset($input_data['manifest_number']) ? $input_data['manifest_number'] :null; 

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $inscan_values = $this->Incoming_model->getInScanValues($consg_number, $dest_branch_id, $office_code, $manifest_number);

        $response = ['status' => 1,  'inscan_values' => $inscan_values ];

        $this->set_response($response, 200);

    }

    public function getManifestNumberReceivedStatus_post()
    {
        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $consg_number = isset($input_data['consg_number']) ? $input_data['consg_number'] : $this->error_response('consg_number is required');
        $dest_branch_id = isset($input_data['dest_branch_id']) ? $input_data['dest_branch_id'] : $this->error_response('dest_branch_id is required');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $manifestReceivedStatus = $this->Incoming_model->getManifestNumberReceivedStatus($consg_number, $dest_branch_id);
        $manifestSavedStatus = $this->Incoming_model->getManifestNumberSavedStatus($consg_number, $dest_branch_id);
        $response = [
            'manifestReceivedStatus' => $manifestReceivedStatus,
            'manifestSavedStatus' => $manifestSavedStatus
        ];
        $this->set_response($response, 200);
    }

    public function getConsgSavedStatusInIBM_post()
    {
        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $consg_number = isset($input_data['consg_number']) ? $input_data['consg_number'] : $this->error_response('consg_number is required');
        $dest_branch_id = isset($input_data['dest_branch_id']) ? $input_data['dest_branch_id'] : $this->error_response('dest_branch_id is required');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $manifestReceivedStatus = $this->Incoming_model->getConsgSavedStatusInIBM($consg_number, $dest_branch_id);
				if($manifestReceivedStatus) {
					$response = [
	            'status' => 0,
							'message' => 'This Manifest number is already saved'
	        ];
					$this->set_response($response, 200);
					return;
				}

                $isRecord = $this->Incoming_model->checkOutgoingRecordExistsOrNot($consg_number);
                if($isRecord){
                    $allow_manifest_type = [3,4,8];
                    $manifest_type_id = null;
                    foreach($isRecord as $key => $value){
                        if($value['MANIFEST_NUMBER'] == $consg_number){
                            $manifest_type_id = $value['mnfst_type_id'];
                        } 
                    }
                   if(!in_array($manifest_type_id,$allow_manifest_type)){
                   
                    $response = [ 
                        'status' => 0,
                        'message' => 'Please scan the dox packet.'
                    ];
                    $this->set_response($response, 200);
                    return;
                   }
                }else{
                    $response = [ 
                        'status' => 2,
                        'message' => 'Please check central data.'
                    ];
                    $this->set_response($response, 200);
                    return;

                }

				$manifestInscanStatus = $this->Incoming_model->getBagReceivedOrNot($consg_number, $dest_branch_id);
				if(!$manifestInscanStatus) {

                    $manifest_number = $this->Incoming_model->getManifestNumberForConsgNumber($consg_number,$dest_branch_id);

					$response = [ 
							'status' => 0,
							'message' => 'This Manifest number '.$manifest_number.' details not found. Please do CD receive.'
					];
					$this->set_response($response, 200);
					return;
				}

				$response = [
						'status' => 1,
						'message' => 'Allow this Manifest number'
				];
				$this->set_response($response, 200);
				return;

    }

    public function getLoggedInOfficeReportingBranches_post()
    {
        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $logged_in_office_id = isset($input_data['loggedInOfficeId']) ? $input_data['loggedInOfficeId'] : $this->error_response('loggedInOfficeId is required');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $offices = $this->Incoming_model->getLoggedInOfficeReportingBranches($logged_in_office_id);
        $response = ['status' => 1, 'offices' => $offices];

        $this->set_response($response, 200);
    }

    public function getActivefranchiseesOfBranch_post()
    {
        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $office_id = isset($input_data['officeId']) ? $input_data['officeId'] : $this->error_response('officeId is required');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $franchisees = $this->Incoming_model->getActivefranchiseesOfBranch($office_id);
        $freedonFranchisees =  $this->Incoming_model->getFreedomFranchisees();
        $response = ['status' => 1, 'franchisees' => $franchisees, 'freedomFranchisee' => $freedonFranchisees];
        $this->set_response($response, 200);
    }

    public function validateConsgToDmc_post()
    {
        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $office_id = isset($input_data['officeId']) ? $input_data['officeId'] : $this->error_response('officeId is required');
        $consg_number = isset($input_data['consignmentNumber']) ? $input_data['consignmentNumber'] : $this->error_response('consignmentNumber is required');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
        if ($this->Incoming_model->isConsgNumberisSavedInDmc($consg_number, $office_id)) {
            $response = ['status' => 0, 'message' => 'DMC Validation is Already done for this consignment.'];
            $this->set_response($response, 200);
            return;
        }

        $bookingModel = new Booking_model();
        if($bookingModel->getBookingIdFromConsgNumber($consg_number)){
            $response = ['status' => 0, "message"=> 'The Mother consignment is not allowed to process further. Please scan child consignments'];
            $this->set_response($response, 200);
            return;
        }

        $result = $this->Incoming_model->getDeliveryStatusOfConsgForDmc($consg_number, $office_id);
        if (empty($result)) {
            $response = ['status' => 0, 'message' => 'No Active Non Delivery record found.Cannot Proceed for DMC Validation.'];
            $this->set_response($response, 200);
            return;
        }
        $reason = $this->Incoming_model->getReasonFromId($result['REASON_ID']);
        $franchise = $this->Incoming_model->getFranchiseFromId($result['FRANCHISEE_ID']);
        $employee = $this->Incoming_model->getEmployeeFromId($result['EMPLOYEE_ID']);
        $attemptsCount = $this->Incoming_model->getNumberOfAttemptsCount($consg_number, $office_id);
        $response = ['status' => 1,
            'franchise' => $franchise,
            'employee' => $employee,
            'reason' => $reason,
            'attempts_count' => $attemptsCount
        ];
        $this->set_response($response, 200);
    }

    public function getBookingDataForDmcConsg_post()
    {
        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $consg_number = isset($input_data['consignmentNumber']) ? $input_data['consignmentNumber'] : $this->error_response('consignmentNumber is required');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $result = $this->Incoming_model->getBookingDataForDmcConsg($consg_number);
        if (is_null($result)) {
            $response = ['status' => 0, 'message' => 'No Booking Data Found!'];
            $this->set_response($response, 200);
            return;
        }
        $cpdpccc_data = $this->Incoming_model->getCpdpcccDetails($result);
        $commodity = $this->Incoming_model->getCommodityDetails($result['commodity_id']);
        $branch = $this->Incoming_model->getBranchDetails($result['brnch_off_id']);
        $pincode = $this->Incoming_model->getThePincodeFromBranchOfficeId($result['brnch_off_id']);
				$franchisee = $this->Incoming_model->getFranchiseFromId($result['franchisee_id']);
				$customer = $this->Incoming_model->getCustomerFromId($result['customer_id']);

        $response = ['status' => 1,
            'cpdpccc_data' => $cpdpccc_data,
            'commodity' => $commodity,
            'branch' => $branch,
						'franchisee' => $franchisee,
						'customer' => $customer,
            'pincode' => $pincode,
            'result' => $result
        ];
        $this->set_response($response, 200);
    }

    public function checkBagSavedInIBM_post(){
        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $consg_number = isset($input_data['consignmentNumber']) ? $input_data['consignmentNumber'] : $this->error_response('consignmentNumber is required');
        $loggedInOfficeId = isset($input_data['loggedInOfficeId']) ? $input_data['loggedInOfficeId'] : $this->error_response('loggedInOfficeId is required');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $result = $this->Incoming_model->checkBagSavedInIBM($consg_number,$loggedInOfficeId);
        if($result){
            $response = ['status' => 0,
                'message' => 'This Bag is saved before'
            ];
        } else {
            $response = ['status' => 1,
                'message' => 'This Bag is not saved before'
            ];
        }

        $this->set_response($response, 200);

    }


    public function saveDmc_post()
    {
        $input_data = $this->post();

        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');


        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $id = $this->Incoming_model->saveDmcData($input_data);

        $response = ['status' => 1, 'id' => $id, 'message' => 'Saved successfully'];

        $this->set_response($response, REST_Controller::HTTP_OK);
    }

    public function provideRtoStock_post(){
        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $branch_code = isset($input_data['branch_code']) ? $input_data['branch_code'] : $this->error_response('branch_code is required');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $result = $this->Incoming_model->getRtoStock($branch_code);
        if(empty($result)){
            $response = ['status' => 0, 'message' => 'Stock Not Found'];
            $this->set_response($response, REST_Controller::HTTP_OK);
            return;
        }

        $csc_id = $result['CSC_ID'];
        $start_number = $result['CSC_START_CNNO'];
        $end_number = $result['CSC_END_CNNO'];
        $stock_count = $result['CSC_STOCK'];

        $originalStock = $end_number - ($start_number - 1);

        $stock_tobe_returned = ($originalStock - $stock_count) + $start_number;

        $stock_to_be_sent = $stock_count-1;
        $this->Incoming_model->updateStock($csc_id,$stock_to_be_sent);

        $response = ['status' => 1, 'value' => $stock_tobe_returned, 'message' => 'Fetched Successfully'];

        $this->set_response($response, REST_Controller::HTTP_OK);
    }

		public function checkPincodeServiceabilityInDelivery_post() {

        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $pincode = isset($input_data['pincode']) ? $input_data['pincode'] : $this->error_response('pincode is required');
        $loggedInOfficeId = isset($input_data['loggedInOfficeId']) ? $input_data['loggedInOfficeId'] : $this->error_response('loggedInOfficeId is required');
        $loggedInOfficeCode = isset($input_data['loggedInOfficeCode']) ? $input_data['loggedInOfficeCode'] : $this->error_response('loggedInOfficeCode is required');
        $productCode = isset($input_data['productCode']) ? $input_data['productCode'] : "LITE";
        $isApex = isset($input_data['isApex']) ? $input_data['isApex'] : $this->error_response('isApex is required');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

            $result = $this->Incoming_model->checkPincodeServiceabilityInDelivery($isApex, $pincode, $loggedInOfficeId, $loggedInOfficeCode, $productCode);
            $this->set_response($result, REST_Controller::HTTP_OK);

        }
        
        public function checkPincodeServiceabilityInDeliveryFdmTemp_post() {

            $input_data = $this->post();
            $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
            $pincode = isset($input_data['pincode']) ? $input_data['pincode'] : $this->error_response('pincode is required');
            $loggedInOfficeId = isset($input_data['loggedInOfficeId']) ? $input_data['loggedInOfficeId'] : $this->error_response('loggedInOfficeId is required');
            $loggedInOfficeCode = isset($input_data['loggedInOfficeCode']) ? $input_data['loggedInOfficeCode'] : $this->error_response('loggedInOfficeCode is required');
            $productCode = isset($input_data['productCode']) ? $input_data['productCode'] : "LITE";
            $isApex = isset($input_data['isApex']) ? $input_data['isApex'] : $this->error_response('isApex is required');
    
            if ($local_db_ip != 'null') {
                $connect = new Connection_model();
                $connect->custom($local_db_ip);
            } else {
                $connect = new Connection_model();
                $connect->central();
            }
    
                $result = $this->Incoming_model->checkPincodeServiceabilityInDeliveryTemp($isApex, $pincode, $loggedInOfficeId, $loggedInOfficeCode, $productCode);
                $this->set_response($result, REST_Controller::HTTP_OK);
    
            }

		public function checkSetRto_post() {
            $input_data = $this->post();
            $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
            if ($local_db_ip != 'null') {
                $connect = new Connection_model();
                $connect->custom($local_db_ip);
            } else {
                $connect = new Connection_model();
                $connect->central();
            }
            $consgNumber = isset($input_data['consgNumber']) ? $input_data['consgNumber'] : $this->error_response('consgNumber is required');

            $weight = $this->Incoming_model->getCheckSetRtoWeight($consgNumber);
            if($weight >= 1) {
                $result = [
                    'status' => 0,
                    'message' => "This Consignment number belongs to SETRTO. we Cannot proceed this booking"
                ];
            } else {
                $result = [
                    'status' => 1,
                    'message' => "Allow booking"
                ];
            }

            $this->set_response($result, REST_Controller::HTTP_OK);
        }

        public function checkSetRtoAttemptType_post() {
            $input_data = $this->post();
            $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
            if ($local_db_ip != 'null') {
                $connect = new Connection_model();
                $connect->custom($local_db_ip);
            } else {
                $connect = new Connection_model();
                $connect->central();
            }
            $consgNumber = isset($input_data['consgNumber']) ? $input_data['consgNumber'] : $this->error_response('consgNumber is required');

            $consing_number_starting = array('V','E','X');
            $start_consign = substr($consgNumber, 0, 1);
            if(in_array($start_consign, $consing_number_starting)){
                $ecomCustomer = '';
            }else{
                $ecomCustomer = $this->Incoming_model->getEcomCustomer($consgNumber);
            }
            if($ecomCustomer === 'Y') {
                $data = $this->Incoming_model->checkSetRtoAttemptType($consgNumber);

                if($data) {
                    $result = [
                        'status' => 1,
                        'message' => 'Success',
                        'dmc_data' => $data,
                    ];
                } else {
                    $result = [
                        'status' => 0,
                        'message' => 'Ecom Customer status Y. But no data found',
                        'dmc_data' => $data,
                    ];
                }
            } 
            else if($ecomCustomer == 'N'){
                $result = [
                    'status' => 2,
                    'message' => 'Ecom Customer Status is N. But no data found',
                    'dmc_data' => false,
                ];
            }else {
                $result = [
                    'status' => 0,
                    'message' => 'Fail Empty',
                    'dmc_data' => false,
                ];
            }

            $this->set_response($result, REST_Controller::HTTP_OK);

        }

        // 10-02-2020
        // this is the new requirement to get active employee for BDM process
        public function getBikerDetailsForBDM_post(){
            $input_data = $this->post();
            $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
            if ($local_db_ip != 'null') {
                $connect = new Connection_model();
                $connect->custom($local_db_ip);
            } else {
                $connect = new Connection_model(); 
                $connect->central();
            }

            $loggedInOfficeId = $input_data['logged_in_off_id'] ? $input_data['logged_in_off_id'] : $this->error_response('logged in office ID is required');
            $result  = $this->Incoming_model->getBikerDetailsForBDM($loggedInOfficeId);
            $this->set_response($result, REST_Controller::HTTP_OK);

        }

        public function checkOutgoingDataCentralIBM_post(){

            $input_data = $this->post();
            $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
            $consg_number = isset($input_data['consignmentNumber']) ? $input_data['consignmentNumber'] : $this->error_response('consignmentNumber is required');
     
            if ($local_db_ip != 'null') {
                $connect = new Connection_model();
                $connect->custom($local_db_ip);
            } else {
                $connect = new Connection_model(); 
                $connect->central();
            }

            $result  = $this->Incoming_model->checkOutgoingDataCentralIBM($consg_number);
            $allow_manifest_type = [3,4,8];
            if(!$result){
                $response = [ 
                    'status' => 0,
                    'message' => 'No outgoing data found.'
                ];
                $this->set_response($response, 200);
                return;
            }
            $manifest_type_id = null;
            foreach($result as $key => $value){
                if($value['MANIFEST_NUMBER'] == $consg_number){
                    $manifest_type_id = $value['mnfst_type_id'];
                } 
            }
                
            if(!in_array($manifest_type_id,$allow_manifest_type)){
            // if(!in_array($result[0]['mnfst_type_id'],$allow_manifest_type)){
            
                $response = [ 
                    'status' => 0,
                    'message' => 'Please scan dox packet.'
                ];
                $this->set_response($response, 200);
                return;
            }

            $response = [ 
                'status' => 1,
                'message' => 'Proceed Further.'
            ];
            $this->set_response($response, 200);
            return;

        }

        public function checkWetherCDInscannedORNot_post(){

            $input_data = $this->post();
            $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
            $consg_number = isset($input_data['consg_number']) ? $input_data['consg_number'] : $this->error_response('consg_number is required');
            $dest_branch_id = isset($input_data['dest_branch_id']) ? $input_data['dest_branch_id'] : $this->error_response('dest_branch_id is required');
    
            if ($local_db_ip != 'null') {
                $connect = new Connection_model();
                $connect->custom($local_db_ip);
            } else {
                $connect = new Connection_model(); 
                $connect->central();
            }

            $manifestInscanStatus = $this->Incoming_model->getBagReceivedOrNot($consg_number, $dest_branch_id);
            if(!$manifestInscanStatus) {

                $manifest_number = $this->Incoming_model->getManifestNumberForConsgNumber($consg_number,$dest_branch_id);

                $response = [ 
                        'status' => 0,
                        'message' => 'This Manifest number '.$manifest_number.' details not found. Please do CD receive.'
                ];
                $this->set_response($response, 200);
                return;
            }

            $response = [
                    'status' => 1,
                    'message' => 'Allow this Manifest number'
            ];
            $this->set_response($response, 200);
            return;

        }

}
