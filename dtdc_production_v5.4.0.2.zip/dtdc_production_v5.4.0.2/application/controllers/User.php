<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require(APPPATH . 'libraries/REST_Controller.php');

class User extends REST_Controller
{

    protected $datetime;

    function __construct()
    {
        parent::__construct();
        $this->load->model("User_model");
        $this->load->model('Apk');
        $dateObj = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
        $this->datetime = $dateObj->format('Y-m-d H:i:s');
    }

    public function login_post()
    {
        $data = $this->post();
        $reply = $this->User_model->login($data);
        $this->response($reply);
    }


    public function validateImei_post() {

    	$imei = $this->post('imei');

	    $local_db_ip = $this->post('local_db_id');

	    if($local_db_ip === 'null') {
		    $connect = new Connection_model();
		    $connect->central();

		    $user = new User_model();

		    $imeiStatus = $user->validateImei($imei);

		    if($imeiStatus) {

		    	if($imeiStatus === 1){
				    return $this->set_response(['status' => 1,'message' => 'Registered device.'],REST_Controller::HTTP_OK);
			    } else {
				    return $this->set_response(['status' => 0,'message' => 'Deactivated device.'],REST_Controller::HTTP_OK);
			    }

		    } else {
			    return $this->set_response(['status' => 0,'message' => 'Unregistered device.'],REST_Controller::HTTP_OK);
		    }
	    } else {
		    return $this->set_response(['status' => 2,'message' => 'Connect to local. Cannot check IMEI.'],REST_Controller::HTTP_OK);
	    }

    }

    public function serverdateandtime_get()
    {
        $reply = array('status' => 1, 'datetime' => $this->datetime);
        $this->response($reply);
    }

    public function masterdata_post()
    {
        $data = $this->post();
        $reply = $this->User_model->masterdata($data);
        $this->response($reply);
    }

    public function masterdatasync_post()
    {
        $data = $this->post();
        $reply = $this->User_model->masterdatasync($data);
        $this->response($reply);
    }

    public function masterdatacoloader_post()
    {
        $data = $this->post();
        $reply = $this->User_model->masterdatacoloader($data);
        $this->response($reply);
    }

    public function masterdatatrnstime_post()
    {
        $data = $this->post();
        $reply = $this->User_model->masterdatatrnstime($data);
        $this->response($reply);
    }

    public function masterdataroute_post()
    {
        $data = $this->post();
        $reply = $this->User_model->masterdataroute($data);
        $this->response($reply);
    }

    public function masterdataotcmaster_post()
    {
        $data = $this->post();
        $reply = $this->User_model->masterdataotcmaster($data);
        $this->response($reply);
    }

    public function masterdatadirectconnection_post()
    {
        $data = $this->post();
        $reply = $this->User_model->masterdatadirectconnection($data);
        $this->response($reply);
    }

    public function masterdatastatuscode_post()
    {
        $data = $this->post();
        $reply = $this->User_model->masterdatastatuscode($data);
        $this->response($reply);
    }

    public function masterdatacommodity_post()
    {
        $data = $this->post();
        $reply = $this->User_model->masterdatacommodity($data);
        $this->response($reply);
    }

    public function masterdatavas_post()
    {
        $data = $this->post();
        $reply = $this->User_model->masterdatavas($data);
        $this->response($reply);
    }

    public function masterdataservicemoderelation_post(){
        $data = $this->post();
        $reply = $this->User_model->masterdataservicemoderelation($data);
        $this->response($reply);
    }

    public function savestatuscode_post()
    {
        $data = $this->post();
        $reply = $this->User_model->savestatuscode($data);
        $this->response($reply);
    }

    public function devicestatus_post()
    {
        $data = $this->post();
        $reply = $this->User_model->devicestatus($data);
        $this->response($reply);
    }

    public function logout_post()
    {
        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $log_in_out_id = isset($input_data['log_in_out_id']) ? $input_data['log_in_out_id'] : $this->error_response('log_in_out_id is required');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $user = new User_model();

        $logout_status = $user->logout($log_in_out_id);

        return $this->set_response(['logout_status' => $logout_status],REST_Controller::HTTP_OK);

    }

    public function manualLogout_post(){

	    $input_data = $this->post();
	    $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');

	    $username = isset($input_data['username']) ? $input_data['username'] : $this->error_response('username is required');
	    $password = isset($input_data['password']) ? $input_data['password'] : $this->error_response('password is required');

	    if ($local_db_ip != 'null') {
		    $connect = new Connection_model();
		    $connect->custom($local_db_ip);
	    } else {
		    $connect = new Connection_model();
		    $connect->central();
	    }

	    $user = new User_model();

	    $logout_status = $user->manualLogout($username, $password);

	    return $this->set_response(['status' => $logout_status],REST_Controller::HTTP_OK);
    }

    public function error_response($e)
    {
        $response = array('status' => 0, 'message' => $e);
        echo json_encode($response);
        exit;
    }

    public function getStatusOfConsignment_post()
    {
        $input_data = $this->post();

        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $consgNumber = isset($input_data['consgNumber']) ? $input_data['consgNumber'] : $this->error_response('consgNumber is required');
        $office_code = isset($input_data['office_code']) ? $input_data['office_code'] : $this->error_response('office_code is required');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $status = $this->User_model->getStatusOfConsignment($consgNumber,$office_code);
        $this->response($status);
    }

    public function updateStatusCodeForConsignment_post(){
        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $consignmentNumber = isset($input_data['consignmentNumber']) ? $input_data['consignmentNumber'] : $this->error_response('consignmentNumber is required');
        $officeCode = isset($input_data['officeCode']) ? $input_data['officeCode'] : $this->error_response('officeCode is required');
        $officeType = isset($input_data['officeType']) ? $input_data['officeType'] : $this->error_response('officeType is required');
        $userId = isset($input_data['userId']) ? $input_data['userId'] : $this->error_response('userId is required');
        $nodeId = isset($input_data['nodeId']) ? $input_data['nodeId'] : $this->error_response('nodeId is required');
        $result = $this->User_model->updateStatusCodeForConsignment($consignmentNumber, $officeCode, $userId, $nodeId, $officeType);
        return $this->set_response(['id' => $result],REST_Controller::HTTP_OK);
    }

    public function hhtLoginValidation_post(){
        $data = $this->post();
        $reply = $this->User_model->hhtLoginValidation($data);
        $this->response($reply);
    }

    public function getMaxDeliveryAttempt_post(){

        $input_data = $this->post(); 
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
        $user = new User_model();
        $response = $user->getMaxDeliveryAttempt();
        $this->response($response, 200);
    }

    public function getProductDetails_post(){
        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
        $user = new User_model();
        $response = $user->getProductDetails();
        $this->response($response, 200);
    }

    public function getAllVehicles_post(){
        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $user = new User_model();
        $response = $user->getAllVehicles();
        $this->response($response, 200);

    }

    public function validationForStatusCode_post(){

        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $consig_number = isset($input_data['consig_number']) ? $input_data['consig_number'] : $this->error_response('consignmentNumber is required');
        $destBranchId = isset($input_data['dest_branch_id']) ? $input_data['dest_branch_id'] : $this->error_response('destBranchId is required');
        $process_type = isset($input_data['process_type']) ? $input_data['process_type'] : $this->error_response('process_type is required');
        $process_name = isset($input_data['process_name']) ? $input_data['process_name'] : $this->error_response('process_name is required');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
        
        $booking_model = new Booking_model();
        switch($process_type){
            case 'Booking':
                $response = $booking_model->validate_booking($consig_number, $destBranchId);
            break;
            case 'Outgoing':
                $response = $booking_model->outgoing_manifest($consig_number, $destBranchId);
            break;
            case 'Incoming':
                $response = $booking_model->incoming_manifest($consig_number, $destBranchId);
            break;
            case 'CD Dispatch':
                $response = $booking_model->cd_dispatch_validate($consig_number, $destBranchId, $process_name);
            break;
            case 'CD Receive':
               $response =  $booking_model->cd_receive_validate($consig_number, $destBranchId, $process_name);
            break;
            case 'Delivery':
               $response =  $booking_model->delivery_validate($consig_number, $destBranchId, $process_name);
            break;
            default:

            $response = [
                'status' => 0,
                'message' => 'Not found'
            ];

            break;
        }
                
        $this->response($response, 200);

    }

    public function getConsignmentNumbers_post(){
        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $manifest_number = isset($input_data['manifest_number']) ? $input_data['manifest_number'] : $this->error_response('manifest_number is required');
        $manifest_type_id = isset($input_data['manifest_type_id']) ? $input_data['manifest_type_id'] : $this->error_response('manifest_type_id is required');
        $manifest_type = isset($input_data['manifest_type']) ? $input_data['manifest_type'] : $this->error_response('manifest_type is required');
        $destBranchId = isset($input_data['dest_branch_id']) ? $input_data['dest_branch_id'] : $this->error_response('destBranchId is required');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
        $booking_model = new Booking_model();
        $response = $booking_model->getConsignmentNumbers($manifest_number, $manifest_type_id, $manifest_type, $destBranchId);
        $this->response($response, 200);
    }

    //30-04-2020
    public function masterdatacoloadersec_post()
    {
        $data = $this->post();
        $reply = $this->User_model->masterdatacoloadersec($data);
        $this->response($reply);
    }

    public function masterdatadirectconnectionsec_post()
        {
            $data = $this->post();
            $reply = $this->User_model->masterdatadirectconnectionsec($data);
            $this->response($reply);
        }

    public function masterdataotcmastersec_post()
        {
            $data = $this->post();
            $reply = $this->User_model->masterdataotcmastersec($data);
            $this->response($reply);
        }

    public function masterdatatrnstimesec_post()
        {
            $data = $this->post();
            $reply = $this->User_model->masterdatatrnstimesec($data);
            $this->response($reply);
        }
    public function masterdataroutesec_post()
        {
            $data = $this->post();
            $reply = $this->User_model->masterdataroutesec($data);
            $this->response($reply);
        }

    // 04-05-2020
    public function masterDataForMasterConRec_post(){

        $data = $this->post();
        $response = $this->User_model->masterDataForMasterConRec($data);
        $this->response($response);
       
    }

    // 08-06-2020
    public function checkCentralOrLocal_post(){

        $data = $this->post();
        $response = $this->User_model->checkCentralOrLocal($data);
        $this->response($response);
       
    }
}
