<?php 
/**
 * Created by PhpStorm.
 * User: amal
 * Date: 26/10/17
 * Time: 3:00 PM
 */
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';

class BookingController extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("Booking_model");
        $this->load->model("Support_model");
    }

    public function checkSplCustomerInCentral_post(){

        $input_data = $this->post();
        $awb_number = isset($input_data['AWBNumber']) ? $input_data['AWBNumber'] : $this->error_response('AWBNumber is required');
        $ebooking_result = $this->Booking_model->getCentralSplCustomerData($awb_number);
        $product_type = null;
        if(in_array($awb_number[0],array('V,E,X'))){
            $product_type = 'PEP';
        }else{
            $product_type = 'LITE';
        }
       
        if($ebooking_result){

                $customer_result = $this->Booking_model->getCustomerDetailsFromCustomerId($ebooking_result['CUSTOMER_ID']);

                $pincode_result = $this->Booking_model->getPincodeDetails($ebooking_result['PINCODE']);
                if($pincode_result){
                    if($pincode_result['WEIGHT_KGS'] == null){
                        $pincode_res = $this->Booking_model->getWeightKGSDtls($product_type);
                        $pincode_result['WEIGHT_KGS'] =  $pincode_res[0]['WEIGHT_KGS'];
                        $pincode_result['PER_PIECE'] =  $pincode_res[0]['PER_PIECE'];
                    }
                }


                $commodity_result = $this->Booking_model->getCommodityDetailsFromCommodityId($ebooking_result['COMMODITY_ID']);

                $service_result = $this->Booking_model->getServiceDetailsFromServiceCode($ebooking_result['SERVICE_TYPE']);

                $vas_result = $this->Booking_model->getVasDetailsFromServiceCode($ebooking_result['VAS_PRODUCT']);

                $response = [
                    'ebooking' => 1,
                    'customer_data' => $customer_result,
                    'pincode' => $pincode_result,
                    'commodity' => $commodity_result,
                    'numOfPieces' => $ebooking_result['NO_OF_PIECES'],
                    'service' => $service_result,
                    'declaredValue' => $ebooking_result['INVOICE_VALUE'],
                    'referenceNumber' => $ebooking_result['REF_NUMBER'],
                    'ewbNumber' => $ebooking_result['EWB_NUMBER'],
                    'vas' => $vas_result,
                    'codValue' => $ebooking_result['COD_AMOUNT'],
                    'fodValue' => $ebooking_result['FOD_AMOUNT'],
                    'paymentModeSelected' => $ebooking_result['MODE_OF_COLLECTION'],
                    'insured' => $ebooking_result['INSURED'],
                    'insuredBy' => $ebooking_result['INSURED_BY'],
                    'breadth' => $ebooking_result['BREADTH'],
                    'length' => $ebooking_result['LENGTH'],
                    'height' => $ebooking_result['HEIGHT'],
                    'volumetricWeight' => $ebooking_result['VOLUMETRIC_WGHT'],
                    'weight' => $ebooking_result['WEIGHT'],
                    'shipment_type' => $ebooking_result['SHIPMENT_TYPE'],
                    'customer_branch' => $ebooking_result['CUSTOMER_BRANCH'],
                    'validation' => $ebooking_result['VER_TYPE']
                ];
            }else{

                $response = [
                    'status' => 0,
                    'message' => 'Online Booking in EFR/FROB App is mandatory'
                ];

            }

        $this->set_response($response, REST_Controller::HTTP_OK);


    }

   
    public function validateAwbNumber_post()
    {

        $hub_code = '';
        $hub_type = '';
        $franchise = [];

        $current_db_ip = null;

        $input_data = $this->post();

        $awb_number = isset($input_data['AWBNumber']) ? $input_data['AWBNumber'] : $this->error_response('AWBNumber is required');
        $booking_type_flag = isset($input_data['bookingTypeFlag']) ? $input_data['bookingTypeFlag'] : $this->error_response('bookingTypeFlag is required');;
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');

        if(in_array($awb_number[0],array('V,E,X'))){
            $product_type = 'PEP';
        }else{
            $product_type = 'LITE';
        }
        
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
           
        } else {
            $connect = new Connection_model();
            $connect->central();
           
        }

        ## STOP status new api created hence commenting ##
        /*if($this->Booking_model->checkTheConsignmentIsStopped($awb_number)){
            $response = [
                'stop_status' => 1,
                'message' => 'This consignment is stopped'
            ];
            $this->set_response($response, REST_Controller::HTTP_OK);
            return;
        }*/

        //check if awb number exists

        if ($this->Booking_model->checkAirwayBillNumberIsExists($awb_number)) {
            $response = [
                'status' => 0,
                'message' => 'Consignment already saved.'
            ];
            $this->set_response($response, REST_Controller::HTTP_OK);
            return;
        }

        $ga_allow_status = 1;
        $weight_validation = $this->Booking_model->getSuggestedMaxWeight(strtoupper($awb_number[0]));

        switch ($booking_type_flag) {
            case 'CP':

                $hub_type = 'FR';

                $result = $this->Booking_model->getAwbNumberDetailsForFranchisee($awb_number);

                if ($result) {

                    $issueDocumentDate = $result['ISSUE_DOCUMENT_DATE'];
                    $daysDifference = $this->Booking_model->getTheDifferenceInDays($issueDocumentDate);

	                $dateTime = new DateTime();
	                $issueDocumentDateObject = $dateTime::createFromFormat('Y-m-d',$issueDocumentDate,new DateTimeZone('Asia/Kolkata'));

                    if($daysDifference > 365) {
                        $response = [
                            'status' => 0,
                            'message' => 'This consignment is expired, The Issue date is ('.$issueDocumentDateObject->format("d-m-Y").')',
	                        'document_issue_date' => $issueDocumentDate
                        ];
                        $this->set_response($response, REST_Controller::HTTP_OK);
                        return;
                    }


                    if (strtoupper($awb_number[0]) === 'G') {
                        $ga_allow_status = $this->Booking_model->checkGaStatusForGSeriesAwbNumber($result['franchisee_id']);
                    }


                    $hub_code = $result['franchisee_code'];

                    $response = [
                        'status' => 1,
                        'ga_allow_status' => $ga_allow_status,
                        'message' => 'Success',
                        'weight_validation' => $weight_validation,
                        'data' => [
                            'id' => $result['franchisee_id'],
                            'businessName' => $result['business_name'],
                            'code' => $result['franchisee_code'],
                            'revenue_category' => $result['revenue_category'],
                            'parent_fr_code' => $result['parent_fr_code'],
                            'online_booking' => $result['online_booking']
                        ]
                    ];

                    $franchise = $response['data'];

                } else {
                    $response = [
                        'status' => 0,
                        'message' => 'Not found'
                    ];
                }


                break;
            case 'DP':

                $hub_type = 'BR';

                $result = $this->Booking_model->getAwbNumberDetailsForCustomer($awb_number);

                if ($result) {

                    $hub_code = $result['customer_code'];

                    $response = [
                        'status' => 1,
                        'message' => 'Success',
                        'weight_validation' => $weight_validation,
                        'data' => [
                            'id' => $result['customer_id'],
                            'businessName' => $result['business_name'],
                            'code' => $result['customer_code']
                        ]
                    ];


                } else {
                    $response = [
                        'status' => 0,
                        'message' => 'Not found'
                    ];
                }

                break;

            case 'CPDP':

                $hub_type = 'BR';

                $result = $this->Booking_model->getAwbNumberDetailsForFranchisee($awb_number);


                if ($result) {

                    $issueDocumentDate = $result['ISSUE_DOCUMENT_DATE'];
                    $daysDifference = $this->Booking_model->getTheDifferenceInDays($issueDocumentDate);
                    if($daysDifference > 365) {
                        $response = [
                            'status' => 0,
                            'message' => 'This consignment is expired, The Issue date is ('.$issueDocumentDate.')'
                        ];
                        $this->set_response($response, REST_Controller::HTTP_OK);
                        return;
                    }
                    if (strtoupper($awb_number[0]) === 'G') {
                        $ga_allow_status = $this->Booking_model->checkGaStatusForGSeriesAwbNumber($result['franchisee_id']);
                    }

                    $hub_code = $result['franchisee_code'];

                    $customer_id = $result['customer_id'];

                    if ($customer_id) {
                        $customer_data = $this->Booking_model->getCustomerDetailFromCustomerId($customer_id);
                    } else {
                        $customer_data = $this->Booking_model->getCustomerDetailsFromFrIdWithAWBNumber($awb_number,$result['franchisee_id']);
                    }

                    if(!$customer_data){
                      $cust_data =   $this->Booking_model->getCustomerDetailsFromFranchisee($result['franchisee_id']);
                      if(!$cust_data){
                          return [
                              'status' => 0,
                              'message' => "There is No customer found under franchisee code ".$hub_code." please select CP option to book the consignment"
                          ];
                      }
                    }
                    $response = [
                        'status' => 1,
                        'message' => 'Success',
                        'weight_validation' => $weight_validation,
                        'ga_allow_status' => $ga_allow_status,
                        'data' => [
                            'id' => $result['franchisee_id'],
                            'businessName' => $result['business_name'],
                            'code' => $result['franchisee_code'],
                            'revenue_category' => $result['revenue_category'],
                            'parent_fr_code' => $result['parent_fr_code'],
                            'online_booking' => $result['online_booking'],
                            'customer_data' => $customer_data ? $customer_data : $cust_data
                        ]
                    ];

                    $franchise = $response['data'];

                } else {
                    $response = [
                        'status' => 0,
                        'message' => 'Not found'
                    ];
                }
                break;

            default:

                $response = [
                    'status' => 0,
                    'message' => 'Not found'
                ];

                break;

        }


        //check if data is available in dtdc_f_spl_cust_data
        if ($hub_code && $hub_type) {

            $ebooking_result = $this->Booking_model->getAwbNumberDetailsFromSpecialCustomerData($awb_number, $hub_type, $hub_code);
           
            if(isset($franchise['online_booking']) && ($franchise['online_booking'] == 'Y')) {
//               $online_booking_ebooking_result = $this->Booking_model->getAwbNumberDetailsFromSpecialCustomerData($awb_number, $hub_type, $hub_code);
                   
                    if(!$ebooking_result && $local_db_ip != 'null'){
                       
                        $response = [
                            'status' => 2,
                            'message' => 'Online Booking Status Y. But Special customer data not found in local db.',
                            'data' => $response
                        ];
                        $this->set_response($response, REST_Controller::HTTP_OK);
                        return;
                    }
                    if(!$ebooking_result && $local_db_ip == 'null'){
                        $response = [
                            'status' => 0,
                            'message' => 'Online Booking in EFR/FROB App is mandatory'
                        ];
                        $this->set_response($response, REST_Controller::HTTP_OK);
                        return;
                    }
             
            }

            if ($local_db_ip != 'null') {
                $connect = new Connection_model();
                $connect->custom($local_db_ip);
            } else {
                $connect = new Connection_model();
                $connect->central();
            }


            if ($ebooking_result) {

                //get customer data

                $customer_result = $this->Booking_model->getCustomerDetailsFromCustomerId($ebooking_result['CUSTOMER_ID']);
                $pincode_result = $this->Booking_model->getPincodeDetails($ebooking_result['PINCODE']);
                if($pincode_result){
                    if($pincode_result['WEIGHT_KGS'] == null){
                        $pincode_result['PER_PIECE'] =  null;
                        $pincode_res = $this->Booking_model->getWeightKGSDtls($product_type);
                        if($pincode_res){
                            $pincode_result['WEIGHT_KGS'] =  $pincode_res[0]['WEIGHT_KGS'];
                            $pincode_result['PER_PIECE'] =  $pincode_res[0]['PER_PIECE'];
                        }
                        
                            
                    }
                }


                $commodity_result = $this->Booking_model->getCommodityDetailsFromCommodityId($ebooking_result['COMMODITY_ID']);

                $service_result = $this->Booking_model->getServiceDetailsFromServiceCode($ebooking_result['SERVICE_TYPE']);

                $vas_result = $this->Booking_model->getVasDetailsFromServiceCode($ebooking_result['VAS_PRODUCT']);

                $response = [
                    'ebooking' => 1,
                    'franchise' => $franchise,
                    'customer_data' => $customer_result,
                    'pincode' => $pincode_result,
                    'weight_validation' => $weight_validation,
                    'commodity' => $commodity_result,
                    'numOfPieces' => $ebooking_result['NO_OF_PIECES'],
                    'service' => $service_result,
                    'declaredValue' => $ebooking_result['INVOICE_VALUE'],
                    'referenceNumber' => $ebooking_result['REF_NUMBER'],
                    'ewbNumber' => $ebooking_result['EWB_NUMBER'],
                    'vas' => $vas_result,
                    'codValue' => $ebooking_result['COD_AMOUNT'],
                    'fodValue' => $ebooking_result['FOD_AMOUNT'],
                    'paymentModeSelected' => $ebooking_result['MODE_OF_COLLECTION'],
                    'insured' => $ebooking_result['INSURED'],
                    'insuredBy' => $ebooking_result['INSURED_BY'],
                    'breadth' => $ebooking_result['BREADTH'],
                    'length' => $ebooking_result['LENGTH'],
                    'height' => $ebooking_result['HEIGHT'],
                    'volumetricWeight' => $ebooking_result['VOLUMETRIC_WGHT'],
                    'weight' => $ebooking_result['WEIGHT'],
                    'shipment_type' => $ebooking_result['SHIPMENT_TYPE'],
                    'customer_branch' => $ebooking_result['CUSTOMER_BRANCH'],
                    'validation' => $ebooking_result['VER_TYPE']
                ];

            }
        } else {
            $response = [
                'status' => 0,
                'current_db_ip' => $current_db_ip,
                'message' => 'Not found'
            ];
        }
  
      
        $this->set_response($response, REST_Controller::HTTP_OK);


    }


    public function checkServiceablePincode_post()
    {

        $input_data = $this->post();

        $pincode = isset($input_data['PINCode']) ? $input_data['PINCode'] : $this->error_response('PINCode is required');
        $product_code = isset($input_data['product_code']) ? $input_data['product_code'] : $this->error_response('product_code is required');
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $shipment_type = isset($input_data['shipmentType']) ? $input_data['shipmentType'] : $this->error_response('shipmentType is required');
        $series_type = isset($input_data['seriesType']) ? $input_data['seriesType'] : null;
        $pincode_details['PER_PIECE']= null;

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        if ($shipment_type === 'PEP') {
            $pincode_details = $this->Booking_model->getPincodeDetailsForPep($pincode);
        } else {
            $pincode_details = $this->Booking_model->getPincodeDetails($pincode);
        }
        if($pincode_details){

            if($pincode_details['WEIGHT_KGS'] == null ){
                $pincode_res = $this->Booking_model->getWeightKGSDtls($product_code);
                $pincode_details['WEIGHT_KGS'] =  $pincode_res[0]['WEIGHT_KGS'];
                $pincode_details['PER_PIECE'] =  $pincode_res[0]['PER_PIECE'];
            }
          
        }


        $x_allow_status = 0;

        if ($series_type === 'X' && $this->Booking_model->getXSeriesPinCodeServiceability($pincode_details['DEST_PINCODE_ID'])) {
            $x_allow_status = 1;
        }


        if ($pincode_details) {
            $response = [
                "status" => 1,
                "message" => "Success",
                "xAllowStatus" => $x_allow_status,
                "pb_pincode_config" => $this->Booking_model->getParcelBranchConfigurationForPincode($pincode, $product_code),
                "data" => [
                    "cityCode" => $pincode_details['col_0_0_'],
                    "cityId" => $pincode_details['DEST_CITY_ID'],
                    "PinCodeId" => $pincode_details['DEST_PINCODE_ID'],
                    "cityName" => $pincode_details['DEST_CITY_NAME'],
                    "WEIGHT_KGS" => $pincode_details['WEIGHT_KGS'],
                    "PER_PIECE" => $pincode_details['PER_PIECE']

                ]
            ];
        } else {
            $response = [
                'status' => 0,
                'message' => 'Not serviceable'
            ];
        }

        $this->set_response($response, REST_Controller::HTTP_OK);

    }


    public function getServices_post()
    {

        $input_data = $this->post();

        $character = isset($input_data['character']) ? $input_data['character'] : $this->error_response('character is required');
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $services = $this->Booking_model->getServices($character);

        $response = [
            'status' => 1,
            'message' => 'Success',
            'data' => $services
        ];

        $this->set_response($response, REST_Controller::HTTP_OK);

    }

    public function getDpBookingRiskCoverWithMaximumInvoiceValue_post()
    {
        $input_data = $this->post();

        $customer_code = isset($input_data['customerCode']) ? $input_data['customerCode'] : $this->error_response('customerCode is required');
        $service_id = isset($input_data['serviceID']) ? $input_data['serviceID'] : $this->error_response('serviceID is required');
        $customer_id = isset($input_data['customerID']) ? $input_data['customerID'] : $this->error_response('customerID is required');
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');


        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $risk_cover = $this->Booking_model->getRiskCover($customer_code);

        if ($risk_cover) {
            $risk_cover_value = $risk_cover['RISK_COVER'];
        } else {
            $risk_cover_value = null;
        }


        $maximum_invoice = $this->Booking_model->getMaximumInvoiceValue($customer_id, $service_id);

        if ($maximum_invoice) {
            $invoice_value_from = $maximum_invoice['INVOICE_VALUE_FROM'];
            $invoice_value_to = $maximum_invoice['INVOICE_VALUE_TO'];
        } else {
            $invoice_value_from = null;
            $invoice_value_to = null;
        }

        $response = [
            'status' => 1,
            'message' => 'Success',
            'data' => [
                'riskCover' => $risk_cover_value,
                'invoiceValueFrom' => $invoice_value_from,
                'invoiceValueTo' => $invoice_value_to
            ]
        ];

        $this->set_response($response, REST_Controller::HTTP_OK);

    }

   

    public function saveNonDoxBooking_post()
    {
        $input_data = $this->post();

        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        


        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $result = $this->Booking_model->saveNonDoxBooking($input_data);
        $this->set_response($result, REST_Controller::HTTP_OK);

    }

    public function rlgServiceValidation_post()
    {
        $input_data = $this->post();

        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $pincode = isset($input_data['pincode']) ? $input_data['pincode'] : $this->error_response('pincode is required');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        if ($this->Booking_model->getPincodeRlg($pincode)) {
            $response = [
                'status' => 1,
                'message' => 'Ok'
            ];
        } else {
            $response = [
                'status' => 0,
                'message' => 'Not ok'
            ];
        }

        $this->set_response($response, REST_Controller::HTTP_OK);

    }

    public function codServiceableStatusChecking_post()
    {

        $input_data = $this->post();

        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $pincode_id = isset($input_data['pincodeId']) ? $input_data['pincodeId'] : $this->error_response('pincodeId is required');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        if ($data = $this->Booking_model->getCodServiceableStatus($pincode_id)) {
            $response = [
                'status' => 1,
                'data' => $data,
                'message' => 'Ok'
            ];
        } else {
            $response = [
                'status' => 0,
                'message' => 'Not ok'
            ];
        }

        $this->set_response($response, REST_Controller::HTTP_OK);

    }

    public function codServiceableStatusCheckingPincodeId_post()
    {

        $input_data = $this->post();

        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $pincode_id = isset($input_data['pincodeId']) ? $input_data['pincodeId'] : $this->error_response('pincodeId is required');
        $consgNumber = isset($input_data['consgNumber']) ? $input_data['consgNumber'] : $this->error_response('consgNumber is required');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        if ($data = $this->Booking_model->getCodServiceableStatusPincode($pincode_id, $consgNumber)) {
            $response = [
                'status' => 1,
                'data' => $data,
                'message' => 'Ok'
            ];
        } else {
            $response = [
                'status' => 0,
                'message' => 'Not ok'
            ];
        }

        $this->set_response($response, REST_Controller::HTTP_OK);

    }

    public function error_response($e)
    {
        $response = array('status' => 0, 'message' => $e);
        echo json_encode($response);
        exit;
    }

    public function getTatForProduct_post()
    {
        $input_data = $this->post();

        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $origin_office_id = isset($input_data['originOfficeId']) ? $input_data['originOfficeId'] : $this->error_response('originOfficeId is required');
        $destination_pincode = isset($input_data['destinationPincode']) ? $input_data['destinationPincode'] : $this->error_response('destinationPincode is required');
        $product_id = isset($input_data['productId']) ? $input_data['productId'] : $this->error_response('productId is required');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $tats = $this->Booking_model->getTatForProduct($origin_office_id, $destination_pincode, $product_id);

        $response = [
            'status' => 1,
            'data' => $tats,
            'message' => 'Ok'
        ];

        $this->set_response($response, REST_Controller::HTTP_OK);

    }

    public function getServicesFromTat_post()
    {
        $input_data = $this->post();

        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $origin_city_id = isset($input_data['originCityId']) ? $input_data['originCityId'] : $this->error_response('originCityId is required');
        $destination_city_id = isset($input_data['destinationCityId']) ? $input_data['destinationCityId'] : $this->error_response('destinationCityId is required');
        $tat = isset($input_data['tat']) ? $input_data['tat'] : $this->error_response('tat is required');
        $product_id = isset($input_data['productId']) ? $input_data['productId'] : $this->error_response('productId is required');
        $weight = isset($input_data['weight']) ? $input_data['weight'] : $this->error_response('weight is required');
        $pincode_id = isset($input_data['pincodeId']) ? $input_data['pincodeId'] : $this->error_response('pincodeId is required');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $validated_services = [];

        $services = $this->Booking_model->getServicesFromTat($origin_city_id, $destination_city_id, $tat, $product_id, $weight);


        foreach ($services as $value) {
            if ($this->Booking_model->validateServiceabilityOfServiceType($value['SERVICE_TYPE'], $pincode_id)) {
                array_push($validated_services, $value);
            }
        }

        $response = [
            'status' => 1,
            'data' => $validated_services,
            'message' => 'Ok'
        ];

        $this->set_response($response, REST_Controller::HTTP_OK);

    }


    public function getServicesForCp_post()
    {
        $input_data = $this->post();

        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $origin_city_id = isset($input_data['originCityId']) ? $input_data['originCityId'] : $this->error_response('originCityId is required');
        $destination_city_id = isset($input_data['destinationCityId']) ? $input_data['destinationCityId'] : $this->error_response('destinationCityId is required');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $services = $this->Booking_model->getServicesForCp($origin_city_id, $destination_city_id);

        $response = [
            'status' => 1,
            'data' => $services,
            'message' => 'Ok'
        ];

        $this->set_response($response, REST_Controller::HTTP_OK);

    }


    public function getServicesForDpOrCpDp_post()
    {
        $input_data = $this->post();

        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $customer_id = isset($input_data['customerId']) ? $input_data['customerId'] : $this->error_response('customerId is required');
        $product_id = isset($input_data['productId']) ? $input_data['productId'] : $this->error_response('productId is required');
        $weight = isset($input_data['weight']) ? $input_data['weight'] : $this->error_response('weight is required');
        $origin_city_id = isset($input_data['originCityId']) ? $input_data['originCityId'] : $this->error_response('originCityId is required');
        $destination_city_id = isset($input_data['destinationCityId']) ? $input_data['destinationCityId'] : $this->error_response('destinationCityId is required');
        $booking_type = isset($input_data['bookingType']) ? $input_data['bookingType'] : $this->error_response('bookingType is required');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $service_list = $this->Booking_model->getServicesForDpOrCpDp($booking_type, $customer_id, $product_id, $weight, $origin_city_id, $destination_city_id);

        $response = [
            'status' => 1,
            'data' => $service_list,
            'message' => 'Ok'
        ];

        $this->set_response($response, REST_Controller::HTTP_OK);

    }

    public function getServicesForE_post()
    {
        $input_data = $this->post();

        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $origin_office_id = isset($input_data['originOfficeId']) ? $input_data['originOfficeId'] : $this->error_response('originOfficeId is required');
        $destination_pincode = isset($input_data['destinationPincode']) ? $input_data['destinationPincode'] : $this->error_response('destinationPincode is required');
        $pincode_id = isset($input_data['pincodeId']) ? $input_data['pincodeId'] : $this->error_response('pincodeId is required');
        $origin_city_id = isset($input_data['originCityId']) ? $input_data['originCityId'] : $this->error_response('originCityId is required');
        $destination_city_id = isset($input_data['destinationCityId']) ? $input_data['destinationCityId'] : $this->error_response('destinationCityId is required');
        $weight = isset($input_data['weight']) ? $input_data['weight'] : $this->error_response('weight is required');
        $product_id = isset($input_data['productId']) ? $input_data['productId'] : $this->error_response('productId is required');


        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $tats = $this->Booking_model->getTatForProduct($origin_office_id, $destination_pincode, $product_id);

        $tat_query = $this->Booking_model->getLastQuery();

        $tats_csv_array = [];

        foreach ($tats as $value) {
            array_push($tats_csv_array, (int)$value['TAT_IN_DAYS']);
        }

        $services = $this->Booking_model->getServicesFromTatForE($origin_city_id, $destination_city_id, $tats_csv_array, $weight);

        $services_query = $this->Booking_model->getLastQuery();

        $validated_services = [];

        foreach ($services as $value) {
            if ($this->Booking_model->validateServiceabilityOfServiceType($value['SERVICE_TYPE'], $pincode_id)) {
                array_push($validated_services, $value);
            }
        }

        $response = [
            'status' => 1,
            'data' => $validated_services,
            'message' => 'Ok',
            'tats' => $tats,
            'tat_csv' => $tats_csv_array,
            'services' => $services,
            'tat_query' => $tat_query,
            'services_query' => $services_query

        ];

        $this->set_response($response, REST_Controller::HTTP_OK);


    }

    public function getCutoffTimeForService_post()
    {
        $input_data = $this->post();

        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $category_id = isset($input_data['categoryId']) ? $input_data['categoryId'] : $this->error_response('categoryId is required');
        $origin_office_id = isset($input_data['originOfficeId']) ? $input_data['originOfficeId'] : $this->error_response('originOfficeId is required');
        $destination_pincode = isset($input_data['destinationPincode']) ? $input_data['destinationPincode'] : $this->error_response('destinationPincode is required');
        $pincode_id = isset($input_data['pincodeId']) ? $input_data['pincodeId'] : $this->error_response('pincodeId is required');
        $origin_city_id = isset($input_data['originCityId']) ? $input_data['originCityId'] : $this->error_response('originCityId is required');
        $destination_city_id = isset($input_data['destinationCityId']) ? $input_data['destinationCityId'] : $this->error_response('destinationCityId is required');
        $weight = isset($input_data['weight']) ? $input_data['weight'] : $this->error_response('weight is required');
        $product_id = isset($input_data['productId']) ? $input_data['productId'] : $this->error_response('productId is required');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $cutoff_times = $this->Booking_model->getCutoffTimeForService($category_id, $origin_city_id, $destination_city_id, $origin_office_id, $destination_pincode, $product_id, $weight);

        $response = [
            'status' => 1,
            'data' => $cutoff_times,
            'message' => 'Ok'
        ];

        $this->set_response($response, REST_Controller::HTTP_OK);


    }

    public function getTheServicesForESeriesDPBooking_post()
    {
        $input_data = $this->post();

        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $origin_city_id = isset($input_data['originCityId']) ? $input_data['originCityId'] : $this->error_response('originCityId is required');
        $dest_city_id = isset($input_data['destCityId']) ? $input_data['destCityId'] : $this->error_response('destCityId is required');
        $customer_id = isset($input_data['customerId']) ? $input_data['customerId'] : $this->error_response('customerId is required');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }


        $services = $this->Booking_model->getTheServicesForESeriesDPBooking1($customer_id);

        if (count($services) === 0) {
            $services = $this->Booking_model->getTheServicesForESeriesDPBooking2($origin_city_id, $dest_city_id);
        }

        $response = [
            'status' => 1,
            'data' => $services,
            'message' => 'Ok'
        ];

        $this->set_response($response, REST_Controller::HTTP_OK);

    }

    public function checkServiceabilityOfPincodeForESeriesDPBooking_post()
    {
        $input_data = $this->post();

        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $service_id = isset($input_data['serviceId']) ? $input_data['serviceId'] : $this->error_response('serviceId is required');
        $customer_id = isset($input_data['customerId']) ? $input_data['customerId'] : $this->error_response('customerId is required');
        $pincode_id = isset($input_data['pincodeId']) ? $input_data['pincodeId'] : $this->error_response('pincodeId is required');
        $service_type = isset($input_data['serviceType']) ? $input_data['serviceType'] : $this->error_response('serviceType is required');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $booking_model = new Booking_model();
        if ($booking_model->checkServiceabilityOfPincodeForESeriesDPBooking1($customer_id, $service_id)) {
            $serviceability = 1;
        } else {
            $serviceability = $booking_model->checkServiceabilityOfPincodeForESeriesDPBooking2($pincode_id, $service_type);
        }

        $response = [
            'serviceability' => $serviceability
        ];

        $this->set_response($response, REST_Controller::HTTP_OK);

    }

    public function getEwbFlag_post()
    {
        $input_data = $this->post();

        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $originCityId = isset($input_data['originCityId']) ? $input_data['originCityId'] : $this->error_response('originCityId is required');
        $destCityId = isset($input_data['destCityId']) ? $input_data['destCityId'] : $this->error_response('destCityId is required');
        $invoiceValue = isset($input_data['invoiceValue']) ? $input_data['invoiceValue'] : $this->error_response('invoiceValue is required');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $booking_model = new Booking_model();
        $response = [
            'ewb_status' => $booking_model->getEwbFlag($originCityId, $destCityId, $invoiceValue)
        ];

        $this->set_response($response, REST_Controller::HTTP_OK);

    }

    public function getConsignmentStopStatus_post()
    {
        $input_data = $this->post();

        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $consignment_number = isset($input_data['consignment_number']) ? $input_data['consignment_number'] : $this->error_response('consignment_number is required');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $booking_model = new Booking_model();
        $response = [
            'stop_status' => $booking_model->getConsignmentNumberStopStatus($consignment_number)
        ];

        $this->set_response($response, REST_Controller::HTTP_OK);
    }

    public function saveDoxBookingCNC_post(){

        $input_data = $this->post();

        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');


        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $response = $this->Booking_model->saveDoxBookingCNC($input_data);

      //  $response = ['status' => 1, 'totalSaved' => $total_saved, 'message' => 'Saved successfully'];

        $this->set_response($response, REST_Controller::HTTP_OK);
    }

    public function saveDoxBooking_post()
    {

        $input_data = $this->post();

        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');


        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $total_saved = $this->Booking_model->saveDoxBooking($input_data);

        $response = ['status' => 1, 'totalSaved' => $total_saved, 'message' => 'Saved successfully'];

        $this->set_response($response, REST_Controller::HTTP_OK);
    }


    public function checkOperationalFreedomEligibility_post() {
	    $input_data = $this->post();

	    $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
		$consignment_number = isset($input_data['consg_number']) ? $input_data['consg_number'] : $this->error_response('consg_number is required');

	    if ($local_db_ip != 'null') {
		    $connect = new Connection_model();
		    $connect->custom($local_db_ip);
	    } else {
		    $connect = new Connection_model();
		    $connect->central();
	    }

      $result = $this->Booking_model->checkOperationalFreedomEligibility($consignment_number);
        

	    if($result){
            $result['pincode'] = null;
            if($result['online_booking'] == 'Y'){
                $splCustData = $this->Booking_model->checkSplCustomerDataForOperationFreedom($consignment_number);
                $result['pincode'] = $splCustData['PINCODE'];
            }
		    $response = ['status' => 1, 'result' => $result, 'message' => 'Success'];
	    } else {
		    $response = ['status' => 0, 'message' => 'Operational freedom is not applicable for this consignment.'];
	    }

	    $this->set_response($response, REST_Controller::HTTP_OK);

    }

    public function saveOperationalFreedom_post() {
	    $input_data = $this->post();

	    $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');

	    if ($local_db_ip != 'null') {
		    $connect = new Connection_model();
		    $connect->custom($local_db_ip);
	    } else {
		    $connect = new Connection_model();
		    $connect->central();
	    }

	    $total_saved = $this->Booking_model->saveOperationalFreedom($input_data);

	    $response = ['status' => 1, 'totalSaved' => $total_saved, 'message' => 'Saved successfully'];

	    $this->set_response($response, REST_Controller::HTTP_OK);
    }

    public function getFrachiseeWalletBalance_post(){

        $input_data = $this->post();

        $result = $this->Support_model->getFrachiseeWalletBalance($input_data);
        $this->set_response($result, REST_Controller::HTTP_OK);
    }
    public function getRate_post(){

        $input_data = $this->post();



        $result = $this->Support_model->getRate($input_data);

        $remarks = $this->Support_model->CNCRemarkPenalitySave($input_data,$result);

        $booking_ts =  $this->Support_model->bookingTsSave($result['additionalTs']);

        $this->set_response($result, REST_Controller::HTTP_OK);
    }
    public function deductFranchiseeWalletBalance_post(){

        $input_data = $this->post();

        $result = $this->Support_model->deductFranchiseeWalletBalance($input_data);
        $this->set_response($result, REST_Controller::HTTP_OK);
    }
    public function getTheBookingDataForConsignment_post() {

        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $consgNumber = isset($input_data['consg_number']) ? $input_data['consg_number'] : $this->error_response('consg_number is required');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $bookedData = $this->Booking_model->getTheBookingDataForConsignment($consgNumber);

        if(!$bookedData) {
            $response = ['status' => 0, 'booked_data' => null, 'message' => 'Booked data not available'];
        } else {
            $response = ['status' => 1, 'booked_data' => $bookedData, 'message' => 'Booked data available'];
        }

        $this->set_response($response, REST_Controller::HTTP_OK);

    }

    public function checkOperationFreedonOnlineBooking_post(){

        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $consgNumber = isset($input_data['consg_number']) ? $input_data['consg_number'] : $this->error_response('consg_number is required');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $splCustData = $this->Booking_model->checkSplCustomerDataForOperationFreedom($consgNumber);
        if($splCustData){
             $result['pincode'] = $splCustData['PINCODE'];
             $response = ['status' => 1, 'result' => $result, 'message' => 'Success'];
        }else{
             $response = ['status' => 0, 'result' => null, 'message' => 'data not available'];
        }

        $this->set_response($response, REST_Controller::HTTP_OK);

    }


    public function forceCloser_post(){

        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $consgNumber = isset($input_data['consg_number']) ? $input_data['consg_number'] : $this->error_response('consg_number is required');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
        $response = $this->Booking_model->forceCloser($consgNumber);
        $this->set_response($response, REST_Controller::HTTP_OK);

        
    }

   

}
