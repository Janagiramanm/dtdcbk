<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';

class Outgoing extends REST_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model("Outgoing_model");
    }

    public function saveoutgoingbagmanifestfordox_post()
    {
        $data = $this->post();
        $reply = $this->Outgoing_model->saveoutgoingbagmanifestfordox($data);
        $this->response($reply);
    }

    public function saveoutgoingbagmanifestfornondox_post()
    {
        $data = $this->post();
        $reply = $this->Outgoing_model->saveoutgoingbagmanifestfornondox($data);
        $this->response($reply);
    }

    public function savemastercondispatch_post()
    {
        $data = $this->post();
        $reply = $this->Outgoing_model->savemastercondispatch($data);
        $this->response($reply);
    }

    public function mastercondispatchchangescan_post()
    {
        $data = $this->post();
        $reply = $this->Outgoing_model->mastercondispatchchangescan($data);
        $this->response($reply);
    }

    public function mastercondispatchremovalscan_post()
    {
        $data = $this->post();
        $reply = $this->Outgoing_model->mastercondispatchremovalscan($data);
        $this->response($reply);
    }

    public function mastercondispatchupdatecdno_post()
    {
        $data = $this->post();
        $reply = $this->Outgoing_model->mastercondispatchupdatecdno($data);
        $this->response($reply);
    }

    public function mastercondispatchgetdocumentid_post()
    {
        $data = $this->post();
        $reply = $this->Outgoing_model->mastercondispatchgetdocumentid($data);
        $this->response($reply);
    }

    public function getModeIdForMCD_post()
    {
        $data = $this->post();
        $reply = $this->Outgoing_model->getModeIdForMCD($data);
        $this->response($reply);
    }


    public function gettsroutemapping_post()
    {
        $data = $this->post();
        $reply = $this->Outgoing_model->gettsroutemapping($data);
        $this->response($reply);
    }


    public function outgoingbagmanifestsearch_post()
    {
        $data = $this->post();
        $reply = $this->Outgoing_model->outgoingbagmanifestsearch($data);
        $this->response($reply);
    }

    public function removalentity_post()
    {
        $data = $this->post();
        $reply = $this->Outgoing_model->removalentity($data);
        $this->response($reply);
    }

    public function getweightfordoxconsignment_post()
    {
        $data = $this->post();
        $reply = $this->Outgoing_model->getweightfordoxconsignment($data);
        $this->response($reply);
    }

    public function validatingsurelockpmfsticker_post()
    {
        $data = $this->post();
        $reply = $this->Outgoing_model->validatingsurelockpmfsticker($data);
        $this->response($reply);
    }

    public function get_desc_goods_post()
    {
        $data = $this->post();
        $reply = $this->Outgoing_model->get_desc_goods($data);
        $this->response($reply);
    }

    public function get_dispatch_number_post()
    {
        $data = $this->post();
        $reply = $this->Outgoing_model->get_dispatch_number($data);
        $this->response($reply);
    }

    public function mastercondispatchvalidatecdno_post()
    {
        $data = $this->post();
        $reply = $this->Outgoing_model->mastercondispatchvalidatecdno($data);
        $this->response($reply);
    }

    public function getCoLoaders_post()
    {
        $input_data = $this->post();

        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $logged_in_office_id = isset($input_data['loggedInOfficeId']) ? $input_data['loggedInOfficeId'] : $this->error_response('loggedInOfficeId is required');
        $mode_id = isset($input_data['modeId']) ? $input_data['modeId'] : $this->error_response('modeId is required');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $co_loaders = $this->Outgoing_model->getCoLoaders($logged_in_office_id, $mode_id);

        $response = [
            'status' => 1,
            'data' => $co_loaders,
            'message' => 'Ok'
        ];

        $this->set_response($response, REST_Controller::HTTP_OK);


    }

    public function getTheWeightForRTOCN_post()
    {

        $input_data = $this->post();

        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $consgNumber = isset($input_data['consgNumber']) ? $input_data['consgNumber'] : $this->error_response('consgNumber is required');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $weight = $this->Outgoing_model->getWeightForConsgNumber($consgNumber);

        $response = [
            'weight' => $weight
        ];

        $this->set_response($response, REST_Controller::HTTP_OK);

    }

    public function validateSureLockNumber_post()
    {
        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $logged_in_office_id = isset($input_data['loggedInOfficeId']) ? $input_data['loggedInOfficeId'] : $this->error_response('loggedInOfficeId is required');
        $manifest_number = isset($input_data['manifestNumber']) ? $input_data['manifestNumber'] : $this->error_response('manifestNumber is required');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $manifest_number_allow_status = $this->Outgoing_model->validateSureLockNumber($manifest_number, $logged_in_office_id);

        $response = [
            'manifest_number_allow_status' => $manifest_number_allow_status
        ];
        $this->set_response($response, REST_Controller::HTTP_OK);


    }

    public function checkBranchIsParcelBranch_post()
    {
        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
        $branch_code = isset($input_data['branch_code']) ? $input_data['branch_code'] : $this->error_response('branch_code is required');
        $response = [
            'details' => $this->Outgoing_model->checkBranchIsParcelBranch($branch_code)
        ];
        $this->set_response($response, REST_Controller::HTTP_OK);
    }

    public function getDirectConnection_post()
    {
        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $logged_in_office_id = isset($input_data['loggedInOfficeId']) ? $input_data['loggedInOfficeId'] : $this->error_response('loggedInOfficeId is required');
        $report_office_id = isset($input_data['reportOfficeId']) ? $input_data['reportOfficeId'] : $this->error_response('reportOfficeId is required');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }


        $data = $this->Outgoing_model->getDirectConnection($logged_in_office_id, $report_office_id);
        $response = [
            'status' => 1,
            'data' => $data,
            'message' => 'Ok'
        ];
        $this->set_response($response, REST_Controller::HTTP_OK);
    }

    public function getTheOtcs_post()
    {
        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $origin_office_id = isset($input_data['originOfficeId']) ? $input_data['originOfficeId'] : $this->error_response('originOfficeId is required');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }


        $data = $this->Outgoing_model->getTheOtcs($origin_office_id);
        $response = [
            'status' => 1,
            'data' => $data,
            'message' => 'Ok'
        ];
        $this->set_response($response, REST_Controller::HTTP_OK);
    }

	/**
	 * To automate the consolidated ewb number.
	 */
    public function automateConsolidatedEwbNumber_post() {
	    $input_data = $this->post();
	    $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $nodeid = isset($input_data['nodeid']) ? $input_data['nodeid'] : $this->error_response('nodeid is required');
        $wardate = isset($input_data['wardate']) ? $input_data['wardate'] : $this->error_response('wardate is required');
        $transaction_uid = isset($input_data['transactionUID']) ? $input_data['transactionUID'] : $this->error_response('transactionUID is required');
	    $ewb_details = isset($input_data['ewbDetails']) ? $input_data['ewbDetails'] : $this->error_response('ewbDetails is required');
	    if ($local_db_ip != 'null') {
		    $connect = new Connection_model();
		    $connect->custom($local_db_ip);
	    } else {
		    $connect = new Connection_model();
		    $connect->central();
	    }

		$mc_ids = $this->Outgoing_model->automateConsolidatedEwbNumber($transaction_uid,$ewb_details,$nodeid,$wardate);

	    sleep(5);

	    $consolidate_ewb_no = $this->Outgoing_model->getConsolidateEwbNumberFromTransactionUid($transaction_uid);

	    if(!$consolidate_ewb_no) {
		    sleep(5);
		    $consolidate_ewb_no = $this->Outgoing_model->getConsolidateEwbNumberFromTransactionUid($transaction_uid);
	    }

	    $response = [
		    'consolidated_ewb_no' => $consolidate_ewb_no,
		    'mc_ids' => $mc_ids
	    ];
	    $this->set_response($response, REST_Controller::HTTP_OK);

    }

    public function checkAutomateConsolidatedEwbNumber_post() {
	    $input_data = $this->post();
	    $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
	    $transaction_uid = isset($input_data['transactionUID']) ? $input_data['transactionUID'] : $this->error_response('transactionUID is required');

	    if ($local_db_ip != 'null') {
		    $connect = new Connection_model();
		    $connect->custom($local_db_ip);
	    } else {
		    $connect = new Connection_model();
		    $connect->central();
	    }

	    $consolidate_ewb_no = $this->Outgoing_model->getConsolidateEwbNumberFromTransactionUid($transaction_uid);

	    $response = [
		    'consolidated_ewb_no' => $consolidate_ewb_no,
	    ];
	    $this->set_response($response, REST_Controller::HTTP_OK);

    }




    public function error_response($e)
    {
        $response = array('status' => 0, 'message' => $e);
        echo json_encode($response);
        exit;
    }

    public function bagManifestValidationForDox_post(){
        $input_data = $this->post();
	    $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
	    
	    if ($local_db_ip != 'null') {
		    $connect = new Connection_model();
		    $connect->custom($local_db_ip);
	    } else {
		    $connect = new Connection_model();
		    $connect->central();
        }

        $response = $this->Outgoing_model->bagManifestValidationForDox($input_data);

	    $this->set_response($response, REST_Controller::HTTP_OK);
    }

}
