<?php
/**
 * Created by PhpStorm.
 * User: amal
 * Date: 19/5/18
 * Time: 11:52 AM
 */

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';

class ApkController extends REST_Controller
{
    public function __construct($config = 'rest')
    {
        parent::__construct($config);
        $this->load->model('Apk');
    }

    public function apkDetails_post()
    {

        $input_data = $this->post();
        $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
        $apk_date = isset($input_data['apkDate']) ? $input_data['apkDate'] : $this->error_response('apkDate is required');
        $apk_version = isset($input_data['apkVersion']) ? $input_data['apkVersion'] : $this->error_response('apkVersion is required');
	    $office_id = isset($input_data['officeId']) ? $input_data['officeId'] : $this->error_response('officeId is required');


        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $apk = new Apk();
        $apk_details = $apk->getApkDetails($apk_date,$apk_version,$office_id);

        $apk_needs_update = 0;

        if(count($apk_details) > 0){
        	$apk_needs_update = 1;
        }

        $response = [
        	'apk_details' => $apk_details,
	        'apk_needs_update' => $apk_needs_update
        ];

        $this->set_response($response,REST_Controller::HTTP_OK);

    }

    public function isSessionActive_post (){
	    $input_data = $this->post();
	    $local_db_ip = isset($input_data['local_db_ip']) ? $input_data['local_db_ip'] : $this->error_response('local_db_ip is required');
	    $logInOutId = isset($input_data['logInOutId']) ? $input_data['logInOutId'] : $this->error_response('logInOutId is required');

	    if ($local_db_ip != 'null') {
		    $connect = new Connection_model();
		    $connect->custom($local_db_ip);
	    } else {
		    $connect = new Connection_model();
		    $connect->central();
	    }

	    $apk = new Apk();
	    $status = $apk->isSessionActive($logInOutId);
	    $response = [
		    'session_status' => $status,
	    ];

	    $this->set_response($response,REST_Controller::HTTP_OK);
    }

    public function error_response($e)
    {
        $response = array('status' => 0, 'message' => $e);
        echo json_encode($response);
        exit;
    }

}