<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require(APPPATH.'libraries/REST_Controller.php');

/**
 *
 */
class Autopacketmanifest extends REST_Controller
{

  function __construct()
  {
    parent::__construct();
    $this->load->model('Autopacketmanifest_model');
  }

  public function generate_post(){
    $data = $this->post();
    $reply = $this->Autopacketmanifest_model->generate($data);
    $this->response($reply);
  }
}
