<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH.'libraries/REST_Controller.php';

class Mastercondispatchservicetype extends REST_Controller {

  public function __construct(){
    parent::__construct();
    $this->load->model("MasterConDispatchServiceType_model");
  }

  public function service_type_post(){
    $data = $this->post();
    $reply = $this->MasterConDispatchServiceType_model->service_type($data);
    $this->response($reply);
  }

}
