<?php

/**
 *
 */
class Support_model extends CI_model
{

  function __construct() {
    // $this->load->database();
  }

  public function count_consgn_numbers_in_dtdc_f_manifest($manifestNumber,$consignmentNumber,$manifestType){
    $query = "select * from dtdc_f_manifest where consg_number = ? and manifest_number = ? and manifest_type = ?";
    $result = $this->db->query($query,[$consignmentNumber,$manifestNumber,$manifestType]);
    return $result->num_rows();
  }

  public function get_row_incoming_from_dtdc_f_manifest($consg_number,$office_id){
    $result_array = array();
    $query = "select * from dtdc_f_manifest where consg_number = ? and manifest_type = 'I' and RECV_OFFICE_ID = ? order by RECORD_ENTRY_DATETIME desc";
    $result = $this->db->query($query,[$consg_number,$office_id]);
    if($result->num_rows()>0){
      $result_array = $result->result_array();
    }
    return $result_array;
  }

  public function get_row_outgoing_from_dtdc_f_manifest($consg_number,$office_id){
    $result_array = array();
    $query = "select * from dtdc_f_manifest where consg_number = ? and manifest_type = 'O' and orig_brnch_id = ? order by RECORD_ENTRY_DATETIME desc";
    $result = $this->db->query($query,[$consg_number,$office_id]);
    if($result->num_rows()>0){
      $result_array = $result->result_array();
    }
    return $result_array;
  }

  public function get_row_incoming_from_dtdc_f_manifest_using_manifest_number($manifest_number,$office_id){
    $result_array = array();
    $query = "select * from dtdc_f_manifest where manifest_number = ? and manifest_type = 'I' and RECV_OFFICE_ID = ? order by RECORD_ENTRY_DATETIME desc";
    $result = $this->db->query($query,[$manifest_number,$office_id]);
    if($result->num_rows()>0){
      $result_array = $result->result_array();
    }
    return $result_array;
  }

  public function get_row_outgoing_from_dtdc_f_manifest_using_manifest_number($manifest_number,$office_id){
    $result_array = array();
    $query = "select * from dtdc_f_manifest where manifest_number = ? and manifest_type = 'O' and orig_brnch_id = ? order by RECORD_ENTRY_DATETIME desc";
    $result = $this->db->query($query,[$manifest_number,$office_id]);
    if($result->num_rows()>0){
      $result_array = $result->result_array();
    }
    return $result_array;
  }

  public function incoming_get_all_manifests_from_manifest_number($manifest_number) {
    $result_array = array();
    $query = "select * from dtdc_f_manifest where manifest_number = ? and manifest_type = 'I'";
    $result = $this->db->query($query,[$manifest_number]);
    if($result->num_rows()>0){
      $result_array = $result->result_array();
    }
    return $result_array;
  }

  public function outgoing_get_all_manifests_from_manifest_number($manifest_number) {
    $result_array = array();
    $query = "select * from dtdc_f_manifest where manifest_number = ? and manifest_type = 'O'";
    $result = $this->db->query($query,[$manifest_number]);
    if($result->num_rows()>0){
      $result_array = $result->result_array();
    }
    return $result_array;
  }

  public function get_row_incoming_from_dtdc_f_cd_receive_using_manifest_number($manifest_number,$office_id){
    $result_array = array();
    $query = "select * from dtdc_f_cd_receive where bag_manifest_number = ? and DEST_OFFICE_ID = ? order by TRANS_CREATE_DATE desc";
    // echo $query;
    $result = $this->db->query($query,[$manifest_number,$office_id]);
    if($result->num_rows()>0){
      $result_array = $result->result_array();
    }
    return $result_array;
  }

  public function get_row_outgoing_from_dtdc_f_dispatch_using_manifest_number($manifest_number,$office_id){
    $result_array = array();
    $query = "select * from dtdc_f_dispatch where BAG_MANIFEST_NUMBER = ? and DEST_OFFICE_ID = ? order by TRANS_CREATE_DATE desc";
    $result = $this->db->query($query,[$manifest_number,$office_id]);
    if($result->num_rows()>0){
      $result_array = $result->result_array();
    }
    return $result_array;
  }

  public function getManifestDetails($consgNumber,$destBranchId) {
  	$query = " select ORIG_BRNCH_ID, MODE_ID, DOCUMENT_ID, PRODUCT_ID, SERVICE_ID, MNFST_TYPE_ID, MANIFEST_TYPE_DEFN from dtdc_f_manifest where manifest_type = 'O' and CONSG_NUMBER = ? and DEST_BRNCH_ID = ?";
  	$result = $this->db->query($query,[$consgNumber,$destBranchId]);
  	if($result->num_rows() > 0){
  		return $result->result_array()[0];
    } else {
  		return false;
    }
  }

  public function checkBookingDataIsAvailableForOPF($consgNumber) {
    $query = "select BOOKING_ID from dtdc_f_booking where consg_number = ?";
    $result = $this->db->query($query,[$consgNumber]);
    return ($result->num_rows() > 0);
  }

  public function getFrachiseeWalletBalance($input)
  {
       // this is for test server
       if($input['tokenNumber'] == 'Axc89318420191312'){
            $make_call = $this->callAPIFrWallet('https://fruat.dtdc.com/WalletAPI_UAT/WalletAPI_UAT', json_encode($input));//https://fruat.dtdc.com/WalletAPI_UAT/WalletAPI_UAT
       }else{
          //this is for live server
          $make_call = $this->callAPIFrWallet('https://frapp.dtdc.com/Wallet_CashAndCarry/WalletAPI_CashNCarry', json_encode($input));//https://fruat.dtdc.com/WalletAPI_UAT/WalletAPI_UAT
       }
      $response = json_decode($make_call, true);
      return $response;
  }
  
    public function getRate($input){
        // Here we're calculating rate a/c to weight
        $make_call = $this->callAPI('http://bulkcn.dtdc.com/ctbs-rate-calculation/rateCalculation/v1/rate.do', json_encode($input));
        //removedOn2ndJan2020 http://billing.dtdc.com/ctbs-rate-calculation/rateCalculation/v1/rate.do
        //http://billingtest.ctbsplus.dtdc.com/ctbs-rate-calculation/rateCalculation/v1/rate.do
       // $make_call = $this->callAPI('http://billingtest.ctbsplus.dtdc.com/ctbs-rate-calculation/rateCalculation/v1/rate.do', json_encode($input));//http://billingtest.ctbsplus.dtdc.com/ctbs-rate-calculation/rateCalculation/v1/rate.do
        $response = json_decode($make_call, true);
        return $response;
    }

    public function deductFranchiseeWalletBalance($input){
      // this is for test server
      if($input['tokenNumber'] == 'Axc89318420191312'){
            $make_call = $this->callAPIDedut('https://fruat.dtdc.com/WalletAPI_UAT/WalletAPI_UAT', json_encode($input));//https://fruat.dtdc.com/WalletAPI_UAT/WalletAPI_UAT
      }else{
            // this is for live server
            $make_call = $this->callAPIDedut('https://frapp.dtdc.com/Wallet_CashAndCarry/WalletAPI_CashNCarry', json_encode($input));//https://fruat.dtdc.com/WalletAPI_UAT/WalletAPI_UAT
      }
        $response = json_decode($make_call, true);
        return $response;
    }

    public function callAPIFrWallet($url, $data){

        $curl = curl_init();
      //  $headers= array('Accept: application/json','Content-Type: application/json');
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        curl_setopt($curl, CURLOPT_URL, $url);

        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
       // curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($curl);
        if(!$result){die("Connection Failure");}
        curl_close($curl);
        return $result;
    }

    public function callAPI($url, $data){

        $curl = curl_init();
        $headers= array('Accept: application/json,','Content-Type: application/json');
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        curl_setopt($curl, CURLOPT_URL, $url);

        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($curl);
        if(!$result){die("Connection Failure");}
        curl_close($curl);
        return $result;
    }

    public function callAPIDedut($url, $data){

        $curl = curl_init();
        //$headers= array('Accept: text/html,','Content-Type: application/json');
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        curl_setopt($curl, CURLOPT_URL, $url);

        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        //curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($curl);
        if(!$result){die("Connection Failure");}
        curl_close($curl);
        return $result;
    }

    public function CNCRemarkPenalitySave($input,$apidata){

      $insert_data = [
        'BILLING_REMARKS' => $input['franchiseeCode'],
        'PENALTY_CHARGE' => $apidata['additionalTs'],
        'MISC_CHARGE' => $apidata['miscleniousCharges'][0]['rate']
      ];

    $this->db->insert('dtdc_l_booking_cnc_log', $insert_data);

    return $this->db->insert_id();
    }

    public function bookingTsSave($additional_ts){

      $insert_data = [
              'ADDITIONAL_TS' => $additional_ts
       ];

    $this->db->insert('dtdc_f_booking_ext', $insert_data);
       return $this->db->insert_id();

    }

}
