<?php
/**
 * Created by PhpStorm.
 * User: amal
 * Date: 26/10/17
 * Time: 3:29 PM
 */

defined( 'BASEPATH' ) OR exit( 'No direct script access allowed' );

class Booking_model extends CI_Model { 

	public $date;
	public $time;
	public $datetime;
	public $fullTime;

    //live version api
	public $tokenNumber = 'cashNcarry89318420191312';//Axc89318420191312
    public $apiPassword = 'wallet@live';//wallet@test
    
    //test version api
    // public $tokenNumber = 'Axc89318420191312';
	// public $apiPassword = 'wallet@test'; 


    public function __construct() {
        # code...
        parent::__construct();
        $dateObj        = new DateTime( 'now', new DateTimeZone( 'Asia/Kolkata' ) );
        $this->date     = $dateObj->format( 'Y-m-d' );
        $this->time     = $dateObj->format( 'H:i' );
        $this->fullTime = $dateObj->format( 'H:i:s' );
        $this->datetime = $dateObj->format( 'Y-m-d H:i:s' );
    }

    public function checkAirwayBillNumberIsExists( $awb_number ) {
        $sql   = "SELECT * FROM dtdc_f_booking WHERE CONSG_NUMBER = ?";
        $query = $this->db->query( $sql, [ $awb_number ] );

        return ( $query->num_rows() > 0 ) ? true : false;

    }

    public function getAwbNumberDetailsFromSpecialCustomerData( $awb_number, $hub_type, $hub_code ) {
        $sql   = "SELECT * FROM dtdc_f_spl_cust_data WHERE CONSG_NUMBER = ? AND consg_status = 'A'";
        $query = $this->db->query( $sql, [ $awb_number ] );
        if ( $query->num_rows() > 0 ) {
            return $query->result_array()[0];
        } else {
            return false;
        }
    }

    public function getCentralSplCustomerData($awb_number){

        $connect = new Connection_model();
        $connect->central();
      
        $sql = "SELECT
                        NO_OF_PIECES,INVOICE_VALUE,REF_NUMBER,EWB_NUMBER,COD_AMOUNT,FOD_AMOUNT,
                        MODE_OF_COLLECTION,INSURED,INSURED_BY,BREADTH,LENGTH,HEIGHT,VOLUMETRIC_WGHT,
                        WEIGHT,SHIPMENT_TYPE,CUSTOMER_ID,PINCODE,COMMODITY_ID,SERVICE_TYPE,VAS_PRODUCT,VER_TYPE,CUSTOMER_BRANCH
                FROM
                        dtdc_f_spl_cust_data
                WHERE
                        CONSG_NUMBER = ? AND consg_status = 'A'";

        $query = $this->db->query( $sql, [ $awb_number ] );

        if ( $query->num_rows() > 0 ) {
            return $query->result_array()[0];
        } else {
            return false;
        }

    }


    public function getAwbNumberDetailsForFranchisee( $awb_number ) {


        // $sql_bkp = "SELECT goodsissue1_.franchisee_id, goodsissue1_.customer_id, franchisee2_.business_name, franchisee2_.franchisee_code
        //      	FROM dtdc_f_goods_issue_item_detl goodsissue0_, dtdc_f_goods_issue goodsissue1_, dtdc_d_franchisee franchisee2_
        //      	WHERE goodsissue0_.GOODS_ISSUE_ID=goodsissue1_.GOODS_ISSUE_ID
        //      	AND goodsissue1_.franchisee_id=franchisee2_.franchisee_id
        //      	AND (
        //      	? BETWEEN goodsissue0_.START_SL_NUMBER
        //      	AND goodsissue0_.END_SL_NUMBER)
        //      	AND franchisee2_.CUR_STATUS='A'
        //      	AND franchisee2_.CLOSED_STATUS = 'N'
        //      	AND goodsissue1_.ISSUE_DOCUMENT_DATE <= ?
        //      	AND goodsissue1_.FRANCHISEE_ID IS NOT NULL
        //      	AND length(goodsissue0_.START_SL_NUMBER) = length(?)
        //      	AND goodsissue0_.RECORD_STATUS='A'
        //      	ORDER BY goodsissue1_.ISSUE_DOCUMENT_DATE DESC";

        // $sql = "SELECT goodsissue1_.franchisee_id, goodsissue1_.customer_id, franchisee2_.business_name, franchisee2_.franchisee_code,
        //         goodsissue1_.ISSUE_DOCUMENT_DATE, franchisee2_.revenue_category, franchisee2_.parent_fr_code, franchisee2_.online_booking
        //         FROM dtdc_f_goods_issue_item_detl goodsissue0_, dtdc_f_goods_issue goodsissue1_, dtdc_d_franchisee franchisee2_
        //         WHERE ? BETWEEN goodsissue0_.START_SL_NUMBER AND goodsissue0_.END_SL_NUMBER
        //         AND length(goodsissue0_.START_SL_NUMBER) = 9
        //         AND goodsissue0_.RECORD_STATUS='A'
        //         AND goodsissue0_.GOODS_ISSUE_ID=goodsissue1_.GOODS_ISSUE_ID
        //         AND goodsissue1_.franchisee_id=franchisee2_.franchisee_id
        //         AND goodsissue1_.ISSUE_DOCUMENT_DATE <= curdate()
        //         AND goodsissue1_.FRANCHISEE_ID IS NOT NULL
        //         AND franchisee2_.CUR_STATUS='A'
        //         AND franchisee2_.CLOSED_STATUS = 'N'
        //         ORDER BY goodsissue1_.ISSUE_DOCUMENT_DATE DESC";

        $startCon = substr($awb_number, 0, 3);
        $startConsg = "$startCon%"; 

        $sql = "SELECT goodsissue1_.franchisee_id, goodsissue1_.customer_id, franchisee2_.business_name, franchisee2_.franchisee_code,
        goodsissue1_.ISSUE_DOCUMENT_DATE, franchisee2_.revenue_category, franchisee2_.parent_fr_code, franchisee2_.online_booking
        FROM dtdc_f_goods_issue_item_detl goodsissue0_, dtdc_f_goods_issue goodsissue1_, dtdc_d_franchisee franchisee2_
        WHERE ? BETWEEN goodsissue0_.START_SL_NUMBER AND goodsissue0_.END_SL_NUMBER
and goodsissue0_.START_SL_NUMBER like ?
        AND length(goodsissue0_.START_SL_NUMBER) = 9
        AND goodsissue0_.RECORD_STATUS='A'
        AND goodsissue0_.GOODS_ISSUE_ID=goodsissue1_.GOODS_ISSUE_ID
        AND goodsissue1_.franchisee_id=franchisee2_.franchisee_id
        AND goodsissue1_.ISSUE_DOCUMENT_DATE <= curdate()
        AND goodsissue1_.FRANCHISEE_ID IS NOT NULL
        AND franchisee2_.CUR_STATUS='A'
        AND franchisee2_.CLOSED_STATUS = 'N'
        ORDER BY goodsissue1_.ISSUE_DOCUMENT_DATE DESC";
                

        $query = $this->db->query( $sql,[$awb_number, $startConsg] );
 
        if ( $query->num_rows() > 0 ) {
            $result = $query->result_array()[0];
            $newRoMappingResult = $this->getTheNewROmappingForFranchisee($result['franchisee_id']);
            if($newRoMappingResult) {
                $result['franchisee_id'] = $newRoMappingResult['franchisee_id'];
                $result['business_name'] = $newRoMappingResult['business_name'];
                $result['franchisee_code'] = $newRoMappingResult['franchisee_code'];
                $result['online_booking'] = $newRoMappingResult['online_booking'];
            }
            return $result;
        } else {
            return false;
        }

    }

    public function getTheNewROmappingForFranchisee($oldFranchiseeId) {
        $sql = "select franchisee_id, business_name, franchisee_code, online_booking from dtdc_d_franchisee where closed_status <> 'Y' and franchisee_id = (select NEW_ID from new_ro_mapping where OLD_ID = ? and TYPE = 'FR')";
        $query = $this->db->query( $sql, array($oldFranchiseeId));
        if ( $query->num_rows() > 0 ) {
            return $query->result_array()[0];
        } else {
            return false;
        }
    }


    public function checkGaStatusForGSeriesAwbNumber( $franchisee_id ) {
        $sql   = "select FRANCHISEE_ID from dtdc_d_franchisee where FRANCHISEE_ID = ? and GA = 'Y'";
        $query = $this->db->query( $sql, array( $franchisee_id ) );

        return ( $query->num_rows() > 0 ) ? 0 : 1;
    }

    public function getAwbNumberDetailsForCustomer( $awb_number ) {

        
        // $sql = "SELECT goodsissue1_.customer_id, customer2_.business_name, customer2_.customer_code
        //         FROM dtdc_f_goods_issue_item_detl goodsissue0_, dtdc_f_goods_issue goodsissue1_, dtdc_d_customer customer2_
        //         WHERE goodsissue0_.GOODS_ISSUE_ID=goodsissue1_.GOODS_ISSUE_ID
        //         AND goodsissue1_.customer_id=customer2_.customer_id
        //         AND (? BETWEEN goodsissue0_.START_SL_NUMBER AND goodsissue0_.END_SL_NUMBER)
        //         AND customer2_.CUR_STATUS='A'
        //         AND goodsissue1_.ISSUE_DOCUMENT_DATE <= ?
        //         AND goodsissue1_.CUSTOMER_ID IS NOT NULL
        //         AND length(goodsissue0_.START_SL_NUMBER) = length(?)
        //         AND goodsissue0_.RECORD_STATUS='A'
        //         ORDER BY goodsissue1_.ISSUE_DOCUMENT_DATE DESC";

        $startCon = substr($awb_number, 0, 3);
        $startConsg = "$startCon%"; 
        $sql = "SELECT goodsissue1_.customer_id, customer2_.business_name, customer2_.customer_code
               FROM dtdc_f_goods_issue_item_detl goodsissue0_, dtdc_f_goods_issue goodsissue1_, dtdc_d_customer customer2_
               WHERE goodsissue0_.GOODS_ISSUE_ID=goodsissue1_.GOODS_ISSUE_ID
               AND goodsissue1_.customer_id=customer2_.customer_id
               AND (? BETWEEN goodsissue0_.START_SL_NUMBER AND goodsissue0_.END_SL_NUMBER)
               AND customer2_.CUR_STATUS='A'
               and goodsissue0_.START_SL_NUMBER like ?
               AND goodsissue1_.ISSUE_DOCUMENT_DATE <= ?
               AND goodsissue1_.CUSTOMER_ID IS NOT NULL
               AND length(goodsissue0_.START_SL_NUMBER) = length(?)
               AND goodsissue0_.RECORD_STATUS='A'
               ORDER BY goodsissue1_.ISSUE_DOCUMENT_DATE DESC ";

        $query = $this->db->query( $sql, [$awb_number, $startConsg, $this->date, $awb_number ] );

        if ( $query->num_rows() > 0 ) {
            return $query->result_array()[0];
        } else {
            return false;
        }

    }

    public function getCustomerDetailsFromFranchisee( $franchisee_id ) {
        $sql   = "SELECT customer_id, customer_code, business_name FROM dtdc_d_customer WHERE cur_status='A' AND franchisee_id = ?";
        $query = $this->db->query( $sql, [ $franchisee_id ] );
        if ( $query->num_rows() > 0 ) {
            return $query->result_array();
        } else {
            return [];
        }

    }


    public function getCustomerDetailsFromCustomerId( $customer_id ) {
        $sql   = "SELECT CUSTOMER_ID, CUSTOMER_CODE, BUSINESS_NAME FROM dtdc_d_customer WHERE CUSTOMER_ID = ?";
        $query = $this->db->query( $sql, [ $customer_id ] );
        if ( $query->num_rows() > 0 ) {
            return $query->result_array()[0];
        } else {
            return [];
        }

    }

    public function getPincodeDetails( $pincode ) {
        $sql = "SELECT citydo3_.CITY_CODE AS col_0_0_,
        areado0_.CITY_ID AS DEST_CITY_ID,
        pincodedo1_.PINCODE_ID AS DEST_PINCODE_ID,
        zonedo7_.ZONE_CODE AS col_3_0_,
        statedo6_.STATE_NAME AS col_4_0_,
        areado0_.AREA_ID AS col_5_0_,
        pincodedo1_.SERVICEABLE AS col_6_0_,
        areado0_.AREA_TYPE AS col_7_0_,
        citydo3_.CITY_TYPE AS col_8_0_,
        pincodedo1_.PIN_CODE_TYPE AS col_9_0_,
        pincodedo1_.OFFICE_ID AS col_10_0_,
        citydo3_.CITY_NAME AS DEST_CITY_NAME,
        pincodedo1_.NONSERVICEABLE_SPL_PIN AS col_12_0_,
            officedo13_.OFFICE_NAME AS col_13_0_,
        pincodedo1_.PINCODE_GICA AS col_14_0_,
        pincodedo1_.PINCODE_RLG AS col_15_0_,
        pincodemap2_.LITE_SERVICEABLE AS col_16_0_,
        officedo13_.REPORT_REGOFF_ID AS col_17_0_,
        pincodedo1_.PIN_CODE AS PIN_CODE,
        pincodedo1_.WEIGHT_KGS AS WEIGHT_KGS,
        pincodedo1_.PER_PIECE AS PER_PIECE,
        pincodedo1_.PIN_CODE AS PIN_CODE
            FROM
            dtdc_d_area areado0_,
            dtdc_d_city citydo3_,
        dtdc_d_district districtdo5_,
            dtdc_d_state statedo6_,
            dtdc_d_zone zonedo7_ CROSS
            JOIN
            dtdc_d_pincode pincodedo1_, dtdc_d_office officedo13_ CROSS
            JOIN
        dtdc_d_pincode_mapping pincodemap2_
            WHERE
        areado0_.CITY_ID=citydo3_.CITY_ID
            AND citydo3_.DISTRICT_ID=districtdo5_.DISTRICT_ID
            AND districtdo5_.STATE_ID=statedo6_.STATE_ID
            AND statedo6_.ZONE_ID=zonedo7_.ZONE_ID
            AND pincodedo1_.OFFICE_ID=officedo13_.OFFICE_ID
            AND areado0_.PINCODE_ID=pincodedo1_.PINCODE_ID
            AND pincodedo1_.PINCODE_ID=pincodemap2_.PINCODE_ID
            AND areado0_.SERVICEABLE='Y'
            AND pincodemap2_.LITE_SERVICEABLE = 'Y'
            AND pincodedo1_.PIN_CODE= ? LIMIT 1";

        $query = $this->db->query( $sql, [ $pincode ] );

        if ( $query->num_rows() > 0 ) {
            return $query->result_array()[0];
        } else {
            return false;
        }
    }

    public function getWeightKGSDtls( $product_type ) {

		$sql = "select WEIGHT_KGS,PER_PIECE from dtdc_d_product_weight_limit WHERE PRODUCT_CODE = ? ";
		$query = $this->db->query( $sql, [ $product_type ] );
		return $query->result_array();
	}


    public function getPincodeDetailsForPep( $pincode ) {
        $sql = "SELECT citydo3_.CITY_CODE AS col_0_0_,
        areado0_.CITY_ID AS DEST_CITY_ID,
        pincodedo1_.PINCODE_ID AS DEST_PINCODE_ID,
        citydo3_.CITY_NAME AS DEST_CITY_NAME,
        pincodedo1_.PIN_CODE AS PIN_CODE,
        pincodedo1_.WEIGHT_KGS AS WEIGHT_KGS,
        pincodedo1_.PER_PIECE AS PER_PIECE,
        pincodedo1_.PIN_CODE AS PIN_CODE
            FROM
            dtdc_d_area areado0_,
            dtdc_d_city citydo3_,
        dtdc_d_district districtdo5_,
            dtdc_d_state statedo6_,
            dtdc_d_zone zonedo7_ CROSS
            JOIN
            dtdc_d_pincode pincodedo1_, dtdc_d_office officedo13_ CROSS
            JOIN
        dtdc_d_pincode_mapping pincodemap2_
            WHERE
        areado0_.CITY_ID=citydo3_.CITY_ID
            AND citydo3_.DISTRICT_ID=districtdo5_.DISTRICT_ID
            AND districtdo5_.STATE_ID=statedo6_.STATE_ID
            AND statedo6_.ZONE_ID=zonedo7_.ZONE_ID
            AND pincodedo1_.OFFICE_ID=officedo13_.OFFICE_ID
            AND areado0_.PINCODE_ID=pincodedo1_.PINCODE_ID
            AND pincodedo1_.PINCODE_ID=pincodemap2_.PINCODE_ID
            AND areado0_.SERVICEABLE='Y'
            AND pincodedo1_.PIN_CODE = ? LIMIT 1";

		$query = $this->db->query( $sql, [ $pincode ] );

		if ( $query->num_rows() > 0 ) {
			return $query->result_array()[0];
		} else {
			return false;
		}
	}

	public function getServices( $character ) {
		$sql = "SELECT s.service_id, service_code, service_name FROM dtdc_d_service_channeltype c, dtdc_d_service s WHERE c.service_id = s.service_id AND cn_series = ?";

		$query = $this->db->query( $sql, [ $character ] );

		return $query->result_array();
	}

	public function getRiskCover( $customer_code ) {
		$sql = "SELECT RISK_COVER FROM dtdc_d_customer WHERE customer_code= ?";

		$query = $this->db->query( $sql, [ $customer_code ] );

		if ( $query->num_rows() > 0 ) {
			return $query->result_array()[0];
		} else {
			return false;
		}
	}

	public function getMaximumInvoiceValue( $customer_id, $service_id ) {
		$sql   = "SELECT d.* FROM dtdc_d_risk_surcharge h, dtdc_d_risk_surcharge_detl d WHERE h.RISK_SURCHARGE_ID=d.RISK_SURCHARGE_ID AND customer_id = ? AND service_id= ? AND h.insured_by='C' AND ? BETWEEN effective_from_date AND effective_to_date";
		$query = $this->db->query( $sql, [ $customer_id, $service_id, $this->date ] );
		if ( $query->num_rows() > 0 ) {
			return $query->result_array()[0];
		} else {
			return false;
		}
    }

    public function saveDoxBookingCNC( $data ) {
        $dox_consignments = $data['doxConsignments'];
        
        $total_saved = 0;
                
		foreach ( $dox_consignments as $consignment ) {

            $cashAndCarryFrCode = $consignment['cashAndCarryFrCode'];
            $cashAndCarryPrice = $consignment['cashAndCarryPrice'];
            $miscleniousCharges = $consignment['miscleniousCharges'];
            if(!$this->checkTheCNCFrWalletbalance($cashAndCarryFrCode, $cashAndCarryPrice)) {
                return ['status' => 0, 'message' => 'This Cash and Carry Franchisee do not have sufficient wallet balance to save the data'];
            }
            $isDebited = $this->doTheHenceforthLogicsForCashAndCarry($cashAndCarryFrCode, $cashAndCarryPrice,  $consignment['consignmentNumber'], $consignment['destinationPincodeId'], $cashAndCarryFrCode,$consignment['additionalTs'],$consignment['miscleniousCharges']);

            if(!$isDebited) {
                return ['status' => 0, 'message' => $consignment['consignmentNumber'].' - Failed to Book this consignment number since Debit failed from Franchisee Wallet'];
            }

            $input['franchiseeCode'] = $consignment['cashAndCarryFrCode'];
         
            $this->insertIntoDTDCFDSRRevenue($consignment['consignmentNumber'], $miscleniousCharges[0]['rate'], $miscleniousCharges[0]['amountType']);

            $validation = $consignment['validation'];
            if($validation == null){
               $validation =  $this->getVersionType($consignment['consignmentNumber']);
            }

			$insert_data = [
			 	'FINAL_WEIGHT'             => $consignment['finalWeight'],
				'CONSGMNT_STATUS'          => 'Booked',
				'WEIGHING_TYPE'            => 'M',
				'NO_OF_PIECES'             => 1,
				'BOOKING_DATE'             => $this->date,
				'BOOKING_TIME'             => $this->fullTime,
				'DOX_AMOUNT'               => 0,
				'NON_DOX_AMOUNT'           => 0,
				'AMOUNT'                   => 0,
				'ACTUAL_WEIGHT'            => $consignment['finalWeight'],
				'INS_AMOUNT'               => 0,
				'CONSG_NUMBER'             => $consignment['consignmentNumber'],
				'SECURITY_POUCH'           => 0,
				'FUEL_SURCHARGE_PERC'      => 0,
				'RISK_SURCHG_AMT'          => 0,
				'SERV_CHRG_AMT'            => 0,
                'CUST_REF_NO'              => $consignment['referenceNumber'],
                'PICKUP_TIME'              => $consignment['customer_branch'],
				'BOOKING_DIVISION'         => 'DD',
				'CHANNEL_TYPE_ID'          => $data['channelTypeId'],
				'DEST_CITY_ID'             => $consignment['destinationCityId'],
				'DEST_PINCODE_ID'          => $consignment['destinationPincodeId'],
				'CUSTOMER_ID'              => $consignment['customerId'],
				'MODE_ID'                  => $consignment['modeId'],
				'PRODUCT_ID'               => $this->getProductIdFromServiceId( $consignment['serviceId'] ),
				'DOCUMENT_ID'              => 1,
				'SERVICE_ID'               => $consignment['serviceId'],
				'FRANCHISEE_ID'            => $consignment['franchiseId'],
				'BRNCH_OFF_ID'             => $data['branchOfficeId'],
				'EMPLOYEE_ID'              => $data['employeeId'],
				'DB_SERVER'                => 'N',
				'BOOKING_TYPE'             => $data['bookingType'],
				'UPDATED_FROM_PROCESS'     => 'MOP',
				'TRANS_CREATE_DATE'        => $this->date,
				'TRANS_LAST_MODIFIED_DATE' => $this->date,
				'USER_ID'                  => $data['userId'],
				'SPECIAL_CHARGE'           => 0,
				'ADDITIONAL_CHARGE'        => 0,
				'COMMERCAIL_TAX'           => 0,
				'CESS_TAX'                 => 0,
				'EDUCATION_TAX'            => 0,
				'TS_AMOUNT'                => 0,
				'NODE_ID'                  => $data['nodeId'],
				'di_flag'                  => 'N',
				'CHANGED_AFTER_BILLING'    => 'N',
				'BILLING_STATUS'           => 'TBB',
				'ACTUAL_BRANCH_ID'         => $this->getActualBranchIdFromFranchiseeIdOrCustomerId( $consignment['franchiseId'], $consignment['customerId'], $data['bookingType'] ),
				'RECORD_ENTRY_DATETIME'    => $this->datetime,
				'VOL_WT_MAND'              => 'N',
				'CONSG_ENTRY_TYPE'         => $consignment['consignmentEntryType'],
				'DEST_BRANCH_CODE'         => $consignment['destBranchCode'],
				'WAR_DATE'                 => $data['warDate'],
				'TRANS_STATUS'             => 'A',
				'DD_FLAG'                  => 'N',
				'VALIDATION'               => $validation,
				// 'VALIDATION'               => $consignment['validation'],
                'FRANCH_MINF_NUMBER'       => $this->findFranchiseeManifestNumber( $consignment['franchiseId'] ),
                'SERV_CHRG_AMT'            => $consignment['serviceCharge'],
                'RISK_SURCHG_AMT'          => $consignment['riskSurcharge'],
                'FUEL_SURCHARGE_PERC'      => $consignment['fscCharge'],
                'PDN_CHARGES'              => $consignment['pdnCharges'],
                'STD_RATE_ID'              => $consignment['stdRateId'],
                'TS_AMOUNT'                => $consignment['totalTsAmount'],
                'AMOUNT'                   => $consignment['chargableAmount']
			];
			if ( $this->db->insert( 'dtdc_f_booking', $insert_data ) ) {
                $total_saved ++;
                $this->insertIntoDTDCFBookingExt($consignment['consignmentNumber'], $cashAndCarryPrice, 'Y');
                $this->updateBookingCNCLog($consignment['consignmentNumber']);
            }
            
           
		}

        return ['status' => 1, 'totalSaved' => $total_saved, 'message' => 'Saved successfully'];
	}
    
    public function saveNonDoxBooking( $data ) {

		$non_dox_shipments = $data['nonDoxShipments'];

		$total_saved = 0;

		for ( $i = 0; $i < count( $non_dox_shipments ); $i ++ ) {

			$input_data = $non_dox_shipments[ $i ];

			$consignments = $input_data['consignments'];

            $cashAndCarryFlag = $input_data['cashAndCarryFlag'];
						$consignmentStatus = 'BOOKED';
            if($cashAndCarryFlag) {
								$consignmentStatus = 'APPROVED';
                $cashAndCarryFrCode = $input_data['cashAndCarryFrCode'];
                $cashAndCarryPrice = $input_data['cashAndCarryPrice'];
                $miscleniousCharges = $input_data['miscleniousCharges'];
                $additionalTs  =  $input_data['additionalTs'];
                if(!$this->checkTheCNCFrWalletbalance($cashAndCarryFrCode, $cashAndCarryPrice)) {
                    return ['status' => 0, 'message' => 'This Cash and Carry Franchisee do not have sufficient wallet balance to save the data'];
                }
                $isDebited = $this->doTheHenceforthLogicsForCashAndCarry($cashAndCarryFrCode, $cashAndCarryPrice,  $input_data['cashAndCarryConsgNumber'], $input_data['destinationPincodeId'], $input_data['childFrCode'],$additionalTs,$miscleniousCharges);

                if(!$isDebited) {
                    return ['status' => 0, 'message' => 'Failed to Book this consignment number since Debit failed from Franchisee Wallet'];
                }
              //  foreach ( $miscleniousCharges as $miscleniousCharge ) {

                    $this->insertIntoDTDCFDSRRevenue($input_data['cashAndCarryConsgNumber'], $miscleniousCharges[0]['rate'], $miscleniousCharges[0]['amountType']);
               // }

            }
            $validation = $input_data['validation'];
            if($validation == null){
                $validation =  $this->getVersionType($input_data['cashAndCarryConsgNumber']);
            }

            
            
			if ( $consignments[0]['eWay'] === 1 && ! $this->getIsEwbNumberIsSavedInBranch( $input_data['branchOfficeId'], $consignments[0]['ewbConsgNumber'] ) ) {

				//check if data is there in dtdc_f_spl_cust_data

				$special_customer_data = array_change_key_case( $this->getEwayDetailsFromSpecialCustomerTable( $consignments[0]['ewbConsgNumber'] ), CASE_UPPER );

				if ( count( $special_customer_data ) === 0 ) {
					$special_customer_data['EWB_NUMBER']     = null;
					$special_customer_data['GST_REG_STATUS'] = null;
					$special_customer_data['INVOICE_NUMBER'] = null;
					$special_customer_data['EWB_STATUS']     = 'N';
					$special_customer_data['RECORD_STATUS']  = 'A';
					$special_customer_data['SENDERGSTIN']    = null;
					$special_customer_data['INVOICE_DATE']   = null;
					$special_customer_data['RECEIVERGSTIN']  = null;
					$special_customer_data['TOTALVALUE']     = null;
					$special_customer_data['CGSTVALUE']      = null;
					$special_customer_data['SGSTVALUE']      = null;
					$special_customer_data['IGSTVALUE']      = null;
					$special_customer_data['CESSVALUE']      = null;
					$special_customer_data['TRANSMODE']      = null;
					$special_customer_data['TRANSDISTANCE']  = null;
					$special_customer_data['HSN_CODE']       = null;
				}

				$insert_data = [
					'CONSG_NUMBER'      => $consignments[0]['ewbConsgNumber'],
					'EWB_NUMBER'        => $consignments[0]['ewbNumber'],
					'DECLARED_VALUE'    => $input_data['declaredValue'],
					'TRANS_OFFICE_ID'   => $input_data['branchOfficeId'],
					'USERID'            => $input_data['userId'],
					'NODEID'            => $input_data['nodeId'],
					//'EWB_NUMBER' => $special_customer_data['EWB_NUMBER'],
					'GST_REG_STATUS'    => $special_customer_data['GST_REG_STATUS'],
					'INVOICE_NUMBER'    => $special_customer_data['INVOICE_NUMBER'],
					'EWB_STATUS'        => 'N',
					'RECORD_STATUS'     => 'A',
					'SenderGstin'       => $special_customer_data['SENDERGSTIN'],
					'INVOICE_DATE'      => $special_customer_data['INVOICE_DATE'],
					'ReceiverGstin'     => $special_customer_data['RECEIVERGSTIN'],
					'totalValue'        => $special_customer_data['TOTALVALUE'],
					'cgstValue'         => $special_customer_data['CGSTVALUE'],
					'sgstValue'         => $special_customer_data['SGSTVALUE'],
					'igstValue'         => $special_customer_data['IGSTVALUE'],
					'cessValue'         => $special_customer_data['CESSVALUE'],
					'transMode'         => $special_customer_data['TRANSMODE'],
					'transDistance'     => $special_customer_data['TRANSDISTANCE'],
					'HSN_CODE'          => $special_customer_data['HSN_CODE'],
					'TRANS_CREATE_DATE' => $this->datetime,
					'MOD_DATE_TIME'     => $this->datetime,
					'PROCESS'           => $input_data['bookingType'],
					'RECEIVERPLACE'     => $input_data['receiverPlace'],
					'RECEIVERPINCODE'   => $input_data['receiverPinCode']
				];

				$this->db->insert( 'dtdc_f_ewb_info', $insert_data );
			}

			if ( $input_data['weight_limit_status'] == 1 || $input_data['weight_limit_status'] == 2 ) {
				$weight_limit_data = $input_data['weight_limit_data'];
				$insert_data       = [
					'BRANCH_OFF_ID'        => $weight_limit_data['branchOfficeId'],
					'CONSG_NUMBER'         => $weight_limit_data['consgNumber'],
					'BOOKING_DATE'         => $this->date,
					'BOOKING_TYPE'         => $weight_limit_data['bookingType'],
					'PRODUCT_TYPE'         => $weight_limit_data['productType'],
					'ACTUAL_WEIGHT'        => $weight_limit_data['actualWeight'],
					'CONFIRMED_WEIGHT'     => $weight_limit_data['confirmedWeight'],
					'CONFIRMED_BY'         => $weight_limit_data['userCode'],
					'CONFIRMATION_REMARKS' => $input_data['weight_limit_status'] == 1 ? 'exceeded suggested weight' : 'exceeded maximum weight',
					'BRANCH_OFF_CODE'      => $weight_limit_data['branchofficeCode'],
					'CAPTURED_WEIGHT'      => $weight_limit_data['captured_weight'],
					'CONFIRMATION_TAT'     => $this->getConfirmationTatDate()

				];

				$this->db->insert( 'dtdc_f_weight_limit_info', $insert_data );

			}
			$cnt          = 0;
            $consignee_id = $consigner_id = null;
            $dsr_mobile = null;
			foreach ( $consignments as $consignment ) {
                
				if ( $input_data['validation'] == 'EBK') {

                    $pass_consg_number =  $consignment['parentConsignmentNumber'] ;
                    if($pass_consg_number == null){
                       $pass_consg_number = $consignment['consignmentNumber'] ;
                    }
                    
                    $data = $this->getCompleteSoftEbkData( $pass_consg_number );
                                  
					if ( count( $data ) > 0 ) {
                        $dsr_mobile =  $data[0]['ASMOBILE_NO'];
                        if($cnt == 0){
                            $consignee_id = $this->insertIntoConsigneeTable( $data[0] );
                            $this->insertIntoConsigneeAddressTable( $data[0], $consignee_id );
                            $consigner_id = $this->insertIntoConsignerTable( $data[0] );
                            $this->insertIntoConsignerAddressTable( $data[0], $consigner_id );
                        }
					}
                }
                $pickup_time = null;
                if($consignment['parentConsignmentNumber'] == null){
                    $pickup_time = $input_data['customer_branch'];

                }
                $cnt ++;
               

				$insert_data = [
					'VOLUMETRIC_WGHT'          => $consignment['volumetricWeight'],
					'BREADTH'                  => $consignment['breadth'],
					'LENGTH'                   => $consignment['length'],
					'HEIGHT'                   => $consignment['height'],
					'DESC_GOODS'               => $consignment['goodsDescription'],
					'FINAL_WEIGHT'             => $consignment['finalWeight'],
					'CONSGMNT_STATUS'          => $consignmentStatus,
					'WEIGHING_TYPE'            => 'M',
					'NO_OF_PIECES'             => $consignment['numberOfPieces'],
					'BOOKING_DATE'             => $this->date,
					'BOOKING_TIME'             => $this->fullTime,
					'COD_AMOUNT'               => $consignment['codAmount'],
					'DOX_AMOUNT'               => 0,
					'NON_DOX_AMOUNT'           => 0,
					'AMOUNT'                   => 0,
					'ACTUAL_WEIGHT'            => $consignment['actualWeight'],
					'PARENT_CONSG_NO'          => $consignment['parentConsignmentNumber'],
					'FOD_AMOUNT'               => $consignment['fodAmount'],
					'INSURED_BY'               => $input_data['insuredBy'],
					'INS_AMOUNT'               => 0,
					'INV_VALUE'                => $input_data['declaredValue'],
					'CONSG_NUMBER'             => $consignment['consignmentNumber'],
					'SECURITY_POUCH'           => 0,
					'FUEL_SURCHARGE_PERC'      => 0,
					'RISK_SURCHG_AMT'          => 0,
					'SERV_CHRG_AMT'            => 0,
					'MODE_OF_COLLECTION'       => $input_data['modeOfCollection'],
					'CUST_REF_NO'              => $input_data['referenceNumber'],
					'BOOKING_DIVISION'         => 'DD',
					'CHANNEL_TYPE_ID'          => $input_data['channelTypeId'],
					'DEST_CITY_ID'             => $input_data['destinationCityId'],
					'DEST_PINCODE_ID'          => $input_data['destinationPincodeId'],
					'CUSTOMER_ID'              => $input_data['customerId'],
					'MODE_ID'                  => $input_data['modeId'],
					'PRODUCT_ID'               => $this->getProductIdFromServiceId( $input_data['serviceId'] ),
					'DOCUMENT_ID'              => 2,
					'SERVICE_ID'               => $input_data['serviceId'],
					'FRANCHISEE_ID'            => $input_data['franchiseId'],
					'BRNCH_OFF_ID'             => $input_data['branchOfficeId'],
					'INSURED'                  => $input_data['insured'],
					'EMPLOYEE_ID'              => $input_data['employeeId'],
					'DB_SERVER'                => 'N',
					'BOOKING_TYPE'             => $input_data['bookingType'],
					'UPDATED_FROM_PROCESS'     => $input_data['updatedByProcess'],
					'VAS_PROD_CODE'            => $input_data['vasCode'],
					'TRANS_CREATE_DATE'        => $this->date,
					'TRANS_LAST_MODIFIED_DATE' => $this->date,
					'USER_ID'                  => $input_data['userId'],
					'SPECIAL_CHARGE'           => 0,
					'ADDITIONAL_CHARGE'        => 0,
					'COMMERCAIL_TAX'           => 0,
					'CESS_TAX'                 => 0,
					'EDUCATION_TAX'            => 0,
					'TS_AMOUNT'                => 0,
					'COMMODITY_ID'             => $input_data['commadityId'],
					'NODE_ID'                  => $input_data['nodeId'],
					'di_flag'                  => 'N',
					'CHANGED_AFTER_BILLING'    => 'N',
					'BILLING_STATUS'           => 'TBB',
					'CARRAIGE_DECLARED_VAL'    => $input_data['declaredValue'],
					'ACTUAL_BRANCH_ID'         => $this->getActualBranchIdFromFranchiseeIdOrCustomerId( $input_data['franchiseId'], $input_data['customerId'], $input_data['bookingType'] ),
					'RECORD_ENTRY_DATETIME'    => $this->datetime,
					'VOL_WT_MAND'              => 'N',
					'CONSG_ENTRY_TYPE'         => $input_data['consignmentEntryType'],
					'DEST_BRANCH_CODE'         => $input_data['destBranchCode'],
					'RLP_Status'               => $consignment['rlpStatus'],
					'WAR_DATE'                 => $input_data['warDate'],
					'TRANS_STATUS'             => 'A',
					'DD_FLAG'                  => 'N',
					'VALIDATION'               => $validation,
					// 'VALIDATION'               => $input_data['validation'],
					'CUT_OFF_TIME'             => $input_data['cutOffTime'],
					'FRANCH_MINF_NUMBER'       => $this->findFranchiseeManifestNumber( $input_data['franchiseId'] ),
					'CONSIGNEE_ID'             => $consignee_id,
					'CONSIGNER_ID'             => $consigner_id,
					'READ_BY_LOCAL'            => 'N',
					'REMARKS'                  => $input_data['remarks'],
					'SERV_CHRG_AMT'            => $input_data['serviceCharge'],
					'RISK_SURCHG_AMT'          => $input_data['riskSurcharge'],
					'FUEL_SURCHARGE_PERC'      => $input_data['fscCharge'],
					'PDN_CHARGES'              => $input_data['pdnCharges'],
					'STD_RATE_ID'              => $input_data['stdRateId'],
					'TS_AMOUNT'                => $input_data['totalTsAmount'],
					'AMOUNT'                   => $input_data['chargableAmount'],
                    'IN_FAVOUR_OF'             => $input_data['inFavourOf'],
                    'DSR_MOBILE'               => $dsr_mobile,
                    'PICKUP_TIME'              => $pickup_time
                    
                    
				];

				if ( $this->db->insert( 'dtdc_f_booking', $insert_data ) ) {
					$total_saved ++;
				}

			}

			if($cashAndCarryFlag) {
					$this->insertIntoDTDCFBookingExt($input_data['cashAndCarryConsgNumber'], $cashAndCarryPrice, 'Y');
					$this->updateBookingCNCLog($input_data['cashAndCarryConsgNumber']);
			} else {
                $this->insertIntoDTDCFBookingExt($input_data['cashAndCarryConsgNumber'], null, null);
            }

		}

		return ['status' => 1, 'message' => 'Successfully Booked '. $total_saved];

	}

	public function insertIntoDTDCFBookingExt($consgNumber, $walletDebitAmt, $cashAndCarryFlag){

        $insert_data = [
            'CONSG_NUMBER' => $consgNumber,
            'CASH_CARRY' => $cashAndCarryFlag,
            'RECORD_ENTRY_DATETIME' => $this->datetime,
            'WALLET_DEBIT_AMOUNT' => $walletDebitAmt
        ];

        $this->db->insert( 'dtdc_f_booking_ext', $insert_data );

    }

    

	public function checkTheCNCFrWalletbalance($cashAndCarryFrCode, $priceFromAPK){

        $data_array =  [
                        'tokenNumber' => $this->tokenNumber,
                        'apiPassword' => $this->apiPassword,
                        'requestType' => 'WALLETBALANCEAPI',
                        'fr_code' => $cashAndCarryFrCode
                        ];

        $support_model = new Support_model();
        $walletDataNow = $support_model->getFrachiseeWalletBalance($data_array);
        $walletBalance = $walletDataNow['balance'];

        if($priceFromAPK > $walletBalance) {
            return false;
        } else {
            return true;
        }

    }

    public function doTheHenceforthLogicsForCashAndCarry($cashAndCarryFrCode, $priceFromAPK, $consignNumber, $destPincodeId, $childFrCode,$additional_Ts,$miscleniousCharge) {

        $rcptno = 'T'.mt_rand(10000000, 99999999);
	    $data_ip_for_deduct_fr_wallet = [
            'tokenNumber' => $this->tokenNumber,
            'apiPassword' => $this->apiPassword,
            'requestType' => 'SPENDAPI',
            'fr_code' => $cashAndCarryFrCode,
            "process" => "BOOKINGCASHCARRY",
            "amount" => $priceFromAPK,
            "remarks" => "Booking Cash and Carry",
            "rcptno" => $rcptno,
            "child_fr_code" => $childFrCode
        ];

        $support_model = new Support_model();
        $data_op_from_deduct_wallet = $support_model->deductFranchiseeWalletBalance($data_ip_for_deduct_fr_wallet);
        $debitStatus = $this->insertDataIntoDTDCLBookingCNCLog($data_op_from_deduct_wallet, $consignNumber, $destPincodeId,$additional_Ts,$miscleniousCharge,$cashAndCarryFrCode);

        return $debitStatus;
    }

    public function insertDataIntoDTDCLBookingCNCLog($deduct_wallet_data, $consignNumber, $destPincodeId,$additional_Ts,$miscleniousCharge,$cashAndCarryFrCode){

        $debitStatus = $deduct_wallet_data['status_code'];
        if($debitStatus == 'SUCCESS') {
            $reconcileStatus = 'Y';
            $agentRefNum = $deduct_wallet_data['merchant_transaction_number'];
            $transactionId = $deduct_wallet_data['yes_bank_reference_number'];
            $tsAmount = $deduct_wallet_data['balance'];
            $description = $deduct_wallet_data['transaction_reference_number'];
            $operationalFreedom = null;
            $readByLocal = 'N';
            $isDebited = true;
        } else {
            $reconcileStatus = 'N';
            $agentRefNum = null;
            $transactionId = null;
            $tsAmount = 0;
            $description = null;
            $operationalFreedom = 'API FAILED';
            $readByLocal = 'N';
            $isDebited = false;
        }

        $insert_data = [
                         'CONSG_NUMBER' => $consignNumber,
                         'DEST_PINCODE_ID' => $destPincodeId,
                         'BOOKING_TYPE' => 'FRBOOKING',
                         'RECONCILE_STATUS' => $reconcileStatus,
                         'AGENT_REF_NO' => $agentRefNum,
                         'TRANSACTION_ID' => $transactionId,
                         'TS_AMOUNT' => $tsAmount,
                         'DESCRIPTION' => $description,
                         'OPERATION_FREEDOM' => $operationalFreedom,
                         'READ_BY_LOCAL' => $readByLocal,
                         'BILLING_REMARKS' => $cashAndCarryFrCode,
                         'PENALTY_CHARGE' => $additional_Ts,
                         'MISC_CHARGE' => $miscleniousCharge[0]['rate']

                       ];

        $this->db->insert( 'dtdc_l_booking_cnc_log', $insert_data );

        return $isDebited;
    }

    public function insertIntoDTDCFDSRRevenue($consignNumber, $rate, $amountType){

        $insert_data = [
                        'DR_CNNO' => $consignNumber,
                        'DR_AMT_TYPE' => $amountType,
                        'DR_EXTRA_AMT' => $rate,
                        'NODEID' => 'CandC',
                        'MOD_DATE' => $this->date,
                        'MOD_TIME ' => $this->time
                      ];

        $this->db->insert( 'dtdc_f_dsr_revenue', $insert_data );
    }

    public function updateBookingCNCLog($consignNumber){

        $sql =  'select BOOKING_ID from dtdc_l_booking_cnc_log where CONSG_NUMBER = ?';
        $query = $this->db->query( $sql, [ $consignNumber ] );

        if ( $query->num_rows() > 0 ) {
            $bookingId =  $query->result_array()[0]['BOOKING_ID'];
            $data = array(
                'READ_BY_LOCAL' => 'Y'
            );
            $this->db->where('BOOKING_ID', $bookingId);
            $this->db->update('dtdc_l_booking_cnc_log', $data);
        }

    }

	public function getEwayDetailsFromSpecialCustomerTable( $consg_number ) {
		$sql   = "SELECT * FROM dtdc_f_spl_cust_data WHERE consg_number = ? AND consg_status = 'A' LIMIT 1";
		$query = $this->db->query( $sql, [ $consg_number ] );

		if ( $query->num_rows() ) {
			return $query->result_array()[0];
		} else {
			return [];
		}
	}


	public function findFranchiseeManifestNumber( $franchisee_id ) {
		//make franchisee_id 5 digits
		$franchisee_id = sprintf( '%05d', $franchisee_id );

		$sql = "SELECT max(franch_minf_number) as franch_minf_number FROM
                dtdc_f_booking
                WHERE
                franch_minf_number LIKE '$franchisee_id%'
                AND franchisee_id= $franchisee_id
                AND length(franch_minf_number)=10";

        $query = $this->db->query( $sql );

        if ( $query->num_rows() ) {

            $result = $query->result_array()[0];

            $intermediate_value = (int) substr( $result['franch_minf_number'], - 5 ) + 1;

            $franchisee_manifest_number = $franchisee_id . $intermediate_value;

        } else {
            $franchisee_manifest_number = $franchisee_id . '00001';
        }

        return $franchisee_manifest_number;
    }


    protected function getProductIdFromServiceId( $service_id ) {

        $sql   = 'SELECT product_id FROM dtdc_d_service WHERE service_id = ?';
        $query = $this->db->query( $sql, [ $service_id ] );

        if ( $query->num_rows() > 0 ) {
            return $query->result_array()[0]['product_id'];
        } else {
            return null;
        }

    }

    protected function getActualBranchIdFromFranchiseeIdOrCustomerId( $franchisee_id, $customer_id, $booking_type ) {

        if ( $booking_type == 'FRBooking' ) {
            $value = $franchisee_id;
            $sql   = 'SELECT office_id FROM dtdc_d_franchisee WHERE franchisee_id = ?';
        } else if ( $booking_type == 'DPBooking' ) {
            $value = $customer_id;
            $sql   = 'SELECT office_id FROM dtdc_d_customer WHERE customer_id= ?';

        }


        $query = $this->db->query( $sql, [ $value ] );

        if ( $query->num_rows() > 0 ) {
            return $query->result_array()[0]['office_id'];
        } else {
            return null;
        }
    }

    public function getPincodeRlg( $pincode ) {
        $sql   = "SELECT PINCODE_RLG FROM dtdc_d_pincode WHERE PIN_CODE=? AND serviceable ='Y' AND  PINCODE_RLG='Y'";
        $query = $this->db->query( $sql, [ $pincode ] );

        if ( $query->num_rows() > 0 ) {
            return true;
        } else {
            return false;
        }

    }

    public function getCodServiceableStatus( $pincode_id ) {
//        $sql = "select COD_SERVICEABLE from dtdc_d_pincode_mapping where PINCODE_ID=? AND  COD_SERVICEABLE='Y'";
        $sql = " SELECT COD_SERVICEABLE, FOD_SERVICEABLE FROM dtdc_d_pincode_mapping WHERE pinCode_id = ?";

        $query = $this->db->query( $sql, [ $pincode_id ] );

        if ( $query->num_rows() > 0 ) {
            return $query->result_array()[0];
        } else {
            return false;
        }
    }

    public function getCodServiceableStatusPincode( $pincode_id, $consgNumber ) {

        $firstLetter = $consgNumber[0];

        if($firstLetter === 'V') {
            $sql = "SELECT PLUS_SERVICEABLE, BLUE_SERVICEABLE, PEC_SERVICEABLE, GREEN_SERVICEABLE FROM dtdc_d_pincode_mapping WHERE PINCODE_ID = ? ";
        } elseif ($firstLetter === 'E') {
            $sql = "SELECT PTP_SERVICEABLE FROM dtdc_d_pincode_mapping WHERE PINCODE_ID = ? ";
        }
//        $sql = "select COD_SERVICEABLE from dtdc_d_pincode_mapping where PINCODE_ID=? AND  COD_SERVICEABLE='Y'";
//        $sql = " SELECT COD_SERVICEABLE, FOD_SERVICEABLE FROM dtdc_d_pincode_mapping WHERE pinCode_id = ?";

        $query = $this->db->query( $sql, [ $pincode_id ] );

        if ( $query->num_rows() > 0 ) {
            return $query->result_array()[0];
        } else {
            return false;
        }
    }


    public function getCommodityDetailsFromCommodityId( $commodity_id ) {
        $sql = "SELECT commodity_id, commodity_name FROM dtdc_d_commodity WHERE commodity_id = ?";

        $query = $this->db->query( $sql, [ $commodity_id ] );

        if ( $query->num_rows() > 0 ) {
            return $query->result_array()[0];
        } else {
            return [];
        }

    }

    public function getServiceDetailsFromServiceCode( $service_code ) {
        $sql = "SELECT service_id, service_code, service_name FROM dtdc_d_service WHERE service_code = ? LIMIT 1";

        $query = $this->db->query( $sql, [ $service_code ] );

        if ( $query->num_rows() > 0 ) {
            return $query->result_array()[0];
        } else {
            return [];
        }

    }

    public function getVasDetailsFromServiceCode( $service_code ) {
        $sql = "SELECT SERVICE_CODE, SERVICE_NAME FROM dtdc_d_service WHERE service_type='VAS' AND MAIN_VAS_ID=1 AND SERVICE_CODE = ?";

        $query = $this->db->query( $sql, [ $service_code ] );

        if ( $query->num_rows() > 0 ) {
            return $query->result_array()[0];
        } else {
            return [];
        }

    }

    public function getCustomerDetailsFromFrIdWithAWBNumber($awb_number,$franchisee_id){

        $sql = "SELECT CUSTOMER_ID,CUSTOMER_CODE,business_name
                FROM dtdc_f_cn_stock_ctrl,DTDC_D_CUSTOMER WHERE ? BETWEEN csc_start_cnno AND csc_end_cnno
                AND CSC_CUST_CODE=CUSTOMER_CODE
                AND FRANCHISEE_ID= ?
                AND DTDC_D_CUSTOMER.CUR_STATUS='A'
                AND dtdc_f_cn_stock_ctrl.STATUS='A'
                ORDER BY csc_iss_date DESC LIMIT 1";

        $query = $this->db->query( $sql, [ $awb_number, $franchisee_id ] );

        if ( $query->num_rows() > 0 ) {
            return $query->result_array()[0];
        } else {
            return false;
        }

    }

    public function getCustomerDetailFromCustomerId( $customer_id ) {
        $sql = "SELECT customer_id, business_name, customer_code FROM dtdc_d_customer WHERE customer_id = ?";

        $query = $this->db->query( $sql, [ $customer_id ] );

        if ( $query->num_rows() > 0 ) {
            return $query->result_array()[0];
        } else {
            return [];
        }
    }

	public function getTatForProduct( $origin_office_id, $destination_pincode, $product_id ) {
//		$sql = "SELECT branchpint0_.TAT AS TAT_IN_DAYS,
//                branchpint0_.DEST_PIN_CUTOFF AS CUT_OF_TIME
//                FROM dtdc_d_branch_pin_tat_map branchpint0_
//                WHERE branchpint0_.ORG_OFFID = ?
//                AND branchpint0_.DEST_PIN = ?
//                AND (branchpint0_.PRODUCT_ID IN ( ? ))
//                AND branchpint0_.STATUS ='A'
//                ORDER BY branchpint0_.TAT ASC";
        $sql = "SELECT branchpint0_.TAT AS TAT_IN_DAYS,
            branchpint0_.DEST_PIN_CUTOFF AS CUT_OF_TIME
            FROM dtdc_d_branch_pin_tat_map branchpint0_
            WHERE branchpint0_.ORG_OFFID = 136
            AND branchpint0_.DEST_PIN = 560001
            AND (branchpint0_.PRODUCT_ID IN ( 2 ))
            AND branchpint0_.STATUS ='A'
            and TIME_FORMAT(curtime(), \"%H%i\") <= dest_pin_cutoff  
            order by tat asc limit 1";

        $query = $this->db->query( $sql, [ $origin_office_id, $destination_pincode, $product_id ] );

        if ( $query->num_rows() > 0 ) {
            return $query->result_array();
        } else {
            return [];
        }

    }

	public function getServicesFromTat( $origin_city_id, $destination_city_id, $tat, $product_id, $weight ) {
//		$sql = "SELECT lanedo0_.BILLING_CATEGORY_ID AS BILLING_CATEGORY_ID,
//                servicedo1_.SERVICE_CODE AS SERVICE_CODE,
//                servicedo1_.SERVICE_TYPE AS SERVICE_TYPE,
//                servicedo1_.PRODUCT_ID AS PRODUCT_ID,
//                servicedo1_.SERVICE_NAME AS SERVICE_NAME
//                FROM dtdc_d_lane lanedo0_, dtdc_d_service servicedo1_, dtdc_d_service_mapping service_mapping
//                WHERE lanedo0_.BILLING_CATEGORY_ID=servicedo1_.SERVICE_ID
//                AND lanedo0_.ORIGIN_CITY_ID = ?
//                AND lanedo0_.DEST_CITY_ID = ?
//                AND lanedo0_.TURN_AROUND_TIME_IN_DAYS = ?
//                AND lanedo0_.WEIGHT_FROM <= ?
//                AND lanedo0_.WEIGHT_TO >= ?
//                AND lanedo0_.RECORD_STATUS <>'I'
//                AND servicedo1_.SERVICE_TYPE REGEXP 'PLUS|BLUE|PEC|GREEN'
//                AND lanedo0_.BILLING_CATEGORY_ID = service_mapping.SERVICE_ID
//                AND service_mapping.MIN_WEIGHT = ?
//                AND service_mapping.MAX_WEIGHT = ?
//                AND ( servicedo1_.PREPAID <>'Y' OR servicedo1_.PREPAID IS NULL)";
        $sql = "SELECT lanedo0_.BILLING_CATEGORY_ID AS BILLING_CATEGORY_ID,
             servicedo1_.SERVICE_CODE AS SERVICE_CODE,
             servicedo1_.SERVICE_TYPE AS SERVICE_TYPE,
             servicedo1_.PRODUCT_ID AS PRODUCT_ID,
             servicedo1_.SERVICE_NAME AS SERVICE_NAME
             FROM dtdc_d_lane lanedo0_, dtdc_d_service servicedo1_, dtdc_d_service_mapping service_mapping
             WHERE lanedo0_.BILLING_CATEGORY_ID=servicedo1_.SERVICE_ID
             AND lanedo0_.ORIGIN_CITY_ID = ?
             AND lanedo0_.DEST_CITY_ID = ?
             AND lanedo0_.RECORD_STATUS <>'I'
             AND servicedo1_.SERVICE_TYPE REGEXP 'PLUS|BLUE|PEC|GREEN'
             AND lanedo0_.BILLING_CATEGORY_ID = service_mapping.SERVICE_ID
             AND ( servicedo1_.PREPAID <>'Y' OR servicedo1_.PREPAID IS NULL)
            and lanedo0_.TURN_AROUND_TIME_IN_DAYS = ?
             AND '0.001' between service_mapping.MIN_WEIGHT AND service_mapping.MAX_WEIGHT";

		$query = $this->db->query( $sql, [
			$origin_city_id,
			$destination_city_id,
			$tat,
//			$weight,
//			$weight,
//			$weight,
//			$weight
		] );

		if ( $query->num_rows() > 0 ) {
			return $query->result_array();
		} else {
			return [];
		}

	}

	public function validateServiceabilityOfServiceType( $service_type, $pincode_id ) {
		$sql   = "select PINCODE_ID from dtdc_d_pincode_mapping where pincode_id = ? and " . $this->db->escape_str($service_type) . '_SERVICEABLE' . " = 'Y'";
		$query = $this->db->query( $sql, [ $pincode_id ] );
		if ( $query->num_rows() > 0 ) {
			return true;
		} else {
			return false;
		}
	}

	public function getServicesFromTatForE( $origin_city_id, $destination_city_id, $tat_array, $weight ) {
		$sql = "select lanedo0_.BILLING_CATEGORY_ID as BILLING_CATEGORY_ID,
                servicedo1_.SERVICE_CODE as SERVICE_CODE,
                servicedo1_.SERVICE_TYPE as SERVICE_TYPE,
                servicedo1_.PRODUCT_ID as PRODUCT_ID,
                servicedo1_.SERVICE_NAME as SERVICE_NAME
                from dtdc_d_lane lanedo0_, dtdc_d_service servicedo1_, dtdc_d_service_mapping service_mapping
                where lanedo0_.BILLING_CATEGORY_ID=servicedo1_.SERVICE_ID
                and lanedo0_.ORIGIN_CITY_ID = ?
                and lanedo0_.DEST_CITY_ID = ?
                and lanedo0_.TURN_AROUND_TIME_IN_DAYS in ?
                and lanedo0_.WEIGHT_FROM <= ?
                and lanedo0_.WEIGHT_TO >= ?
                and lanedo0_.RECORD_STATUS<>'I'
                and servicedo1_.SERVICE_TYPE REGEXP 'PTP'
                AND lanedo0_.BILLING_CATEGORY_ID = service_mapping.SERVICE_ID
                AND service_mapping.MIN_WEIGHT = ?
                AND service_mapping.MAX_WEIGHT = ?
                and ( servicedo1_.PREPAID<>'Y' or servicedo1_.PREPAID is null)";

        $query = $this->db->query( $sql, [
            $origin_city_id,
            $destination_city_id,
            $tat_array,
            $weight,
            $weight,
            $weight,
            $weight
        ] );

        if ( $query->num_rows() > 0 ) {
            return $query->result_array();
        } else {
            return [];
        }

    }

    public function getServicesForCp( $origin_city_id, $destination_city_id ) {
        $sql = "SELECT DISTINCT lanedo0_.BILLING_CATEGORY_ID AS BILLING_CATEGORY_ID,
        servicedo1_.SERVICE_CODE AS SERVICE_CODE,
        servicedo1_.SERVICE_TYPE AS SERVICE_TYPE,
        servicedo1_.SERVICE_NAME AS SERVICE_NAME
    FROM
        dtdc_d_lane lanedo0_,
        dtdc_d_service servicedo1_
    WHERE
		lanedo0_.BILLING_CATEGORY_ID=servicedo1_.SERVICE_ID
        AND lanedo0_.ORIGIN_CITY_ID = ?
        AND lanedo0_.DEST_CITY_ID = ?
        AND lanedo0_.RECORD_STATUS <>'I'
        AND servicedo1_.SERVICE_TYPE = 'PRIORITY'
		AND (servicedo1_.PREPAID<>'Y' OR servicedo1_.PREPAID IS NULL)";

        $query = $this->db->query( $sql, [ $origin_city_id, $destination_city_id ] );

		if ( $query->num_rows() > 0 ) {
			return $query->result_array();
		} else {
			return [];
		}

	}


	public function getServicesForDpOrCpDp( $booking_type, $customer_id, $product_id, $weight, $origin_city_id, $destination_city_id ) {
		$service_list = [];

		$vertical = $this->getVerticalFromCustomerId( $customer_id );

		$pin_check = $this->getPinCheckFromCustomerIdAndProductId( $customer_id, $product_id );

		if ( strtoupper( $pin_check ) === 'Y' ) {
			$service_ids = $this->getServiceIdForPinCheckY( $customer_id, $product_id );
		} else {
			$service_ids = $this->getServiceIdForPinCheckOther( $customer_id, $product_id, $weight, $origin_city_id, $destination_city_id );
		}

		$service_ids_array = [];

		foreach ( $service_ids as $value ) {
			array_push( $service_ids_array, $value['SERVICE_ID'] );
		}

		$service_id = $service_ids_array;

		if ( ! ( $vertical === 'ECO' || $vertical === 'EBZ' ) && ! empty( $service_id ) ) {
			$service_list = $this->getServiceListFromServiceId( $service_id );
		}

		if ( ( $vertical === 'ECO' || $vertical === 'EBZ' ) && ! empty( $service_id ) && ( $weight <= 5 ) ) {
			$service_list = $this->getServiceListFromServiceIdAndVerticalAndWeightLessThan5( $service_id );
		}

		if ( ( $vertical === 'ECO' || $vertical === 'EBZ' ) && ! empty( $service_id ) && ( $weight > 5 ) ) {
			$service_list = $this->getServiceListFromServiceIdAndVerticalAndWeightGreaterThan5( $service_id );
		}

		if ( $booking_type == 'DP' ) {
			if ( ! empty( $vertical ) && empty( $service_id ) && ( $weight <= 5 ) ) {
				$service_list = $this->getServiceListFromVerticalAndWeightLessThan5( $customer_id );
			}

			if ( ! empty( $vertical ) && empty( $service_id ) && ( $weight > 5 ) ) {
				$service_list = $this->getServiceListFromVerticalAndWeightGreaterThan5( $customer_id );
			}
		}

		return $service_list;


	}


	public function getVerticalFromCustomerId( $customer_id ) {
		$sql   = "SELECT VERTICAL FROM dtdc_d_customer WHERE CUSTOMER_ID = ? LIMIT 1";
		$query = $this->db->query( $sql, [ $customer_id ] );
		if ( $query->num_rows() > 0 ) {
			return $query->result_array()[0]['VERTICAL'];
		} else {
			return null;
		}
	}

	public function getPinCheckFromCustomerIdAndProductId( $customer_id, $product_id ) {
		$sql   = "SELECT PIN_CHECK FROM dtdc_d_cust_prod_config WHERE CUSTOMER_ID = ?  AND PRODUCT_ID = ? AND STATUS = 'A' LIMIT 1";
		$query = $this->db->query( $sql, [ $customer_id, $product_id ] );
		if ( $query->num_rows() > 0 ) {
			return $query->result_array()[0]['PIN_CHECK'];
		} else {
			return null;
		}
	}

	public function getServiceIdForPinCheckY( $customer_id, $product_id ) {
		$sql   = "SELECT SERVICE_ID FROM dtdc_d_cust_prod_config WHERE CUSTOMER_ID = ? AND PRODUCT_ID = ?  AND STATUS = 'A'";
		$query = $this->db->query( $sql, [ $customer_id, $product_id ] );
		if ( $query->num_rows() > 0 ) {
			return $query->result_array();
		} else {
			return [];
		}
	}


	public function getServiceIdForPinCheckOther( $customer_id, $product_id, $weight, $origin_city_id, $destination_city_id ) {
		$sql   = "SELECT SERVICE_ID FROM dtdc_d_cust_prod_config  WHERE CUSTOMER_ID = ? AND PRODUCT_ID = ? AND STATUS = 'A'  AND SERVICE_ID IN (SELECT BILLING_CATEGORY_ID FROM dtdc_d_lane WHERE ORIGIN_CITY_ID = ?  AND DEST_CITY_ID = ? AND WEIGHT_TO >= ? AND WEIGHT_FROM <= ?)";
		$query = $this->db->query( $sql, [
			$customer_id,
			$product_id,
			$origin_city_id,
			$destination_city_id,
			$weight,
			$weight
		] );
		if ( $query->num_rows() > 0 ) {
			return $query->result_array();
		} else {
			return [];
		}
	}

	public function getServiceListFromServiceId( $service_id ) {
		$sql   = "SELECT SERVICE_ID, SERVICE_CODE, SERVICE_NAME FROM dtdc_d_service WHERE SERVICE_ID IN ? ";
		$query = $this->db->query( $sql, [ $service_id ] );
		if ( $query->num_rows() > 0 ) {
			return $query->result_array();
		} else {
			return [];
		}
	}

	public function getServiceListFromServiceIdAndVerticalAndWeightLessThan5( $service_id ) {
		$sql   = "SELECT SERVICE_ID, SERVICE_CODE, SERVICE_NAME FROM dtdc_d_service WHERE SERVICE_CODE IN ('PEX') AND SERVICE_ID IN ? ";
		$query = $this->db->query( $sql, [ $service_id ] );
		if ( $query->num_rows() > 0 ) {
			return $query->result_array();
		} else {
			return [];
		}
	}

	public function getServiceListFromServiceIdAndVerticalAndWeightGreaterThan5( $service_id ) {
		$sql   = "SELECT SERVICE_ID, SERVICE_CODE, SERVICE_NAME FROM dtdc_d_service WHERE SERVICE_CODE IN ('PAR','PSF') AND SERVICE_ID IN ?";
		$query = $this->db->query( $sql, [ $service_id ] );
		if ( $query->num_rows() > 0 ) {
			return $query->result_array();
		} else {
			return [];
		}
	}

	public function getServiceListFromVerticalAndWeightLessThan5( $customer_id ) {
		$sql = "SELECT SERVICE_ID, SERVICE_CODE, SERVICE_NAME FROM dtdc_d_service WHERE
	            SERVICE_CODE IN ('PEX')
	            AND SERVICE_ID IN ( SELECT
		        SERVICE_ID FROM
		        dtdc_d_cust_prod_config WHERE
		        CUSTOMER_ID = ?
		        AND IS_SPL_SERV='Y')";

        $query = $this->db->query( $sql, [ $customer_id ] );
        if ( $query->num_rows() > 0 ) {
            return $query->result_array();
        } else {
            return [];
        }
    }


    public function getServiceListFromVerticalAndWeightGreaterThan5( $customer_id ) {
        $sql = "select SERVICE_ID, SERVICE_CODE, SERVICE_NAME from
                dtdc_d_service where
                SERVICE_CODE in ('PAR','PSF')
                and SERVICE_ID in (select
                SERVICE_ID from
                dtdc_d_cust_prod_config where
                CUSTOMER_ID = ?
                and IS_SPL_SERV = 'Y')";

        $query = $this->db->query( $sql, [ $customer_id ] );
        if ( $query->num_rows() > 0 ) {
            return $query->result_array();
        } else {
            return [];
        }
    }

    public function getCutoffTimeForService( $category_id, $origin_city_id, $destination_city_id, $origin_office_id, $destination_pincode, $product_id, $weight ) {
        $sql = "select
        	b.DEST_PIN_CUTOFF
    	from
        	dtdc_d_lane lanedo0_,
        	dtdc_d_branch_pin_tat_map b,
        	dtdc_d_service_mapping service_mapping
	    where
	        lanedo0_.BILLING_CATEGORY_ID = ?
	        and lanedo0_.ORIGIN_CITY_ID = ?
	        and lanedo0_.DEST_CITY_ID = ?
	        and lanedo0_.TURN_AROUND_TIME_IN_DAYS= b.TAT
			and b.Org_OffId = ?
			and b.Dest_pin = ?
			and b.product_id = ?
	        and lanedo0_.WEIGHT_FROM <= ?
	        and lanedo0_.WEIGHT_TO >= ?
	        AND service_mapping.SERVICE_ID = ?
            AND service_mapping.MIN_WEIGHT = ?
            AND service_mapping.MAX_WEIGHT = ?
	        and lanedo0_.RECORD_STATUS <> 'I'";

		$query = $this->db->query( $sql, [
			$category_id,
			$origin_city_id,
			$destination_city_id,
			$origin_office_id,
			$destination_pincode,
			$product_id,
			$weight,
			$weight,
			$category_id,
			$weight,
			$weight
		] );
		if ( $query->num_rows() > 0 ) {
			return $query->result_array();
		} else {
			return [];
		}

	}

	public function getXSeriesPinCodeServiceability( $pincode_id ) {
		$sql   = "select * from dtdc_d_pincode_mapping where pincode_id = ? and (PLUS_SERVICEABLE = 'Y' OR
                BLUE_SERVICEABLE = 'Y' OR GREEN_SERVICEABLE = 'Y')";
        $query = $this->db->query( $sql, [ $pincode_id ] );
        if ( $query->num_rows() > 0 ) {
            return true;
        } else {
            return false;
        }


    }

    public function getLastQuery() {
        return $this->db->last_query();
    }


    public function getTheServicesForESeriesDPBooking1( $customer_id ) {
        $sql = "select servicedo1_.SERVICE_CODE as SERVICE_CODE,
                servicedo1_.SERVICE_NAME as SERVICE_NAME,
                custprodco0_.SERVICE_ID as SERVICE_ID,
                servicedo1_.SERVICE_TYPE as SERVICE_TYPE
                from
                dtdc_d_cust_prod_config custprodco0_,
                dtdc_d_service servicedo1_
                where
                custprodco0_.SERVICE_ID = servicedo1_.SERVICE_ID
                and custprodco0_.CUSTOMER_ID = ?
                and custprodco0_.PIN_CHECK = 'Y'
                and servicedo1_.SERVICE_CODE like '%D14%'
                and (servicedo1_.PREPAID <>'Y'
                    or servicedo1_.PREPAID is null)
                and custprodco0_.MAX_WT =
                    ( select max(custprodco6_.MAX_WT) from
                    dtdc_d_cust_prod_config custprodco6_
                    where
                    custprodco6_.CUSTOMER_ID = ?)";

        $query = $this->db->query( $sql, [ $customer_id, $customer_id ] );

        if ( $query->num_rows() > 0 ) {
            return $query->result_array();
        } else {
            return [];
        }

    }

    public function getTheServicesForESeriesDPBooking2( $origin_city_id, $dest_city_id ) {
        $sql = "select
        distinct lanedo0_.BILLING_CATEGORY_ID as SERVICE_ID,
        servicedo1_.SERVICE_CODE as SERVICE_CODE,
        servicedo1_.SERVICE_TYPE as SERVICE_TYPE,
        servicedo1_.SERVICE_NAME as SERVICE_NAME
    from
        dtdc_d_lane lanedo0_,
        dtdc_d_service servicedo1_
    where
        lanedo0_.BILLING_CATEGORY_ID = servicedo1_.SERVICE_ID
        and lanedo0_.ORIGIN_CITY_ID = ?
        and lanedo0_.DEST_CITY_ID = ?
        and lanedo0_.RECORD_STATUS <>'I'
		and servicedo1_.SERVICE_TYPE like '%PTP%'

        and (
            servicedo1_.PREPAID <>'Y'
            or servicedo1_.PREPAID is null
        )";

        $query = $this->db->query( $sql, [ $origin_city_id, $dest_city_id ] );

        if ( $query->num_rows() > 0 ) {
            return $query->result_array();
        } else {
            return [];
        }

    }

	public function checkServiceabilityOfPincodeForESeriesDPBooking1( $customer_id, $service_id ) {
		$sql = "select PIN_CHECK from dtdc_d_cust_prod_config
    	where CUSTOMER_ID = ?
        	and SERVICE_ID = ?
        	and STATUS='A' and PIN_CHECK = 'Y'";

        $query = $this->db->query( $sql, [ $customer_id, $service_id ] );

        return ( $query->num_rows() > 0 ) ? true : false;

    }


	public function checkServiceabilityOfPincodeForESeriesDPBooking2( $pincode_id, $service_type ) {
		$sql = "select PINCODE_ID from dtdc_d_pincode_mapping where PINCODE_ID = ?
                and " . $service_type . "_SERVICEABLE = 'Y'";

        $query = $this->db->query( $sql, [ $pincode_id ] );

        return ( $query->num_rows() > 0 ) ? 1 : 0;
    }

    public function getParcelBranchConfigurationForPincode( $pincode, $product_code ) {
        $sql   = "Select * from dtdc_d_pincode_pb_product_mapping
		where PINCODE = ? and PRODUCT = ? and RECORD_STATUS = 'A'";
        $query = $this->db->query( $sql, [ $pincode, $product_code ] );
        if ( $query->num_rows() > 0 ) {
            return $query->result_array()[0];
        } else {
            return [];
        }
    }

    public function getEwbFlag( $originCityId, $destCityId, $invoiceValue ) {
        $sql = "select
                (select STATE_CODE from dtdc_d_city where city_id = ?) as st1,
                (select STATE_CODE from dtdc_d_city where city_id = ?) as st2;";

        $query = $this->db->query( $sql, [ $originCityId, $destCityId ] );

        $result = $query->row_array();
        if ( $result['st1'] == $result['st2'] ) {
            $comp_sql = "select ewb_slab_id from dtdc_d_ewb_slab where ? >= INTRA_STATE_SLAB AND STATE_CODE = '" . $result['st1'] . "'";
        } else {
            $comp_sql = "select ewb_slab_id from dtdc_d_ewb_slab where ? >= INTER_STATE_SLAB AND STATE_CODE = '" . $result['st1'] . "'";
        }
        $comp_query = $this->db->query( $comp_sql, [ $invoiceValue ] );
        if ( $comp_query->num_rows() > 0 ) {
            return 1;
        } else {
            return 0;
        }
    }

    public function getSuggestedMaxWeight( $cong_series ) {
        $sql   = "select SUGGESTED_LIMIT AS suggested_weight, MAX_WEIGHT_ALLOWED AS max_weight from dtdc_d_weight_info
                where CONSG_SERIES = ? and RECORD_STATUS = 'Y'";
		$query = $this->db->query( $sql, [ $cong_series ] );
		if ( $query->num_rows() > 0 ) {
			return $query->row();
		} else {
			$x = new stdClass();

			return json_encode( $x );
		}

	}

	private function getConfirmationTatDate() {

		$date           = $this->date;
		$local_date_obj = new DateTime( $date, new DateTimeZone( 'Asia/Kolkata' ) );
		$exact_date     = $local_date_obj->format( 'j' );
		$total          = $local_date_obj->format( 't' );

		if ( $exact_date == $total ) {
			$new_date = date_add( $local_date_obj, date_interval_create_from_date_string( '1 day' ) );
		} else {
			$new_date = date_add( $local_date_obj, date_interval_create_from_date_string( '2 days' ) );
		}

		return $new_date->format( 'Y-m-d' );
	}

	public function insertIntoConsigneeTable( $data ) {
		$insert_data = array(
			'FIRST_NAME' => $data['CONSIGNEE_NAME'],
			'PHONE'      => $data['CONSIGNEE_PHONE'],
			'EMAIL'      => $data['CONSIGNEE_MAILID']
		);
		$this->db->insert( 'dtdc_d_consignee', $insert_data );
		$insert_id = $this->db->insert_id();

		return $insert_id;
	}

	public function insertIntoConsignerTable( $data ) {
		$insert_data = array(
			'FIRST_NAME' => $data['CONSIGNER_NAME'],
			'PHONE'      => $data['CONSIGNER_PHONE'],
			'EMAIL'      => $data['CONSIGNER_EMAIL']
		);
		$this->db->insert( 'dtdc_f_consigner_info', $insert_data );
		$insert_id = $this->db->insert_id();

		return $insert_id;
	}

	public function insertIntoConsigneeAddressTable( $data, $consignee_id ) {
		$city_id     = $this->getCityIdFromCityName( $data['CITY_NAME'] );
		$pincode_id  = $this->getPincodeIdFromPincode( $data['PINCODE'] );
		$insert_data = array(
			'STREET_1'     => $data['CONSIGNEE_ADD1'],
			'STREET_2'     => $data['CONSIGNEE_ADD2'],
			'STREET_3'     => $data['CONSIGNEE_ADD3'],
			'CONSIGNEE_ID' => $consignee_id,
			'CITY_ID'      => $city_id,
			'PINCODE_ID'   => $pincode_id
		);
		$this->db->insert( 'dtdc_d_consg_address', $insert_data );
	}

	public function insertIntoConsignerAddressTable( $data, $consigner_id ) {
		$city_id     = $this->getCityIdFromCityName( $data['CONSIGNER_CITY'] );
		$pincode_id  = $this->getPincodeIdFromPincode( $data['CONSIGNER_PINCODE'] );
		$insert_data = array(
			'STREET_1'     => $data['CONSIGNER_ADD1'],
			'STREET_2'     => $data['CONSIGNER_ADD2'],
			'STREET_3'     => $data['CONSIGNER_ADD3'],
			'CONSIGNER_ID' => $consigner_id,
			'CITY_ID'      => $city_id,
			'PINCODE_ID'   => $pincode_id
		);
		$this->db->insert( 'dtdc_f_consigr_address', $insert_data );
	}

	public function getCompleteSoftEbkData( $consignment_number ) {
		$sql   = "select *,ifnull(mobile_no,consignee_phone) as ASMOBILE_NO from dtdc_f_spl_cust_data where consg_number = ? AND consg_status = 'A'";
		$query = $this->db->query( $sql, [ $consignment_number ] );
		if ( $query->num_rows() > 0 ) {
			return $query->result_array();
		} else {
			return [];
		}
	}

	public function getPincodeIdFromPincode( $pincode ) {
		$sql   = 'select PINCODE_ID from dtdc_d_pincode where PIN_CODE = ? order by PINCODE_ID limit 1';
		$query = $this->db->query( $sql, [ $pincode ] );
		if ( $query->num_rows() > 0 ) {
			return $query->result_array()[0]['PINCODE_ID'];
		} else {
			return null;
		}
	}

	public function getCityIdFromCityName( $cityName ) {
		$sql   = 'select CITY_ID from dtdc_d_city where CITY_NAME = ? order by CITY_ID limit 1';
		$query = $this->db->query( $sql, [ $cityName ] );
		if ( $query->num_rows() > 0 ) {
			return $query->result_array()[0]['CITY_ID'];
		} else {
			return null;
		}
	}

	public function getIsEwbNumberIsSavedInBranch( $office_id, $ewb_consg_number ) {
		$sql   = "select EWB_ID from dtdc_f_ewb_info where TRANS_OFFICE_ID = ? and CONSG_NUMBER = ?";
		$query = $this->db->query( $sql, [ $office_id, $ewb_consg_number ] );
		if ( $query->num_rows() > 0 ) {
			return true;
		} else {
			return false;
		}
	}

	public function checkTheConsignmentIsStopped( $consignment_number ) {
		$sql   = "select * from dtdc_f_rto_upload where CONSG_NUMBER = ? and SET_RTO_STATUS = 'Y' and RECORD_STATUS = 'A'";
		$query = $this->db->query( $sql, [ $consignment_number ] );
		if ( $query->num_rows() > 0 ) {
			return true;
		} else {
			return false;
		}
	}

	public function getConsignmentNumberStopStatus( $consignment_number ) {
		$sql   = "select * from dtdc_f_rto_upload where CONSG_NUMBER = ? and SET_RTO_STATUS = 'N' and RECORD_STATUS = 'A'";
		$query = $this->db->query( $sql, [ $consignment_number ] );
		if ( $query->num_rows() > 0 ) {
			return true;
		} else {
			return false;
		}
    }
    
  

	public function saveDoxBooking( $data ) {
        $dox_consignments = $data['doxConsignments'];
        
       	$total_saved = 0;
		foreach ( $dox_consignments as $consignment ) {

            $validation = $consignment['validation'];
            if($validation == null){
                $validation =  $this->getVersionType($consignment['consignmentNumber']);
            }

			$insert_data = [
				'FINAL_WEIGHT'             => $consignment['finalWeight'],
				'CONSGMNT_STATUS'          => 'Booked',
				'WEIGHING_TYPE'            => 'M',
				'NO_OF_PIECES'             => 1,
				'BOOKING_DATE'             => $this->date,
				'BOOKING_TIME'             => $this->fullTime,
				'DOX_AMOUNT'               => 0,
				'NON_DOX_AMOUNT'           => 0,
				'AMOUNT'                   => 0,
				'ACTUAL_WEIGHT'            => $consignment['finalWeight'],
				'INS_AMOUNT'               => 0,
				'CONSG_NUMBER'             => $consignment['consignmentNumber'],
				'SECURITY_POUCH'           => 0,
				'FUEL_SURCHARGE_PERC'      => 0,
				'RISK_SURCHG_AMT'          => 0,
				'SERV_CHRG_AMT'            => 0,
                'CUST_REF_NO'              => $consignment['referenceNumber'],
                'PICKUP_TIME'              => $consignment['customer_branch'], // FR Credit 23-02-2020
				'BOOKING_DIVISION'         => 'DD',
				'CHANNEL_TYPE_ID'          => $data['channelTypeId'],
				'DEST_CITY_ID'             => $consignment['destinationCityId'],
				'DEST_PINCODE_ID'          => $consignment['destinationPincodeId'],
				'CUSTOMER_ID'              => $consignment['customerId'],
				'MODE_ID'                  => $consignment['modeId'],
				'PRODUCT_ID'               => $this->getProductIdFromServiceId( $consignment['serviceId'] ),
				'DOCUMENT_ID'              => 1,
				'SERVICE_ID'               => $consignment['serviceId'],
				'FRANCHISEE_ID'            => $consignment['franchiseId'],
				'BRNCH_OFF_ID'             => $data['branchOfficeId'],
				'EMPLOYEE_ID'              => $data['employeeId'],
				'DB_SERVER'                => 'N',
				'BOOKING_TYPE'             => $data['bookingType'],
				'UPDATED_FROM_PROCESS'     => 'MOP',
				'TRANS_CREATE_DATE'        => $this->date,
				'TRANS_LAST_MODIFIED_DATE' => $this->date,
				'USER_ID'                  => $data['userId'],
				'SPECIAL_CHARGE'           => 0,
				'ADDITIONAL_CHARGE'        => 0,
				'COMMERCAIL_TAX'           => 0,
				'CESS_TAX'                 => 0,
				'EDUCATION_TAX'            => 0,
				'TS_AMOUNT'                => 0,
				'NODE_ID'                  => $data['nodeId'],
				'di_flag'                  => 'N',
				'CHANGED_AFTER_BILLING'    => 'N',
				'BILLING_STATUS'           => 'TBB',
				'ACTUAL_BRANCH_ID'         => $this->getActualBranchIdFromFranchiseeIdOrCustomerId( $consignment['franchiseId'], $consignment['customerId'], $data['bookingType'] ),
				'RECORD_ENTRY_DATETIME'    => $this->datetime,
				'VOL_WT_MAND'              => 'N',
				'CONSG_ENTRY_TYPE'         => $consignment['consignmentEntryType'],
				'DEST_BRANCH_CODE'         => $consignment['destBranchCode'],
				'WAR_DATE'                 => $data['warDate'],
				'TRANS_STATUS'             => 'A',
				'DD_FLAG'                  => 'N',
				'VALIDATION'               => $validation,
				// 'VALIDATION'               => $consignment['validation'],
				'FRANCH_MINF_NUMBER'       => $this->findFranchiseeManifestNumber( $consignment['franchiseId'] )
			];
			if ( $this->db->insert( 'dtdc_f_booking', $insert_data ) ) {
				$total_saved ++;
			}
		}

		return $total_saved;
	}


	public function checkOperationalFreedomEligibility( $consignment_number ) {

		$sql = "SELECT
                goodsissue1_.franchisee_id frid,
                goodsissue1_.customer_id cust_id,
                franchisee2_.business_name cname,
                franchisee2_.franchisee_code ccode,
                goodsissue1_.ISSUE_DOCUMENT_DATE as issue_date,
                franchisee2_.ONLINE_BOOKING online_booking
                FROM dtdc_f_goods_issue_item_detl goodsissue0_, dtdc_f_goods_issue goodsissue1_, dtdc_d_franchisee franchisee2_
                           WHERE ? BETWEEN goodsissue0_.START_SL_NUMBER AND goodsissue0_.END_SL_NUMBER
                           AND length(goodsissue0_.START_SL_NUMBER) = 9
                           AND goodsissue0_.RECORD_STATUS='A'
                           AND goodsissue0_.GOODS_ISSUE_ID=goodsissue1_.GOODS_ISSUE_ID
                           AND goodsissue1_.franchisee_id=franchisee2_.franchisee_id
                           AND ifnull(franchisee2_.revenue_category,'') not in ('CNC', 'NEW')
                           AND goodsissue1_.ISSUE_DOCUMENT_DATE <= curdate()
                           AND goodsissue1_.FRANCHISEE_ID IS NOT NULL
                           AND franchisee2_.CUR_STATUS='A'
                           AND franchisee2_.CLOSED_STATUS = 'N'
                union
                
                SELECT
                ''frid,
                goodsissue1_.customer_id cust_id,
                customer2_.business_name cname,
                customer2_.customer_code ccode,
                goodsissue1_.ISSUE_DOCUMENT_DATE as issue_date,
                ''online_booking
                               FROM dtdc_f_goods_issue_item_detl goodsissue0_, dtdc_f_goods_issue goodsissue1_, dtdc_d_customer customer2_
                               WHERE goodsissue0_.GOODS_ISSUE_ID=goodsissue1_.GOODS_ISSUE_ID
                               AND goodsissue1_.customer_id=customer2_.customer_id
                               AND (? BETWEEN goodsissue0_.START_SL_NUMBER AND goodsissue0_.END_SL_NUMBER)
                               AND customer2_.CUR_STATUS='A'
                               AND goodsissue1_.ISSUE_DOCUMENT_DATE <= curdate()
                               AND goodsissue1_.CUSTOMER_ID IS NOT NULL
                               AND length(goodsissue0_.START_SL_NUMBER) = 9
                               AND goodsissue0_.RECORD_STATUS='A'

                ORDER BY issue_date DESC";

        $query = $this->db->query( $sql, [ $consignment_number, $consignment_number ] );

        if ( $query->num_rows() > 0 ) {

            $result = $query->result_array()[0];
            if($result['frid']) {

                $newRoMappingResult = $this->getTheNewROmappingForFranchisee($result['frid']);
                if($newRoMappingResult) {
                    $result['frid'] = $newRoMappingResult['franchisee_id'];
                    $result['cname'] = $newRoMappingResult['business_name'];
                    $result['ccode'] = $newRoMappingResult['franchisee_code'];
                }

            }
            return $result;
        } else {
            return false;
        }

    }

    public function saveOperationalFreedom( $input_data ) {

        $opfCns = $input_data['opfCNs'];
        $total_saved = 0;

        foreach($opfCns as $opf_cn){

            $validation =  $this->getVersionType($opf_cn['consgNumber']);
            $insert_data = array(
                'FINAL_WEIGHT'         => $opf_cn['finalWeight'],
                'CONSGMNT_STATUS'      => 'BOOKED',
                'WEIGHING_TYPE'        => 'M',
                'BOOKING_DATE'         => $this->datetime,
                'BOOKING_TIME'         => $this->fullTime,
                'REMARKS'              => 'OPF',
                'ACTUAL_WEIGHT'        => $opf_cn['finalWeight'],
                'CONSG_NUMBER'         => $opf_cn['consgNumber'],
                'CUSTOMER_ID'          => $opf_cn['customerId'],
                'BOOKING_DIVISION'     => 'DD',
                'CHANNEL_TYPE_ID'      => $opf_cn['channelTypeId'],
                'DEST_CITY_ID'         => $opf_cn['destCityId'],
                'DEST_PINCODE_ID'      => $opf_cn['destPincodeId'],
                'MODE_ID'              => 1,
                'PRODUCT_ID'           => 1,
                'DOCUMENT_ID'          => 1,
                'SERVICE_ID'           => 2,
                'FRANCHISEE_ID'        => $opf_cn['franchiseeId'],
                'BRNCH_OFF_ID'         => $input_data['loggedInOfficeId'],
                'DB_SERVER'            => 'N',
                'BOOKING_TYPE'         => $opf_cn['bookingType'],
                'USER_ID'              => $input_data['userId'],
                'NODE_ID'              => $input_data['nodeId'],
                'Di_flag'              => 'P',
                'ACTUAL_BRANCH_ID'     => $this->getActualBranchIdFromFranchiseeIdOrCustomerId($opf_cn['franchiseeId'],$opf_cn['customerId'], $opf_cn['bookingType']),
                'WAR_DATE'             => $input_data['warDate'],
                'MANUAL_DOWNLOAD_FLAG' => 'N',
                'DD_FLAG'              => 'N',
                'DEST_BRANCH_CODE'     => $opf_cn['destOfficeCode'],
                'NO_OF_PIECES'         => 1,
                'VALIDATION'           => $validation
            );

            if ( $this->db->insert( 'dtdc_f_booking', $insert_data ) ) {
                $total_saved ++;
            }

        }

        return $total_saved;


    }


	public function getBookingIdFromConsgNumber($consgNumber) {
		$sql = "select booking_id from dtdc_f_booking where consg_number = ? and  no_of_pieces > 1 and COMMODITY_ID != 101";
		$result = $this->db->query($sql,[$consgNumber]);
		if($result->num_rows() > 0) {
			return $result->result_array()[0]['booking_id'];
		} else {
			return false;
		}
	}


	public function getTheDifferenceInDays($issueDateString) {

        date_default_timezone_set('Asia/Kolkata');
        $dateObj = new DateTime( 'now', new DateTimeZone( 'Asia/Kolkata' ));
        $current_date = $dateObj->format('Y-m-d');
        $issueDate = DateTime::createFromFormat('Y-m-d', $issueDateString, new DateTimeZone( 'Asia/Kolkata' ));
        $issueDateStringNew = $issueDate->format('Y-m-d');
        $diff = strtotime($current_date) - strtotime($issueDateStringNew);
        $no_of_days =  abs(round($diff / 86400));
        return $no_of_days;
    }

    public function getTheBookingDataForConsignment($consgNumber) {

        $sql = "select NO_OF_PIECES, ACTUAL_WEIGHT as WEIGHT, DOCUMENT_ID, BRNCH_OFF_ID as OFFICE_ID, DEST_PINCODE_ID as PINCODE_ID, DESC_GOODS 
                    from dtdc_f_booking where consg_number = ?";
        $result = $this->db->query($sql,[$consgNumber]);
        if($result->num_rows() > 0) {
            return $result->result_array()[0];
        } else {
            return null;
        }
    }

    public function checkSplCustomerDataForOperationFreedom($consgNumber){

        $sql = "SELECT PINCODE FROM dtdc_f_spl_cust_data WHERE CONSG_NUMBER = ? AND consg_status = 'A'";
        $result = $this->db->query($sql,[$consgNumber]);
        if($result->num_rows() > 0) {
            return $result->result_array()[0];
        } else {
            return null;
        }
    }

    public function forceCloser($consgNumber){

        $sql = "SELECT CONSG_NUMBER CNNO,CLOSURE_STATUS STS,
                CASE WHEN CLOSURE_STATUS='Lost' THEN (SELECT 'Force Closure Lost')
                WHEN CLOSURE_STATUS='RTO Delivered' THEN (SELECT 'Force Closure RTO Delivered')
                WHEN CLOSURE_STATUS='Delivered' THEN (SELECT 'Force Closure Delivered') END MESSAGE,
                STATUS RS,CLOSURE_ACTION CA FROM DTDC_F_FORCE_CLOSURE WHERE CONSG_NUMBER = ? AND CLOSURE_ACTION='ADD' AND DTDC_F_FORCE_CLOSURE.STATUS='A'";

        $query = $this->db->query($sql,[$consgNumber]);
        $result = $query->result_array();
        if($result){
            return  [
                        'status' => '0',
                        'message' => $result[0]['MESSAGE']
                    ];
        }
            return  [
                        'status' => '1',
                        'message' => 'Proceed Further'
                    ];

    }

    public function validate_booking($consgNumber, $destBranchId){
        // $sql = "select booking_id MF,FINAL_WEIGHT as tot_weight_kgs,
        //         document_id, no_of_pieces, mode_id from dtdc_f_booking
        //         where CONSG_NUMBER = ? and BRNCH_OFF_ID = ? ";

        // $sql = "select booking.booking_id MF,booking.FINAL_WEIGHT as tot_weight_kgs,
        //         booking.document_id, booking.no_of_pieces, booking.mode_id 
        //         from dtdc_f_booking booking,dtdc_f_delivery delivery
        //         where booking.CONSG_NUMBER = ? and booking.BRNCH_OFF_ID = ? and delivery.DELIVERY_STATUS <> 'D'";

        $sql = "select booking.booking_id MF,booking.FINAL_WEIGHT as tot_weight_kgs,
        booking.document_id, booking.no_of_pieces, booking.mode_id 
        from dtdc_f_booking booking
        where booking.CONSG_NUMBER = ? and booking.BRNCH_OFF_ID =  ? ";

        $query = $this->db->query($sql,[$consgNumber, $destBranchId]);
        $result = $query->result_array();
        if($result) {
            if($result[0]['no_of_pieces'] > 1 ){
                return  [
                    'status' => '0',
                    'message' => 'Please scan child consignment, mother consignment is not allowed',
                    'result_data' => null
                ];
            }
            $isDelivered =  $this->isDelivered($consgNumber, $destBranchId);
            if($isDelivered){
                return  [
                    'status' => '0',
                    'message' => 'Consignment '. $consgNumber.' Already Delivered',
                    'result_data' => null,
                
                ];
            }
            
            return  [
                'status' => '1',
                'message' => 'Proceed Further',
                'result_data' => $consgNumber
            ];  

        } 
        return  [
            'status' => '0',
            'message' => 'Booking Data Not Found',
            'result_data' => null
        ];
    }

    public function checkDelivery($consg_number, $destBranchId){
        $sql = "select consg_number from dtdc_f_delivery WHERE consg_number = ?  and OFFICE_ID = ? ";
        $query = $this->db->query($sql,[$consg_number, $destBranchId]);
        $result = $query->result_array();
        if($result){
            return true;
        }
        return false;
    }

    public function incoming_manifest($consg_number, $destBranchId){

        $consig_number_length =  strlen($consg_number);
        
        if($consig_number_length == '12' || $consig_number_length == '9'){
           
           $sql = "select distinct(CONSG_NUMBER)  from dtdc_f_manifest where CONSG_NUMBER = ? and MANIFEST_TYPE = 'I' and DEST_BRNCH_ID = ?";
           $query = $this->db->query($sql,[$consg_number, $destBranchId]);
        }
        if($consig_number_length == '11' || $consig_number_length == '8'){
            // $sql = "select distinct(manifest_number),mnfst_type_id  from dtdc_f_manifest where manifest_number = ? and MANIFEST_TYPE = 'I' and DEST_BRNCH_ID = ?";
            // $sql = "select distinct(CONSG_NUMBER) from dtdc_f_manifest where CONSG_NUMBER = ? and MANIFEST_TYPE = 'I' and DEST_BRNCH_ID = ?
            //         union
            //         select distinct(CONSG_NUMBER) from dtdc_f_manifest where manifest_number = ? and MANIFEST_TYPE = 'I' and DEST_BRNCH_ID = ? ";
            $sql = "select manifest_number,mnfst_type_id,manifest_date  from (
                    select distinct(manifest_number)  ,mnfst_type_id ,manifest_date from dtdc_f_manifest where CONSG_NUMBER = ? and MANIFEST_TYPE = 'I' and DEST_BRNCH_ID = ?
                    union
                    select distinct(manifest_number)  ,mnfst_type_id ,manifest_date from dtdc_f_manifest where manifest_number = ? and MANIFEST_TYPE = 'I' and DEST_BRNCH_ID = ?) A
                    order by manifest_date desc limit 1";
            
            $query = $this->db->query($sql,[$consg_number, $destBranchId, $consg_number, $destBranchId]);        
        }
       
       
        $result = $query->result_array();
        if($result){

            if($consig_number_length == '12' || $consig_number_length == '9'){
                    $isDelivered =  $this->isDelivered($consg_number, $destBranchId);
                    if($isDelivered){
                        return  [
                            'status' => '0',
                            'message' => 'Consignment '. $consg_number.' Already Delivered',
                            'result_data' => null,
                        
                        ];
                    }
            }

            return  [
                'status' => '1',
                'message' => 'Proceed Further',
                'result_data' => $result,
                
            ];  
        }
        return  [
            'status' => '0',
            'message' => 'Incoming Data Not Found',
            'result_data' => null,
            'consg_numbers' => null
        ];

    }

    public function outgoing_manifest($consig_number, $destBranchId){

        $consig_number_length =  strlen($consig_number);
       
        if($consig_number_length == '12' || $consig_number_length == '9'){
           
            $sql = "select distinct(CONSG_NUMBER)  from dtdc_f_manifest where CONSG_NUMBER = ? and MANIFEST_TYPE = 'O' and orig_brnch_id = ?";
            $query = $this->db->query($sql,[$consig_number, $destBranchId]);
        }
        if($consig_number_length == '11' || $consig_number_length == '8'){
            //$sql = "select distinct(manifest_number),mnfst_type_id  from dtdc_f_manifest where manifest_number = ? and MANIFEST_TYPE = 'O' and orig_brnch_id = ?";
        // $sql = "select distinct(CONSG_NUMBER)  from dtdc_f_manifest where CONSG_NUMBER = ? and MANIFEST_TYPE = 'O' and orig_brnch_id = ?
        //         union
        //         select distinct(CONSG_NUMBER)  from dtdc_f_manifest where manifest_number = ? and MANIFEST_TYPE = 'O' and orig_brnch_id = ? ";
        //         $query = $this->db->query($sql,[$consig_number, $destBranchId, $consig_number, $destBranchId]);
        $sql = "select manifest_number,mnfst_type_id,manifest_date  from (
                 select distinct(manifest_number)  ,mnfst_type_id ,manifest_date  from dtdc_f_manifest where CONSG_NUMBER = ? and MANIFEST_TYPE = 'O' and orig_brnch_id = ?
                union
                select distinct(manifest_number)  ,mnfst_type_id ,manifest_date 
                from dtdc_f_manifest where manifest_number = ? and MANIFEST_TYPE = 'O' and orig_brnch_id = ? ) A
                order by manifest_date desc limit 1"; 
             $query = $this->db->query($sql,[$consig_number, $destBranchId, $consig_number, $destBranchId]);   
        }
        
        $result = $query->result_array();
        if($result){
            if($consig_number_length == '12' || $consig_number_length == '9'){
                $isDelivered =  $this->isDelivered($consig_number, $destBranchId);
                if($isDelivered){
                    return  [
                        'status' => '0',
                        'message' => 'Consignment '. $consig_number.' Already Delivered',
                        'result_data' => null,
                    
                    ];
                }
            }
            return  [
                'status' => '1',
                'message' => 'Proceed Further',
                'result_data' =>  $result,
                
            ];  
        }
        return  [
            'status' => '0',
            'message' => 'Outgoing Data Not Found',
            'result_data' => null,
           
        ];
    }

    public function cd_receive_validate($dispatch_number, $destBranchId, $process_name){
    
        if($process_name == 'dispatch_number'){
            $sql = "select distinct(bag.BAG_MANIFEST_NUMBER),manifest.mnfst_type_id,bag.CD_RECEIVE_DISPATCH_ID,bag.DEST_OFFICE_ID
            from dtdc_f_cd_recv_mnfst_dtls bag, dtdc_f_manifest manifest
            where bag.BAG_MANIFEST_NUMBER = manifest.manifest_number 
            and bag.CD_RECEIVE_DISPATCH_ID  = (select CD_RECEIVE_DISPATCH_ID from dtdc_f_cd_receive where DISPATCH_NUMBER = ? and dest_office_id = ? )
            ";
        }
        if($process_name == 'CD_LT_RR_No'){
            $sql = "select distinct(bag.BAG_MANIFEST_NUMBER),manifest.mnfst_type_id,bag.CD_RECEIVE_DISPATCH_ID,bag.DEST_OFFICE_ID
                    from dtdc_f_cd_recv_mnfst_dtls bag, dtdc_f_manifest manifest
                    where bag.BAG_MANIFEST_NUMBER = manifest.manifest_number 
                    and bag.CD_RECEIVE_DISPATCH_ID   = 
                    (select CD_RECEIVE_DISPATCH_ID from dtdc_f_cd_receive where CD_LT_RR_NO = ? and dest_office_id = ? );
                    ";
        }
        if($process_name == 'bag_manifest'){

            $sql = "select distinct(bag.BAG_MANIFEST_NUMBER),manifest.mnfst_type_id
            from dtdc_f_cd_recv_mnfst_dtls bag, dtdc_f_manifest manifest
            where bag.BAG_MANIFEST_NUMBER = manifest.manifest_number AND  bag.BAG_MANIFEST_NUMBER = ? and bag.DEST_OFFICE_ID = ?  ";
        
        }
        $query = $this->db->query($sql,[$dispatch_number, $destBranchId]);
        $result = $query->result_array();
        if($result){
            
            return  [
                'status' => '1',
                'message' => 'Proceed Further',
                'result_data' => $result
            ];  
        }
        return  [
            'status' => '0',
            'message' => 'CD Receive Data Not Found',
            'result_data' => null
        ];

    }

    public function cd_dispatch_validate($dispatch_number, $destBranchId, $process_name){
    
        if($process_name == 'dispatch_number'){
            $sql = "select distinct(BAG_MANIFEST_NUMBER) from dtdc_f_dispatch where DISPATCH_NUMBER = ? and ORIGIN_OFFICE_ID = ? ";
        }
        if($process_name == 'CD_LT_RR_No'){
            $sql = "select distinct(BAG_MANIFEST_NUMBER) from dtdc_f_dispatch where CD_LT_RR_NUMBER = ? and ORIGIN_OFFICE_ID =  ? ";
        }
        if($process_name == 'bag_manifest'){
            $sql = "select distinct(bag.BAG_MANIFEST_NUMBER),manifest.mnfst_type_id
                    from dtdc_f_disp_bag_mnfst_dtls bag, dtdc_f_manifest manifest
                    where bag.BAG_MANIFEST_NUMBER = manifest.manifest_number AND  bag.BAG_MANIFEST_NUMBER = ? and bag.ORIGIN_OFFICE_ID = ? ";
        }
        $query = $this->db->query($sql,[$dispatch_number, $destBranchId]);
        $result = $query->result_array();
        if($result){

             return  [
                'status' => '1',
                'message' => 'Proceed Further',
                'result_data' => $result
            ];  
        }
        return  [
            'status' => '0',
            'message' => 'CD Dispatch Data Not Found',
            'result_data' => null
        ];

    }

    public function delivery_validate($run_sheet_number, $destBranchId, $process_name){
    
        
        if($process_name == 'CONSG_NUMBER'){
            
                $isConsignment = $this->isConsignment($run_sheet_number, $destBranchId);
                if(!$isConsignment){
                    return  [
                        'status' => '0',
                        'message' => 'Consignment details not found',
                        'result_data' => null
                    ];
                }
                $isDelivered = $this->isDelivered($run_sheet_number, $destBranchId);
                if($isDelivered){
                    return  [
                        'status' => '0',
                        'message' => 'Consignment already Delivered',
                        'result_data' => null
                    ];
                }
                return  [
                    'status' => '1',
                    'message' => 'Proceed Further',
                    'result_data' => $run_sheet_number
                ];
        }
        if($process_name == 'RUN_SHEET_NUMBER'){
            $sql = "select distinct(CONSG_NUMBER) from DTDC_F_DELIVERY where RUN_SHEET_NUMBER = ? and office_id =  ? and CONSG_STATUS = 'A' and delivery_status <> 'D' ";
        }
        if($process_name == 'FDM_NUMBER'){
            $sql = "select distinct(CONSG_NUMBER) from DTDC_F_DELIVERY where FDM_NUMBER = ? and office_id = ? and CONSG_STATUS = 'A' and delivery_status <> 'D' ";
        }       
        $query = $this->db->query($sql,[$run_sheet_number, $destBranchId]);
        $result = $query->result_array();
        if($result){
            //consg_num
            foreach($result as $key => $value){
                $consg_num[] = $value['CONSG_NUMBER'];
            }
            $consg_numbers_csv = implode(',', $consg_num);
            return  [
                'status' => '1',
                'message' => 'Proceed Further',
                'result_data' => $consg_numbers_csv
            ];  
        }
        return  [
            'status' => '0',
            'message' => 'Delivered Data Not Found',
            'result_data' => null
        ];

    }

    public function isConsignment($consg_number, $destBranchId){
        $sql = "select consg_number from dtdc_f_delivery WHERE consg_number = ?  and OFFICE_ID = ? ";
        $query = $this->db->query($sql,[$consg_number, $destBranchId]);
        $result = $query->result_array();
        if($result){
            return true;
        }
        return false;
    }
    public function isDelivered($consg_number, $destBranchId){
        $sql = "select distinct(consg_number) from dtdc_f_delivery WHERE delivery_status = 'D' and consg_number = ? and OFFICE_ID = ? ";
        $query = $this->db->query($sql,[$consg_number, $destBranchId]);
        $result = $query->result_array();
        if($result){
            return true;
        }
        return false;
    }

    public function getConsignmentNumbersForDispatchAndReceive($routingLabel, $loggedInOfficeId){
       
        $user_model = new User_model();
        $consg_numbers_array = [];
        $consg_numbers = $user_model->get_consignment_number_for_bmf($routingLabel, $loggedInOfficeId);
        for ($i = 0; $i < count($consg_numbers); $i++) {
            $second_consg_numbers = $user_model->get_consignment_number_for_bmf($consg_numbers[$i]['consg_number'], $loggedInOfficeId);
            if (count($second_consg_numbers) > 0) {
                for ($j = 0; $j < count($second_consg_numbers); $j++) {
                    array_push($consg_numbers_array, $second_consg_numbers[$j]['consg_number']);
                }
            } else {
                array_push($consg_numbers_array, $consg_numbers[$i]['consg_number']);
            }
        }
        $consg_numbers_csv = implode(',', $consg_numbers_array);
        if (empty($consg_numbers_csv)) {
             return false;
        }

        return $consg_numbers_csv;

    }

    public function getConsignmentNumbers($manifest_number, $manifest_type_id, $manifest_type, $destBranchId){

        $consg_numbers_array = array();
        $consg_numbers_csv = null;
        switch($manifest_type_id){
            case '5':
                $consg_numbers = $this->get_consignment_numbers_for_bmf($manifest_number, $manifest_type);
                if($consg_numbers){
                    foreach($consg_numbers as $key => $consg_number){
                        
                        $second_consg_numbers = $this->get_consignment_numbers_for_bmf($consg_number['consg_number'], $manifest_type);
                        if($second_consg_numbers){
                            foreach($second_consg_numbers as $key => $second_consg_number){
                                $isDelivered = $this->isDelivered($second_consg_number['consg_number'],$destBranchId);
                                if(!$isDelivered){
                                    array_push($consg_numbers_array, "'".$second_consg_number['consg_number']."'");
                                }
                               
                            }
                        }
                    }
                }
             
            break;
            case '2':
                $consg_numbers = $this->get_consignment_numbers_for_bmf($manifest_number, $manifest_type);
                    if ($consg_numbers) {
                        foreach($consg_numbers as $key => $consg_number){
                            $isDelivered = $this->isDelivered($consg_number['consg_number'],$destBranchId);
                            if(!$isDelivered){
                                array_push($consg_numbers_array, "'".$consg_number['consg_number']."'");
                            }
                           
                        }
                    }
            break;
            case '3':
                $consg_numbers = $this->get_consignment_numbers_for_bmf($manifest_number, $manifest_type);
                    if ($consg_numbers) {
                        foreach($consg_numbers as $key => $consg_number){
                            $isDelivered = $this->isDelivered($consg_number['consg_number'],$destBranchId);
                            if(!$isDelivered){
                                array_push($consg_numbers_array, "'".$consg_number['consg_number']."'");
                            }
                          
                        }
                    }
            break;
            default:
               $response = null;
            break;
        }

        if($consg_numbers_array){
           $consg_numbers_csv = implode(',', $consg_numbers_array);
        }
        return $response = [
            'status' => 1,
            'message' => 'Success',
            'consg_numbers' => $consg_numbers_csv
            
        ];

    }

    public function get_consignment_numbers_for_bmf($routing_label, $manifest_type)
    {

        $sql = "SELECT consg_number FROM dtdc_f_manifest WHERE MANIFEST_NUMBER = ? AND MANIFEST_TYPE= ? ";
        
        $query = $this->db->query($sql, [$routing_label , $manifest_type]);

        $result_array = $query->result_array();

        return $result_array; 
    }

    public function getVersionType($consg_number){

        $sql = "SELECT ver_type,consg_number FROM dtdc_f_spl_cust_data WHERE consg_number = ? ";
        
        $query = $this->db->query($sql, [$consg_number]);

        $result_array = $query->result_array();
       
        if($result_array){
            foreach($result_array as $verType){
                $vType = null;
                $versionT = preg_replace("/[^A-Za-z0-9]/", '', $verType['ver_type']);
                $versionType = preg_replace('/[0-9]+/', '', $versionT);

                if($versionType == 'shipsyapp'){
                    $vType = 'APP';
                }
                if($versionType == 'shipsydrop'){
                    $vType = 'EBK';
                }
                if($versionType == 'shipsyorder'){
                    $vType = 'FM';
                }
            }

            return $vType;
        }
       

        return null; 
    }
    

}
