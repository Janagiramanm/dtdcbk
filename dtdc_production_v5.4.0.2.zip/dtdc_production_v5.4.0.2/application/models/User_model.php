<?php

class User_model extends CI_Model
{
    public $version = '4.3.4';
    public $server_date;
    public $server_time;
    public $server_date_time;
    public $server_full_time;

    public $user_id;

    public $response;

    public $test_variable;

    function __construct()
    {
        $dateObj = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
        $this->server_date = $dateObj->format('Y-m-d');
        $this->server_time = $dateObj->format('H:i');
        $this->server_full_time = $dateObj->format('H:i:s');
        $this->server_date_time = $dateObj->format('Y-m-d H:i:s');
    }

    public function validateImei($imei)
    {
        $sql = "select imei, DEACTIVED_ON from dtdc_d_smart_warrior_imei where (imei = ? or imei_2 = ?)";
        $result = $this->db->query($sql, [$imei, $imei]);
        if ($result->num_rows() == 0) {
            return 0;
        } else {

            $deactivatedOn = $result->result_array()[0]['DEACTIVED_ON'];

            if ($deactivatedOn) {
                return 2;
            }

            return 1;
        }
    }


    public function login($input)
    {

        $username = $input['username'];
        $password = $input['password'];
        $lastSyncDate = $input['lastSyncDate'];
        $imei = $input['imei'];
        $local_db_ip = $input['local_db_ip'];
        $apk_version = $input['apkVersion'];
        $apk_date = $input['apkDate'];


        //Always start mysql connection to central
        // $connect = new Connection_model();
        // $connect->central();

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        if ($local_db_ip == 'null') {


            $check_imei = "select imei, DEACTIVED_ON from dtdc_d_smart_warrior_imei where (imei = ? or imei_2 = ?)";
            $result_check_imei = $this->db->query($check_imei, [$imei, $imei]);
            if ($result_check_imei->num_rows() == 0) {
                $this->error_response('Unregistered device');
                return;
            } else {
                $deactivatedOn = $result_check_imei->result_array()[0]['DEACTIVED_ON'];

                if ($deactivatedOn) {
                    $this->error_response('Deactivated device');
                    return;
                }
            }
        }


        $query = "SELECT u.* FROM cg_d_user AS u INNER JOIN cg_d_password AS p ON u.USER_ID=p.USER_ID WHERE u.USER_NAME= ? AND p.PASSWORD= ?";
        $result = $this->db->query($query, [$username, sha1($password)]);

        if ($result->num_rows() > 0) {

            $result_array = $result->result_array();
            $this->user_id = $result_array['0']['USER_ID'];

            $employee_model = new Employee_model();
            $employee_details = $employee_model->get_employee_details($username);

            $current_logged_info = array(
                "userId" => $this->user_id,
                "username" => $employee_details['NAME'],
                "userofficeId" => $employee_details['OFFICE_ID'],
                "userOfficeName" => $employee_details['OFFICE_NAME'],
                "userOfficeCode" => $employee_details['OFFICE_CODE'],
                "userOfficeType" => $employee_details['OFF_TYPE'],
                "reportRegoffId" => $employee_details['REPORT_REGOFF_ID'],
                "employeeId" => $employee_details['EMPLOYEE_ID'],
                "departmentCode" => $employee_details['DEPARTMENT_CODE']
            );


            $office_id = $employee_details['OFFICE_ID'];
            $office_code = $employee_details['OFFICE_CODE'];

            // $dtdc_d_employee = $employee_model->get_all_employees($office_id);
            if ($local_db_ip === 'null') {
                $this->updateModificationDetails($office_code, $imei);
            }

            // $dtdc_d_employee = $employee_model->get_all_employees($office_id);

            $master_details = new Master_details_model();


            if ($local_db_ip != 'null') {
              //  $ip_details = $master_details->get_app_server_ip($office_code);
                $current_logged_info['local_server_ip'] = '';
                $current_logged_info['local_db_ip'] = '';
                $current_logged_info['test_local_server_ip'] = '192.168.1.147';
                $current_logged_info['local_or_central'] = '';
               // $current_logged_info['local_or_central'] =  trim($ip_details[0]['nodal_enabled']);
            } else {
                $ip_details = $master_details->get_app_server_ip($office_code);

                $local_app_server_ip = trim($ip_details[0]['APP_SERVER_IP']);
                $local_db_server_ip = trim($master_details->get_mysql_server_ip($office_code));

                $current_logged_info['local_server_ip'] = $local_app_server_ip;
                $current_logged_info['local_db_ip'] = $local_db_server_ip;
                $current_logged_info['test_local_server_ip'] = '192.168.1.147';
                $current_logged_info['local_or_central'] =  trim($ip_details[0]['nodal_enabled']);
            }

            //Check and update the APK version.

            $apk_needs_update = 0;

            $apk = new Apk();
            if ($apk->isApkDateAndVersionMore($apk_date, $apk_version, $office_id)) {
                $apk->updateApkVersion($apk_date, $apk_version, $office_id);
            }

            if(!$this->isOfficeAvailable($office_id)){
                $apk->insertApkVersion($apk_date, $apk_version, $office_id);
            }

            if ($apk->isApkDateAndVersionLess($apk_date, $office_id)) {
                $apk_needs_update = 1;
            }

            $login_status = 1;
            $log_in_out_id = null;

            if ($apk_needs_update === 0) {
                if ($this->isUserLoggedIn($username)) {
                    $login_status = 0;
                } else {
                    $log_in_out_id = $this->createLoginEntry($username);
                }
            }

            $this->response = array(
                'status' => 1,
                'version' => $this->version,
                'CurrentLoggedInfo' => $current_logged_info,
                'login_status' => $login_status,
                'log_in_out_id' => $log_in_out_id,
                'apk_needs_update' => $apk_needs_update
            );


        } else {
            $this->response = array('status' => 0, "message" => "Invalid Login");
        }

        return $this->response;
    }

    public function isOfficeAvailable($office_id){

        $sql = "select office_id from dtdc_d_war_details where office_id = ? ";

        $query = $this->db->query($sql, [$office_id]);

        return ($query->num_rows() > 0) ? true : false;

    }

    public function isUserLoggedIn($login_name)
    {
        $sql = "select LOG_IN_OUT_ID from cg_f_log_in_out_detl where LOGIN_NAME = ? and LOGOUT_DATE is null and LOGOUT_TIME is null";

        $query = $this->db->query($sql, [$login_name]);

        return ($query->num_rows() > 0) ? true : false;
    }

    public function updateModificationDetails($office_code, $imei)
    {
        $sql = "update dtdc_d_smart_warrior_imei set mod_date_time = ?, updated_by = ? where imei = ? or imei_2 = ?";
        $this->db->query($sql, [$this->server_date_time, $office_code, $imei, $imei]);
        if ($this->db->affected_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }


    public function createLoginEntry($login_name)
    {
        $insert_data = [
            'LOGIN_NAME' => $login_name,
            'LOGIN_DATE' => $this->server_date,
            'LOGIN_TIME' => $this->server_time
        ];

        $this->db->insert('cg_f_log_in_out_detl', $insert_data);

        return $this->db->insert_id();

    }

    public function logout($log_in_out_id)
    {
        $sql = "update cg_f_log_in_out_detl set LOGOUT_DATE = ?, LOGOUT_TIME = ? where LOG_IN_OUT_ID = ?";
        $query = $this->db->query($sql, [$this->server_date, $this->server_time, $log_in_out_id]);

        return ($this->db->affected_rows() > 0) ? true : false;

    }

    public function manualLogout($username, $password)
    {
        $sql1 = "SELECT u.* FROM cg_d_user AS u INNER JOIN cg_d_password AS p ON u.USER_ID=p.USER_ID WHERE u.USER_NAME = ? AND p.PASSWORD= ?";
        $query1 = $this->db->query($sql1, [$username, sha1($password)]);
        $login_out_ids = [];
        if ($query1->num_rows() > 0) {
            $sql2 = "Select LOG_IN_OUT_ID from cg_f_log_in_out_detl where LOGIN_NAME = ? and LOGOUT_DATE is null and LOGOUT_TIME is null";
            $query2 = $this->db->query($sql2, [$username]);
            if ($query2->num_rows() > 0) {
                $result = $query2->result_array();
                foreach ($result as $value) {
                    array_push($login_out_ids, $value['LOG_IN_OUT_ID']);
                }
                $sql3 = "update cg_f_log_in_out_detl set LOGOUT_DATE = '2018-06-07', LOGOUT_TIME = '12:30:30' where LOG_IN_OUT_ID in ?";
                $query3 = $this->db->query($sql3, [$login_out_ids]);
                return 1;
            } else {
                return 1;
            }
        } else {
            return 0;
        }
    }


    public function masterdatasync($input)
    {
        $lastSyncDate = isset($input['lastSyncDate']) ? $input['lastSyncDate'] : $this->error_response('Error : lastSyncDate is not set.');
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        $office_id = isset($input['officeId']) ? $input['officeId'] : $this->error_response('Error: officeId is not set.');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $employee_model = new Employee_model();
        $dtdc_d_employee = $employee_model->get_all_employees($office_id);

        $master_details = new Master_details_model();

        $flights = $master_details->get_flight_details($office_id);
        $trains = $master_details->get_train_details($office_id);
        $franchisees = $master_details->get_franchisee_details($office_id);
        $vehicles = $master_details->get_vehicle_details($office_id);
        $ts_mapping = $master_details->get_ts_mapping($office_id);

        $dtdc_d_route = $master_details->sync_dtdc_d_route($lastSyncDate);
        $dtdc_d_trns_time = $master_details->sync_all_trns_time($lastSyncDate);
        $dtdc_d_otc_master = $master_details->sync_dtdc_d_otc_master($lastSyncDate);
        $dtdc_d_direction_connections = $master_details->sync_dtdc_d_vendor($lastSyncDate);
        $dtdc_d_coloader = $master_details->sync_dtdc_d_coloader($lastSyncDate);
        $dtdc_d_routing_master = $master_details->sync_dtdc_d_routing_master($lastSyncDate);
        $dtdc_d_office = $master_details->sync_dtdc_d_office_master($lastSyncDate);
        $dtdc_d_pincode = $master_details->sync_dtdc_d_pincode($lastSyncDate);
        $dtdc_d_reason = $master_details->sync_dtdc_d_reason($lastSyncDate);
        $commodity_data = $master_details->get_commodity_master();

        $this->response = array(
            'status' => 1,
            'flights' => $flights,
            'trains' => $trains,
            'vehicles' => $vehicles,
            'franchisess' => $franchisees,
            'dtdc_d_ts_mapping' => $ts_mapping,
            'dtdc_d_employee' => $dtdc_d_employee,
            'dtdc_d_route' => $dtdc_d_route,
            'dtdc_d_trns_time' => $dtdc_d_trns_time,
            'dtdc_d_otc_master' => $dtdc_d_otc_master,
            'dtdc_d_direction_connections' => $dtdc_d_direction_connections,
            'dtdc_d_coloader' => $dtdc_d_coloader,
            'dtdc_d_routing_master' => $dtdc_d_routing_master,
            'dtdc_d_office' => $dtdc_d_office,
            'dtdc_d_pincode' => $dtdc_d_pincode,
            'dtdc_d_reason' => $dtdc_d_reason,
            'commodity_data' => $commodity_data
        );

        return $this->response;


    }

    public function masterdata($input)
    {
        $connect = new Connection_model();
        $connect->central();
        $master_details = new Master_details_model();
        $routing_details = $master_details->get_dtdc_d_routing_master();
        $dtdc_d_office = $master_details->get_dtdc_d_office_master();
        $dtdc_d_pincode = $master_details->get_dtdc_d_pincode();
        $dtdc_d_reasons = $master_details->get_reasons();

        $this->response = array(
            'status' => 1,
            'dtdc_d_routing_master' => $routing_details,
            'dtdc_d_office' => $dtdc_d_office,
            'dtdc_d_pincode' => $dtdc_d_pincode,
            'dtdc_d_reasons' => $dtdc_d_reasons
        );

        return $this->response;
    }

    public function masterdatacoloader($input)
    {
        $connect = new Connection_model();
        $connect->central();
        $master_details = new Master_details_model();
        $dtdc_d_coloader = $master_details->get_all_coloader();
        $this->response = array('dtdc_d_coloader' => $dtdc_d_coloader);

        return $this->response;

    }

    public function masterdatatrnstime($input)
    {
        $connect = new Connection_model();
        $connect->central();
        $master_details = new Master_details_model();
        $dtdc_d_trns_time = $master_details->get_all_trns_time();
        $this->response = array('dtdc_d_trns_time' => $dtdc_d_trns_time);

        return $this->response;
    }

    public function masterdataroute($input)
    {
        $connect = new Connection_model();
        $connect->central();
        $master_details = new Master_details_model();
        $dtdc_d_route = $master_details->get_all_route();
        $this->response = array('dtdc_d_route' => $dtdc_d_route);

        return $this->response;
    }

    public function masterdataotcmaster($input)
    {
        $connect = new Connection_model();
        $connect->central();
        $master_details = new Master_details_model();
        $dtdc_d_otc_master = $master_details->get_all_otc_master();
        $this->response = array('dtdc_d_otc_master' => $dtdc_d_otc_master);

        return $this->response;
    }

    public function masterdatadirectconnection($input)
    {
        $connect = new Connection_model();
        $connect->central();
        $master_details = new Master_details_model();
        $dtdc_d_direction_connections = $master_details->get_all_direct_connections();
        $this->response = array('dtdc_d_direction_connections' => $dtdc_d_direction_connections);

        return $this->response;
    }

    //masterdatastatuscode
    public function masterdatastatuscode($input)
    {
        $connect = new Connection_model();
        $connect->central();
        $master_details = new Master_details_model();
        $status_codes = $master_details->get_status_code_master();
        $this->response = array('status_codes' => $status_codes);

        return $this->response;
    }

    public function masterdatacommodity($input)
    {
        $connect = new Connection_model();
        $connect->central();
        $master_details = new Master_details_model();
        $commodity_data = $master_details->get_commodity_master();
        $this->response = array('commodity_data' => $commodity_data);

        return $this->response;
    }

    public function masterdataservicemoderelation($input)
    {
        $connect = new Connection_model();
        $connect->central();
        $master_details = new Master_details_model();
        $service_mode_relation_master = $master_details->get_service_mode_relation_master();
        $this->response = array('service_mode_relation_master' => $service_mode_relation_master);

        return $this->response;
    }

    public function masterdatavas($input)
    {
        $connect = new Connection_model();
        $connect->central();
        $master_details = new Master_details_model();
        $vas_data = $master_details->get_vas_master();
        $this->response = array('vas_data' => $vas_data);

        return $this->response;
    }

    public function devicestatus($input)
    {

        $imei = isset($input['imei']) ? $input['imei'] : $this->error_response('imei is required');
        // $imei = "1234567838383839";
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
        $activeStatus = isset($input['activeStatus']) ? $input['activeStatus'] : $this->error_response('activeStatus is required');
        $activeStatus = 'inactive';
        if ($activeStatus == 'active') {
            $query = "update dtdc_d_smart_warrior_imei set status = 1 where imei = ?";
        } else {
            $query = "update dtdc_d_smart_warrior_imei set status = 0 where imei = ?";
        }

        if ($this->db->query($query, [$imei])) {
            $response = array('status' => 1, 'message' => 'Device status changed to ' . $activeStatus);
        }

        return $response;
    }

    public function savestatuscode($input)
    {
        $hed_id = array();
        $duplicates = array();
        $mode_time_exp = explode(':', $this->server_time);
        $mode_time = implode('', $mode_time_exp);
        $nodeId = isset($input['nodeId']) ? $input['nodeId'] : $this->error_response('Error: nodeId is not set.');
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
        $loggedInOfficeType = isset($input['loggedInOfficeType']) ? $input['loggedInOfficeType'] : $this->error_response('Error: loggedInOfficeType is not set.');
        $loggedInOfficeId = isset($input['loggedInOfficeId']) ? $input['loggedInOfficeId'] : $this->error_response('Error: loggedInOfficeId is not set.');
        $loggedInOfficeCode = isset($input['loggedInOfficeCode']) ? $input['loggedInOfficeCode'] : $this->error_response('Error: loggedInOfficeCode is not set.');
        $userId = isset($input['userId']) ? $input['userId'] : $this->error_response('Error: userId is not set.');
        $shipments = isset($input['shipments']) ? $input['shipments'] : $this->error_response('Error: shipments is not set.');

        $isTable_dtdc_f_hb_excp_cn_status = null;
        if ($this->db->table_exists('dtdc_f_hb_excp_cn_status') )
        {
            $isTable_dtdc_f_hb_excp_cn_status = 'yes';
        }
        for ($d = 0; $d < count($shipments); $d++) {
            # code...
            $erm_categ_id = isset($shipments[$d]['erm_categ_id']) ? $shipments[$d]['erm_categ_id'] : $this->error_response('Error: erm_categ_id is not set.');
            $erm_id = isset($shipments[$d]['erm_id']) ? $shipments[$d]['erm_id'] : $this->error_response('Error: erm_id is not set.');
            $routingLabel = isset($shipments[$d]['routingLabel']) ? $shipments[$d]['routingLabel'] : $this->error_response('Error: routingLabel is not set.');
            $transaction_ref = isset($shipments[$d]['transaction_ref']) ? $shipments[$d]['transaction_ref'] : $this->error_response('Error: transaction_ref is not set.');
            $statusCode = isset($shipments[$d]['statusCode']) ? $shipments[$d]['statusCode'] : $this->error_response('Error: statusCode is not set.');
            $remarks = isset($shipments[$d]['remarks']) ? $shipments[$d]['remarks'] : $this->error_response('Error: remarks is not set.');
//          $processType = isset($shipments[$i]['processType']) ? $shipments[$i]['processType'] : $this->error_response('Error: processType is not set.');

            /** 15-04-2010 shashi instruction */
            //$shipment_type = isset($shipments[$d]['shipmentType']) ? $shipments[$d]['shipmentType'] : $this->error_response('Error: shipmentType is not set.');
            $process_type = isset($shipments[$d]['shipmentType']) ? $shipments[$d]['shipmentType'] : $this->error_response('Error: shipmentType is not set.');
            $consg_numbers_csv = isset($shipments[$d]['consg_numbers']) ? $shipments[$d]['consg_numbers'] : $this->error_response('Error: consg_numbers is not set.');

            $image = isset($shipments[$d]['parcelImage']) ? $shipments[$d]['parcelImage'] : $this->error_response('Error: parcelImage is not set.');

            //Check if routing lable already saved
//			if ( $this->is_status_code_saved( $routingLabel ) ) {
//				array_push( $duplicates, $routingLabel );
//			} else {
            if ($image != 'null') {
                $blob = base64_decode($image);
            } else {
                $blob = null;
            }

            if ($remarks == 'null') {
                $remarks = null;
            }

            $this->test_variable = 'calling process_type';

            /* 15-04-2010 shashi instruction it was commented
            $process_type = $this->get_process_type($shipment_type, $routingLabel, $loggedInOfficeId);

            //cnsg numbers
            $consg_numbers_array = array();
            if ($shipment_type == 'BMF') {
                $consg_numbers = $this->get_consignment_number_for_bmf($routingLabel, $loggedInOfficeId);
                for ($i = 0; $i < count($consg_numbers); $i++) {
                    $second_consg_numbers = $this->get_consignment_number_for_bmf($consg_numbers[$i]['consg_number'], $loggedInOfficeId);
                    if (count($second_consg_numbers) > 0) {
                        for ($j = 0; $j < count($second_consg_numbers); $j++) {
                            array_push($consg_numbers_array, $second_consg_numbers[$j]['consg_number']);
                        }
                    } else {
                        array_push($consg_numbers_array, $consg_numbers[$i]['consg_number']);
                    }
                }
            }

            if ($shipment_type == 'PMF') {
                $consg_numbers = $this->get_consignment_number_for_pmf($routingLabel, $loggedInOfficeId);
                for ($i = 0; $i < count($consg_numbers); $i++) {
                    $second_consg_numbers = $this->get_consignment_number_for_pmf($consg_numbers[$i]['consg_number'], $loggedInOfficeId);
                    if (count($second_consg_numbers) > 0) {
                        for ($j = 0; $j < count($second_consg_numbers); $j++) {
                            array_push($consg_numbers_array, $second_consg_numbers[$j]['consg_number']);
                        }
                    } else {
                        array_push($consg_numbers_array, $consg_numbers[$i]['consg_number']);
                    }
                }
            }

            if ($shipment_type == 'CON') {
                $consg_numbers_array = array($routingLabel);
            }

            if ($shipment_type == 'BMF/PMF') {
                $consg_numbers = $this->get_consignment_number_for_bmf($routingLabel, $loggedInOfficeId);
                for ($i = 0; $i < count($consg_numbers); $i++) {
                    $second_consg_numbers = $this->get_consignment_number_for_bmf($consg_numbers[$i]['consg_number'], $loggedInOfficeId);
                    if (count($second_consg_numbers) > 0) {
                        for ($j = 0; $j < count($second_consg_numbers); $j++) {
                            array_push($consg_numbers_array, $second_consg_numbers[$j]['consg_number']);
                        }
                    } else {
                        array_push($consg_numbers_array, $consg_numbers[$i]['consg_number']);
                    }

                }

                if (count($consg_numbers) == 0) {
                    $consg_numbers = $this->get_consignment_number_for_pmf($routingLabel, $loggedInOfficeId);
                    for ($i = 0; $i < count($consg_numbers); $i++) {
                        $second_consg_numbers = $this->get_consignment_number_for_pmf($consg_numbers[$i]['consg_number'], $loggedInOfficeId);
                        if (count($second_consg_numbers) > 0) {
                            for ($j = 0; $j < count($second_consg_numbers); $j++) {
                                array_push($consg_numbers_array, $second_consg_numbers[$j]['consg_number']);
                            }
                        } else {
                            array_push($consg_numbers_array, $consg_numbers[$i]['consg_number']);
                        }
                    }
                }


            }

            $consg_numbers_csv = implode(',', $consg_numbers_array);
            if (empty($consg_numbers_csv)) {
                $consg_numbers_csv = $routingLabel;
            }*/


            //@todo parcel image
            $insert_data = array(
                'HED_CATEG_ID' => $erm_categ_id,
                'HED_TRANS_NO' => $routingLabel,
                'HED_REASON_ID' => $erm_id,
                'HED_REMARKS' => $remarks,
                'OFFICE_CODE' => $loggedInOfficeCode,
                'MOD_DATE' => $this->server_date_time,
                'MOD_TIME' => $mode_time,
                'USERID' => $userId,
                'NODEID' => $nodeId,
                'OFFICE_TYPE' => $loggedInOfficeType,
                'READ_BY_LOCAL' => 'Y',
                'RECORD_STATUS' => 'A',
                'DB_SERVER' => 'N',
                'MANUAL_DOWNLOAD_FLAG' => 'N',
                'PROCESS_TYPE' => $process_type,
                'TRANSACTION_REF' => $transaction_ref,
                'HED_DATE' => $this->server_date_time,
                'CONSG_NOS' => $consg_numbers_csv,
                'CAPTURE_IMAGE' => $blob
            );
            $this->db->insert('dtdc_f_hb_exception_dtl', $insert_data);

            $insert_id = $this->db->insert_id();
            if($insert_id){

                if($isTable_dtdc_f_hb_excp_cn_status == 'yes'){
                    $consg_numbers = explode(',',$consg_numbers_csv);
                    foreach($consg_numbers as $key => $consg_number){

                        $insert_cn_status_data = array(
                            'CONSG_NUMBER' => $consg_number,
                            'STATUS_CODE_DESC' => $statusCode,
                            'HED_ID_REF' => $insert_id,
                            'HED_TRANS_NO' => $routingLabel,
                            'HED_CATEG_ID' => $erm_categ_id,
                            'HED_REASON_ID' => $erm_id,
                            'OFFICE_CODE' => $loggedInOfficeCode,
                            'HED_DATE_TIME' => $this->server_date_time,
                            'LAST_UPDATED_DATETIME' => $this->server_date_time,
                            'NODE_ID' => $nodeId,
                            'READ_BY_LOCAL' => 'Y',
                            'RECORD_STATUS' => 'A',

                        );
                        $this->db->insert('dtdc_f_hb_excp_cn_status ', $insert_cn_status_data);
                    }
                }

            }
            array_push($hed_id, $insert_id);

            //}
        }

       /// echo 'END'; exit;

        $response = array(
            'status' => 1,
            'hed_id_array' => $hed_id,
            'duplicates' => $duplicates,
            'test_variable' => $this->test_variable
        );

        return $response;

    }

    public function is_status_code_saved($routing_label)
    {
        $sql = "SELECT hed_id FROM dtdc_f_hb_exception_dtl WHERE HED_TRANS_NO = ?";
        $query = $this->db->query($sql, array($routing_label));
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function is_status_code_saved_2($routing_label, $officeCode)
    {
        $sql = "SELECT hed_id FROM dtdc_f_hb_exception_dtl WHERE HED_TRANS_NO = ? AND OFFICE_CODE = ? AND MOD_DATE = CURDATE()";
        $query = $this->db->query($sql, array($routing_label, $officeCode));
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function get_process_type($shipment_type, $routing_label, $logged_in_office_id)
    {
        $process_type = null;
        switch ($shipment_type) {
            case 'BMF':
                # code...
                $this->test_variable = 'inside bmf';
                $process_type = $this->get_process_type_from_cd_dispatch($routing_label, $logged_in_office_id);
                if (!$process_type) {
                    $process_type = $this->get_process_type_from_cd_receive($routing_label, $logged_in_office_id);
                }
                break;
            case 'PMF':
                $process_type = $this->get_process_type_from_manifest_table($routing_label, $logged_in_office_id);
                break;
            case 'CON':
                $process_type = $this->get_process_type_from_manifest_table($routing_label, $logged_in_office_id);
                if (!$process_type) {
                    $process_type = $this->get_process_type_from_delivery($routing_label);
                    if (!$process_type) {
                        $process_type = $this->get_process_type_from_booking($routing_label);
                    }
                }


                break;
            case 'BMF/PMF':
                $this->test_variable = 'inside bmf/pmf';
                $process_type = $this->get_process_type_from_cd_dispatch($routing_label, $logged_in_office_id);
                if (!$process_type) {
                    $this->test_variable = 'inside bmf/pmf - not found in cd_dispatch';
                    $process_type = $this->get_process_type_from_cd_receive($routing_label, $logged_in_office_id);
                    if($process_type){
                        $this->test_variable =  $process_type;
                    }
                }
                if (!$process_type) {

                    $this->test_variable = 'inside bmf/pmf - not found in cd_receive';
                    $process_type = $this->get_process_type_from_manifest_table($routing_label, $logged_in_office_id);
                    if($process_type){
                        $this->test_variable =  $process_type;
                    }
                }

                if (!$process_type) {
                    $this->test_variable = 'inside bmf/pmf - not found in manifest_table';
                }
                break;

            default:
                # code...
                $process_type = null;
                break;
        }

        return $process_type;

    }

    public function get_process_type_from_manifest_table($manifest_number, $logged_in_office_id)
    {
        $process_type = null;
        $sql = "(select manifest_id, manifest_type, RECORD_ENTRY_DATETIME as datetime from dtdc_f_manifest where manifest_number = ? and ORIG_BRNCH_ID = ?) union (select manifest_id, manifest_type, RECORD_ENTRY_DATETIME as datetime from dtdc_f_manifest where manifest_number = ? and RECV_OFFICE_ID = ?) order by datetime desc";
        $query = $this->db->query($sql, array(
            $manifest_number,
            $logged_in_office_id,
            $manifest_number,
            $logged_in_office_id
        ));

        if ($query->num_rows() > 0) {
            $result_array = $query->result_array()[0];
            $manifest_type = $result_array['manifest_type'];
            if ($manifest_type == 'O') {
                $process_type = 'MANIFEST-O';
            }
            if ($manifest_type == 'I') {
                $process_type = 'MANIFEST-I';
            }
        }

        return $process_type;
    }

    public function get_process_type_from_cd_dispatch($bag_manifest_number, $logged_in_office_id)
    {
        $process_type = null;

        $sql_cd_dispatch = "SELECT DISP_BAG_MNFST_DETL_ID FROM dtdc_f_disp_bag_mnfst_dtls WHERE bag_manifest_number = ? AND ORIGIN_OFFICE_ID = ?";

        $query_cd_dispatch = $this->db->query($sql_cd_dispatch, array($bag_manifest_number, $logged_in_office_id));

        if ($query_cd_dispatch->num_rows() > 0) {
            $process_type = 'CD DISPATCH';
        } else {
            $process_type = null;
        }

        return $process_type;

    }

    public function get_process_type_from_cd_receive($bag_manifest_number, $logged_in_office_id)
    {
        $process_type = null;

        $sql_cd_receive = "SELECT CD_RECV_MNFST_DTLS_ID FROM dtdc_f_cd_recv_mnfst_dtls WHERE BAG_MANIFEST_NUMBER = ? AND DEST_OFFICE_ID = ?";

        $query_cd_receive = $this->db->query($sql_cd_receive, array($bag_manifest_number, $logged_in_office_id));

        if ($query_cd_receive->num_rows() > 0) {
            $process_type = 'CD RECEIVE';
        } else {
            $process_type = null;
        }

        return $process_type;
    }

    public function get_process_type_from_booking($routing_label, $logged_in_office_id = null)
    {
        $process_type = null;

        $sql = "SELECT booking_id FROM dtdc_f_booking WHERE consg_number = ?";

        $query = $this->db->query($sql, array($routing_label));

        if ($query->num_rows() > 0) {
            $process_type = 'BOOKING';
        } else {
            $process_type = null;
        }

        return $process_type;
    }

    public function get_process_type_from_delivery($routing_label, $logged_in_office_id = null)
    {
        $process_type = null;

        $sql = "SELECT delivery_id FROM dtdc_f_delivery WHERE consg_number = ?";

        $query = $this->db->query($sql, array($routing_label));

        if ($query->num_rows() > 0) {
            $process_type = 'DELIVERY';
        } else {
            $process_type = null;
        }

        return $process_type;
    }


    public function get_consignment_number_for_pmf($routing_label, $logged_in_office_id)
    {

        $sql = "SELECT consg_number FROM dtdc_f_manifest WHERE manifest_number=? AND manifest_type='O' AND ORIG_BRNCH_ID=?
UNION
SELECT consg_number FROM dtdc_f_manifest WHERE manifest_number=? AND manifest_type='I' AND RECV_OFFICE_ID = ?";

        $query = $this->db->query($sql, array(
            $routing_label,
            $logged_in_office_id,
            $routing_label,
            $logged_in_office_id
        ));

        $result_array = $query->result_array();

        return $result_array;

    }

    public function get_consignment_number_for_bmf($routing_label, $logged_in_office_id)
    {

        $sql = "SELECT consg_number FROM dtdc_f_manifest WHERE MANIFEST_NUMBER = ? AND MANIFEST_TYPE='O'";

        $query = $this->db->query($sql, array($routing_label));

        $result_array = $query->result_array();

        return $result_array;
    }


    public function error_response($e)
    {
        $response = array('status' => 0, 'message' => $e);
        echo json_encode($response);
        exit;
    }

    public function getStatusOfConsignment($consgNumber, $office_code)
    {
        $sql = "select HED_ID from dtdc_f_hb_exception_dtl where OFFICE_CODE = ? and DATE(HED_DATE) = DATE(NOW()) and HED_TRANS_NO = ?";
        $query = $this->db->query($sql, array($office_code, $consgNumber));
        if ($query->num_rows() > 0) {
            $status = array('status' => 1);
        } else {
            $status = array('status' => 0);
        }

        return $status;
    }

    public function updateStatusCodeForConsignment($consgignmentNumber, $officeCode, $userId, $nodeId, $officeType, $processType)
    {
        if ($this->is_status_code_saved_2($consgignmentNumber, $officeCode)) {
            return 0;
        }
        $mode_time_exp = explode(':', $this->server_time);
        $mode_time = implode('', $mode_time_exp);
        $insert_data = array(
            'HED_CATEG_ID' => 11,
            'HED_TRANS_NO' => $consgignmentNumber,
            'HED_REASON_ID' => 314,
            'HED_REMARKS' => "Auto Captured",
            'OFFICE_CODE' => $officeCode,
            'MOD_DATE' => $this->server_date,
            'MOD_TIME' => $mode_time,
            'USERID' => $userId,
            'NODEID' => $nodeId,
            'OFFICE_TYPE' => $officeType,
            'READ_BY_LOCAL' => 'Y',
            'RECORD_STATUS' => 'A',
            'DB_SERVER' => 'N',
            'MANUAL_DOWNLOAD_FLAG' => 'N',
            'PROCESS_TYPE' => $processType,
            'TRANSACTION_REF' => "CONSG_NUMBER",
            'HED_DATE' => $this->server_date_time
        );

        $this->db->insert('dtdc_f_hb_exception_dtl', $insert_data);
        $insert_id = $this->db->insert_id();

        return $insert_id;
    }

    public function hhtLoginValidation($input)
    {
        $username = $input['username'];
        $imei = $input['imei'];
        $local_db_ip = $input['local_db_ip'];

        $connect = new Connection_model();
        $connect->central();

        $check_imei = "select imei, DEACTIVED_ON from dtdc_d_smart_warrior_imei where (imei = ? or imei_2 = ?) and DEVICE_MAKE=?";
        $result_check_imei = $this->db->query($check_imei, [$imei, $imei, $username]);
        if ($result_check_imei->num_rows() == 0) {
            $this->response = array('status' => 0);

        } else {
            $this->response = array('status' => 1);
        }
        return $this->response;

    }

    public function getProductDetails(){
        $sql = "select PRODUCT_ID,product_type,PRODUCT_NAME from dtdc_d_product where product_category='DOM'";
        $query = $this->db->query($sql);
        $result = $query->result_array();
        if($result){
            return [
                'status' => 1,
                'data' => $result
            ];
        }
        return [
            'status' => 0,
            'data' => 'Product data not found'
        ];
    }

    public function getAllVehicles(){

        $sql = "select vehicle_id,vehicle_code,reg_number from dtdc_d_vehicle";
        $query = $this->db->query($sql);
        $result = $query->result_array();
        if($result){
            return [
                'status' => 1,
                'data' => $result
            ];
        }
        return [
            'status' => 0,
            'data' => 'Vehicle data not found'
        ];
    }

    //30-04-2020
    public function masterdatacoloadersec($input)
    {
        $connect = new Connection_model();
        $connect->central();
        $master_details = new Master_details_model();
        $dtdc_d_coloader = $master_details->get_all_coloader_sec();
        $this->response = array('dtdc_d_coloader' => $dtdc_d_coloader);

        return $this->response;

    }

    public function masterdatadirectconnectionsec($input)
        {
            $connect = new Connection_model();
            $connect->central();
            $master_details = new Master_details_model();
            $dtdc_d_direction_connections = $master_details->get_all_direct_connections_sec();
            $this->response = array('dtdc_d_direction_connections' => $dtdc_d_direction_connections);

            return $this->response;
        }
    public function masterdataotcmastersec($input)
        {
            $connect = new Connection_model();
            $connect->central();
            $master_details = new Master_details_model();
            $dtdc_d_otc_master = $master_details->get_all_otc_master_sec();
            $this->response = array('dtdc_d_otc_master' => $dtdc_d_otc_master);

            return $this->response;
        }
    public function masterdatatrnstimesec($input)
        {
            $connect = new Connection_model();
            $connect->central();
            $master_details = new Master_details_model();
            $dtdc_d_trns_time = $master_details->get_all_trns_time_sec();
            $this->response = array('dtdc_d_trns_time' => $dtdc_d_trns_time);

            return $this->response;
        }
    public function masterdataroutesec($input)
        {
            $connect = new Connection_model();
            $connect->central();
            $master_details = new Master_details_model();
            $dtdc_d_route = $master_details->get_all_route_sec();
            $this->response = array('dtdc_d_route' => $dtdc_d_route);

            return $this->response;
        }

    // 04-05-2020
    public function masterDataForMasterConRec($input){

        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        $office_id = isset($input['officeId']) ? $input['officeId'] : $this->error_response('Error: officeId is not set.');
        $interval_days = isset($input['interval_days']) ? $input['interval_days'] : $this->error_response('Error: interval_days is not set.');
        $modeId = isset($input['mode_id']) ? $input['mode_id'] : $this->error_response('Error: mode_id is not set.');
        
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        // $query =   "select  a.dispatch_id,b.bag_manifest_number,a.origin_office_id,
        //             Left(a.dispatch_number, 11) as dispatch_number,
        //             IFNULL(b.cd_lt_rr_number,a.cd_lt_rr_number) as cd_lt_rr_number,
        //             a.vehicle_id,a.dest_office_id,a.mode_id,
        //             a.billing_id,a.load_sent_date,a.load_sent_time,a.trans_create_date,a.cd_date,a.cd_time,substr(a.remarks,1,150) as remarks1,a.service_type,
        //             a.charged_weight,a.load_sender_employee_id,a.node_id,a.user_id,a.trans_last_modified_date,b.loader_id,
        //             CASE WHEN expected_dep='' THEN (SELECT '00') WHEN length(expected_dep)>=4 THEN (SELECT time_format(expected_dep,'%H%i')) ELSE ifnull(a.expected_dep,0) END expected_dep,
        //             CASE WHEN expected_arrival='' THEN (SELECT '00') WHEN length(expected_arrival)>=4 THEN (SELECT time_format(expected_arrival,'%H%i')) WHEN expected_arrival='NA' THEN(SELECT '00') ELSE ifnull(a.expected_arrival,0) END expected_arri,
        //             a.obc_code,a.pnr_number,a.ticket_cost,substr(b.remarks,1,50) as remarks2,b.physical_weight,b.temp_vehical_code,b.vendor_id,b.airport_id,b.train_id,b.vehicle_number
        //             from dtdc_ctbs_plus.dtdc_f_dispatch a,dtdc_ctbs_plus.dtdc_f_disp_bag_mnfst_dtls b
        //             where   a.dispatch_id = b.dispatch_id
        //             and a.dest_office_id= ?
        //             and a.trans_create_date between date_sub(curdate(),interval ".$interval_days." day) and curdate()";

        $query = "SELECT a.dispatch_id,b.bag_manifest_number,a.origin_office_id,
        FUNC_GET_CTBSPLUS_CODE(a.origin_office_id,'dtdc_d_office') ORG_OFF_Code,
        IFNULL(b.cd_lt_rr_number,a.cd_lt_rr_number) cd_lt_rr_number,
        Left(a.dispatch_number, 11) as dispatch_number,
        a.dest_office_id,
        FUNC_GET_CTBSPLUS_CODE(a.dest_office_id,'dtdc_d_office') DEST_OFF_Code,
        a.vehicle_id,a.mode_id,FUNC_GET_CTBSPLUS_CODE(a.mode_id,'dtdc_d_mode') mode_code,
        a.billing_id,
        b.physical_weight,a.load_sent_date,a.load_sent_time,a.trans_create_date,a.cd_date,a.cd_time,
        substr(a.remarks,1,150) as remarks,
        a.service_type,
        b.loader_id,
        FUNC_GET_CTBSPLUS_NAME(b.loader_id,'dtdc_d_coloader') dtdc_d_coloader,
        b.vendor_id,
        FUNC_GET_CTBSPLUS_NAME(b.vendor_id,'dtdc_d_vendor') dtdc_d_vendor,
        a.obc_code,b.airport_id,
        CASE WHEN (A.MODE_ID=1 OR A.MODE_ID=3 OR A.MODE_ID=12) THEN FUNC_GET_CTBSPLUS_CODE(B.AIRPORT_ID,'DTDC_D_AIRPORT')
        WHEN A.MODE_ID=2 THEN IFNULL(FUNC_GET_CTBSPLUS_NAME(A.VEHICLE_ID,'DTDC_D_VEHICLE'),CONCAT(A.TEMP_VEHICAL_CODE,'' ,A.TEMP_VEHICAL_NAME))
        WHEN A.MODE_ID=10 THEN FUNC_GET_CTBSPLUS_NAME(A.TRAIN_ID,'DTDC_D_TRAIN') END AS FRNAME,
        b.train_id,ifnull(b.vehicle_number,b.temp_vehical_code) vehicle_number
        from dtdc_ctbs_plus.dtdc_f_dispatch a,dtdc_ctbs_plus.dtdc_f_disp_bag_mnfst_dtls b
        where a.dispatch_id = b.dispatch_id
        and a.dest_office_id= ?
        and a.MODE_ID = ? and a.trans_create_date between date_sub(curdate(),interval ? day) and curdate();";

        $result = $this->db->query($query, [$office_id, $modeId, $interval_days]);
        $response = $result->result_array();
        if($response){
            return [
                'status' => 1,
                'data' => $response
            ];
        }
        return [
            'status' => 0,
            'data' => 'Data not found'
        ];


    }

    public function getMaxDeliveryAttempt(){
        $sql = "select param_value from dtdc_d_configurable_params where id= 31 ";
        $query = $this->db->query($sql);
        $result = $query->result_array();
        if($result){
            return [
                'status' => 1,
                'data' => $result
            ];
        }
        return [
            'status' => 0,
            'data' => 'Data Not Found'
        ];
    }

    public function checkCentralOrLocal($input){
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        $username = isset($input['username']) ? $input['username'] : $this->error_response('Error: username is not set.');
       

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $employee_model = new Employee_model();
        $employee_details = $employee_model->get_employee_details($username);
        if(!$employee_details){
            return $this->response = array(
                'status' => 0,
                'data' => 'Data Not Found'
            );
        }
        $office_code = $employee_details['OFFICE_CODE'];
        $master_details = new Master_details_model();
        $ip_details = $master_details->get_app_server_ip($office_code);
        $current_logged_info = null;
        if(!$ip_details){
            return $this->response = array(
                'status' => 0,
                'data' => 'IP Details Not Found'
            );  
        }
        $current_logged_info['nodal_enabled'] =  trim($ip_details[0]['nodal_enabled']);
            
        return $this->response = array(
                    'status' => 1,
                    'data' => $current_logged_info
                );
    }

    public function reprintingRoutingLabelForPacketManifest(){
        $Awbnumber = isset($input['Awbnumber']) ? $input['Awbnumber'] : $this->error_response('Error: Awbnumber is not set.');
        $Type_flag = isset($input['Type_flag']) ? $input['Type_flag'] : $this->error_response('Error: Type_flag is not set.');
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        if($Type_flag == 'packetmanifest'){
            
        }

    
    }

}
