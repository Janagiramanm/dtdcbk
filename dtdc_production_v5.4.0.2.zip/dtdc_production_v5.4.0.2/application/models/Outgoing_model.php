<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Outgoing_model extends CI_Model
{

    public $server_date;
    public $server_time;
    public $server_date_time;

    public $response;
    //user details
    public $currentLoginInfo = array();
    public $support_model;
    public $bookingModel;


    function __construct()
    {
        # code...
        parent::__construct();
        $dateObj = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
        $this->server_date = $dateObj->format('Y-m-d');
        $this->server_time = $dateObj->format('H:i');
        $this->server_date_time = $dateObj->format('Y-m-d H:i:s');

        $this->support_model = new Support_model();
        $this->bookingModel = new Booking_model();
    }


    //outgoingbagmanifestfordox
    public function saveoutgoingbagmanifestfordox($input)
    {

        $server_date = $this->server_date;
        $server_time = $this->server_time;
        $server_date_time = $this->server_date_time;
        $save_response = array();
        $save_manifest_response = array();
        $unsaved_manifest_response = array();
        $unsaved_response = array();

        $manifestType = 'O';
        $manifestStatus = 'M';
        $dbServer = 'N';
        $weighingType = 'M';
        $readByLocal = 'N';
        $diFlag = 'N';

        // echo 'user id is '.$input['userId'];
        $loginUserId = isset($input['userId']) ? $input['userId'] : $this->error_response('Incomplete input: userId not received.');
        $employeeId = isset($input['employeeId']) ? $input['employeeId'] : $this->error_response('Incomplete input: employeeId not received.');
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
        $loginUserOfficeId = isset($input['loggedInOfficeId']) ? $input['loggedInOfficeId'] : $this->error_response('Incomplete input: loggedInOfficeId not received.');
        $loggedInOfficeCode = isset($input['loggedInOfficeCode']) ? $input['loggedInOfficeCode'] : $this->error_response('Incomplete input: loggedInOfficeCode not received.');
        $nodeId = isset($input['nodeId']) ? $input['nodeId'] : $this->error_response('Incomplete input: nodeId not received');
        $manifestNumbers = isset($input['manifestNumbers']) ? $input['manifestNumbers'] : $this->error_response('Incomplete input: manifestNumbers not received');
        for ($i = 0; $i < count($manifestNumbers); $i++) {
            $manifestDate = isset($manifestNumbers[$i]['manifestDate']) ? $manifestNumbers[$i]['manifestDate'] : $this->error_response('Incomplete input: manifestDate not received');
            $manifestTime = isset($manifestNumbers[$i]['manifestTime']) ? $manifestNumbers[$i]['manifestTime'] : $this->error_response('Incomplete input: manifestTime not received');

            $manifestDate = $server_date;
            $manifestTime = $server_time;

            $manifestNumber = isset($manifestNumbers[$i]['manifestNumber']) ? $manifestNumbers[$i]['manifestNumber'] : $this->error_response('Incomplete input: manifestNumber not received');
            $totWeightKgs = isset($manifestNumbers[$i]['totWeightKgs']) ? $manifestNumbers[$i]['totWeightKgs'] : $this->error_response('Incomplete input: totWeightKgs not received');
            //you are sending id, i am receiving code. It should actually be code.
            $destBranchCode = isset($manifestNumbers[$i]['destBranchId']) ? $manifestNumbers[$i]['destBranchId'] : $this->error_response('Incomplete input: destBranchId not received');
            $destBranchId = $this->get_branch_id_dtdc_d_office($destBranchCode);
            if (!$destBranchId) {
                $destBranchId = null;
            }

            $modeId = isset($manifestNumbers[$i]['modeId']) ? $manifestNumbers[$i]['modeId'] : $this->error_response('Incomplete input: modeId not received');

            $numberOfPackets = isset($manifestNumbers[$i]['numberOfPackets']) ? $manifestNumbers[$i]['numberOfPackets'] : $this->error_response('Incomplete input: numberOfPackets not received');
            $totalWeight = isset($manifestNumbers[$i]['totalWeight']) ? $manifestNumbers[$i]['totalWeight'] : $this->error_response('Incomplete input: totalWeight not received');
            $warDate = isset($manifestNumbers[$i]['warDate']) ? $manifestNumbers[$i]['warDate'] : $this->error_response('Incomplete input: warDate not received');
            $consgNumbers = isset($manifestNumbers[$i]['consgNumbers']) ? $manifestNumbers[$i]['consgNumbers'] : $this->error_response('Incomplete input: consgNumbers not received');
            $backgroundSync = isset($manifestNumbers[$i]['backgroundSync']) ? $manifestNumbers[$i]['backgroundSync'] : $this->error_response('Incomplete input: backgroundSync value should be true or false in string, not boolean ');
            $search = isset($manifestNumbers[$i]['search']) ? $manifestNumbers[$i]['search'] : $this->error_response('Incomplete input: search not received');
            $remarks = "";

            $check_query = "select * from dtdc_f_manifest where manifest_number = ? and manifest_type='O'";

            $result_check = $this->db->query($check_query,[$manifestNumber]);

            if ($backgroundSync == "false") {

                $num_rows = $result_check->num_rows();
            } else {
                $num_rows = $result_check->num_rows();
                if ($num_rows > 0) {
                    $remarks = "duplicate";
                } else {
                    $remarks = "";
                }
                //Rest $num_rows to 0 for both duplicates to insert.
                $num_rows = 0;
            }

            if ($search == "true") {
                $num_rows = 0;
            }


            if ($num_rows == 0) {
                for ($j = 0; $j < count($consgNumbers); $j++) {
                    $consgNumber = isset($consgNumbers[$j]['consgNumber']) ? $consgNumbers[$j]['consgNumber'] : $this->error_response('Incomplete input: consgNumber not received');
                    $indvWeightKgs = isset($consgNumbers[$j]['indvWeightKgs']) ? $consgNumbers[$j]['indvWeightKgs'] : $this->error_response('Incomplete input: indvWeightKgs not received');
                    $documentId = isset($consgNumbers[$j]['documentId']) ? $consgNumbers[$j]['documentId'] : $this->error_response('Incomplete input: documentId not received');
                    $productId = isset($consgNumbers[$j]['productId']) ? $consgNumbers[$j]['productId'] : $this->error_response('Incomplete input: productId not received');
                    $manifestTypeId = isset($consgNumbers[$j]['manifestTypeId']) ? $consgNumbers[$j]['manifestTypeId'] : $this->error_response('Incomplete input: manifestTypeId not received');
                    $totalConsignmentNumber = isset($consgNumbers[$j]['totalConsignmentNumber']) ? $consgNumbers[$j]['totalConsignmentNumber'] : $this->error_response('Incomplete input: totalConsignmentNumber not received');

                    if ($indvWeightKgs === '0') {
                        $getWeightData = $this->getWeightForPacket($consgNumber, $loginUserOfficeId);
//                        $documentId = $getWeightData['document_id'];
                        $indvWeightKgs = $getWeightData['indv_weight_kgs'];
                    }

                    //Logic
                    $origin_branch_id = $this->get_origin_branch_id_from_dtdc_f_manifest($manifestNumber);
                    if (!$origin_branch_id) {
                        $origin_branch_id = $loginUserOfficeId;
                    }

                    if ($productId == '0' || $productId == 0) {
                        $productId = null;
                    }

                    if ($manifestTypeId == 0) {
                        $manifestTypeId = null;
                    }

                    $rep_off_id = $this->get_rep_off_id_from_dtdc_d_office($loggedInOfficeCode);

                    switch ($documentId) {
                        case '1':
                            //packet
                            # if 1 do nothing.
                            $manifestTypeDefn = $this->get_manifest_code($manifestTypeId);
                            break;
                        case '2':
                            //bag
                            // $documentId = $this->get_rm_entity_type_from_dtdc_d_routing_master($productId);
                            if (!$documentId) {
                                $documentId = null;
                            }
                            $manifestTypeDefn = $this->get_manifest_code($manifestTypeId);
                            break;
                        case '0':
                            //manual entry
                            $documentId = $this->get_document_id_from_dtdc_f_manifest($manifestNumber);
                            if (!$documentId) {
                                $documentId = null;
                                $manifestTypeDefn = 'PMF';
                            } else {
                                $manifestTypeDefn = $this->get_manifest_code($manifestTypeId);
                            }

                            break;

                        default:
                            # code...
                            $manifestTypeDefn = $this->get_manifest_code($manifestTypeId);
                            break;
                    }
                    $manifestTypeDefn = $this->get_manifest_code($manifestTypeId);
                    if ($totalConsignmentNumber == 'null') {
                        $totalConsignmentNumber = $this->get_total_consignment_number_from_dtdc_f_manifest($manifestNumber);
                    }

                    $check_query_1 = "select * from dtdc_f_manifest where manifest_number = ? and consg_number = ? and manifest_type='O'";

                    $result_check_1 = $this->db->query($check_query_1,[$manifestNumber,$consgNumber]);
                    $search_num_rows = $result_check_1->num_rows();
                    if ($search == 'true') {
                        $search_num_rows = 0;
                    }
                    if ($search_num_rows == 0) {

                        $insert_data = array(
                            'MANIFEST_DATE' => $manifestDate,
                            'MANIFEST_TIME' => $manifestTime,
                            'MANIFEST_NUMBER' => $manifestNumber,
                            'CONSG_NUMBER' => $consgNumber,
                            'TOT_WEIGHT_KGS' => $totWeightKgs,
                            'INDV_WEIGHT_KGS' => $indvWeightKgs,
                            'ORIG_BRNCH_ID' => $origin_branch_id,
                            'REP_OFF_ID' => $rep_off_id,
                            'DEST_BRNCH_ID' => $destBranchId,
                            'MODE_ID' => $modeId,
                            'DOCUMENT_ID' => $documentId,
                            'PRODUCT_ID' => $productId,
                            'EMPLOYEE_ID' => $employeeId,
                            'MNFST_TYPE_ID' => $manifestTypeId,
                            'TOT_CONSG_NUM' => $totalConsignmentNumber,
                            'NO_OF_PACKETS' => $numberOfPackets,
                            'NO_OF_PIECES' => 1,
                            'TOT_WGHT_PACKETS' => $totalWeight,
                            'MNFST_STATUS' => $manifestStatus,
                            'DB_SERVER' => $dbServer,
                            'MANIFEST_TYPE' => $manifestType,
                            'MANIFEST_TYPE_DEFN' => $manifestTypeDefn,
                            'WEIGHING_TYPE' => $weighingType,
                            'TRANS_CREATE_DATE' => $server_date_time,
                            'TRANS_LAST_MODIFIED_DATE' => $server_date_time,
                            "USER_ID" => $loginUserId,
                            "READ_BY_LOCAL" => $readByLocal,
                            "NODE_ID" => $nodeId,
                            "di_flag" => $diFlag,
                            "RECORD_ENTRY_DATETIME" => $server_date_time,
                            "ARRIVAL_DATE_TIME" => $server_date_time,
                            "REMARKS" => $remarks,
                            "WAR_DATE" => $warDate
                        );

//                        $query = "INSERT INTO dtdc_f_manifest" .
//                            "(MANIFEST_DATE," .
//                            "MANIFEST_TIME," .
//                            "MANIFEST_NUMBER," .
//                            "CONSG_NUMBER," .
//                            "TOT_WEIGHT_KGS," .
//                            "INDV_WEIGHT_KGS," .
//                            "ORIG_BRNCH_ID," .
//                            "REP_OFF_ID," .
//                            "DEST_BRNCH_ID," .
//                            "MODE_ID," .
//                            "DOCUMENT_ID," .
//                            "PRODUCT_ID," .
//                            "EMPLOYEE_ID," .
//                            "MNFST_TYPE_ID," .
//                            "TOT_CONSG_NUM," .
//                            "NO_OF_PACKETS," .
//                            "TOT_WGHT_PACKETS," .
//                            "MNFST_STATUS," .
//                            "DB_SERVER," .
//                            "MANIFEST_TYPE," .
//                            "MANIFEST_TYPE_DEFN," .
//                            "WEIGHING_TYPE," .
//                            "TRANS_CREATE_DATE," .
//                            "TRANS_LAST_MODIFIED_DATE," .
//                            "USER_ID," .
//                            "READ_BY_LOCAL," .
//                            "NODE_ID," .
//                            "di_flag," .
//                            "RECORD_ENTRY_DATETIME," .
//                            "ARRIVAL_DATE_TIME," .
//                            "REMARKS," .
//                            "WAR_DATE) VALUES ('"
//                            . $manifestDate . "','"
//                            . $manifestTime . "','"
//                            . $manifestNumber . "','"
//                            . $consgNumber . "','"
//                            . $totWeightKgs . "','"
//                            . $indvWeightKgs . "','"
//                            . $origin_branch_id . "',"
//                            . $rep_off_id . ","
//                            . $destBranchId . ",'"
//                            . $modeId . "',"
//                            . $documentId . ","
//                            . $productId . ",'"
//                            . $employeeId . "',"
//                            . $manifestTypeId . ",'"
//                            . $totalConsignmentNumber . "','"
//                            . $numberOfPackets . "','"
//                            . $totalWeight . "','"
//                            . $manifestStatus . "','"
//                            . $dbServer . "','"
//                            . $manifestType . "','"
//                            . $manifestTypeDefn . "','"
//                            . $weighingType . "','"
//                            . $server_date_time . "','"
//                            . $server_date_time . "','"
//                            . $loginUserId . "','"
//                            . $readByLocal . "','"
//                            . $nodeId . "','"
//                            . $diFlag . "','"
//                            . $server_date_time . "','"
//                            . $server_date_time . "','"
//                            . $remarks . "','"
//                            . $warDate . "')";

                        // echo $query;
                        if (!$this->support_model->count_consgn_numbers_in_dtdc_f_manifest($manifestNumber, $consgNumber, $manifestType)) {
                            $result = $this->db->insert('dtdc_f_manifest',$insert_data);
                            if ($result) {
                                array_push($save_response, $consgNumber);
                            } else {
                                array_push($unsaved_response, $consgNumber);
                            }
                        } else {

                            $update_data = array(
                                'TOT_WEIGHT_KGS' => $totWeightKgs,
                                'TOT_CONSG_NUM' => $totalConsignmentNumber,
                                'NO_OF_PACKETS' => $numberOfPackets,
                                'TOT_WGHT_PACKETS' => $totalWeight
                            );

                            $this->db->where('manifest_number',$manifestNumber);
                            $this->db->where('consg_number',$consgNumber);
                            $this->db->where('MANIFEST_TYPE',$manifestType);

                            $this->db->update('dtdc_f_manifest',$update_data);

//                            $update_query = "update dtdc_f_manifest set TOT_WEIGHT_KGS = '$totWeightKgs',
//TOT_CONSG_NUM = '$totalConsignmentNumber', NO_OF_PACKETS = '$numberOfPackets', TOT_WGHT_PACKETS = '$totalWeight' where manifest_number = '$manifestNumber' and consg_number = '$consgNumber' and MANIFEST_TYPE = '$manifestType'";
//                            $this->db->query($update_query);
                            array_push($unsaved_response, $consgNumber);
                        }

                    }
                }
                array_push($save_manifest_response, $manifestNumber);
            } else {
                array_push($unsaved_manifest_response, $manifestNumber);
            }


        }
        $response = array(
            'status' => 1,
            'saved_manifest_numbers' => $save_manifest_response,
            'duplicate_manifest_numbers' => $unsaved_manifest_response,
            'info' => array(
                'saved_consg_nums' => $save_response,
                'dup_consg_nums' => $unsaved_response
            )
        );

        return $response;
    }

    public function getWeightForPacket($manifest_number, $branch_id)
    {
        $sql = "(select document_id, indv_weight_kgs from dtdc_f_manifest where CONSG_NUMBER = ? and DEST_BRNCH_ID = ? and MANIFEST_TYPE = 'I')
                union
                (select document_id, tot_weight_kgs from dtdc_f_manifest where manifest_number = ? and ORIG_BRNCH_ID = ? and MANIFEST_TYPE = 'O')";

        $query = $this->db->query($sql, [$manifest_number, $branch_id, $manifest_number, $branch_id]);
        if ($query->num_rows() > 0) {
            return $query->result_array()[0];
        } else {
            return [
                'document_id' => null,
                'indv_weight_kgs' => null,
            ];
        }
    }

    //Need changes here
    public function saveoutgoingbagmanifestfornondox($input)
    {
        $server_date = $this->server_date;
        $server_time = $this->server_time;
        $server_date_time = $this->server_date_time;
        $save_response = array();
        $save_manifest_response = array();
        $unsaved_manifest_response = array();
        $unsaved_response = array();

        $manifestType = 'O';
        $manifestStatus = 'M';
        $dbServer = 'N';
        $weighingType = 'M';
        $readByLocal = 'N';
        $diFlag = 'N';

        $loginUserId = isset($input['userId']) ? $input['userId'] : $this->error_response('Incomplete input: userId not received.');
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
        $loginUserOfficeId = isset($input['loggedInOfficeId']) ? $input['loggedInOfficeId'] : $this->error_response('Incomplete input: loggedInOfficeId not received.');
        $employeeId = isset($input['employeeId']) ? $input['employeeId'] : $this->error_response('Incomplete input: employeeId not received.');
        $loggedInOfficeCode = isset($input['loggedInOfficeCode']) ? $input['loggedInOfficeCode'] : $this->error_response('Incomplete input: loggedInOfficeCode not received.');
        $nodeId = isset($input['nodeId']) ? $input['nodeId'] : $this->error_response('Incomplete input: nodeId not received');
        $manifestNumbers = isset($input['manifestNumbers']) ? $input['manifestNumbers'] : $this->error_response('Incomplete input: manifestNumbers not received');

        for ($i = 0; $i < count($manifestNumbers); $i++) {
            $manifestDate = isset($manifestNumbers[$i]['manifestDate']) ? $manifestNumbers[$i]['manifestDate'] : $this->error_response('Incomplete input: manifestDate not received');
            $manifestTime = isset($manifestNumbers[$i]['manifestTime']) ? $manifestNumbers[$i]['manifestTime'] : $this->error_response('Incomplete input: manifestTime not received');
            $manifestNumber = isset($manifestNumbers[$i]['manifestNumber']) ? $manifestNumbers[$i]['manifestNumber'] : $this->error_response('Incomplete input: manifestNumber not received');
            $totWeightKgs = isset($manifestNumbers[$i]['totWeightKgs']) ? $manifestNumbers[$i]['totWeightKgs'] : $this->error_response('Incomplete input: totWeightKgs not received');
            //
            $manifestDate = $server_date;
            $manifestTime = $server_time;
            //This is destBranchCode
            $destBranchCode = isset($manifestNumbers[$i]['destBranchId']) ? $manifestNumbers[$i]['destBranchId'] : $this->error_response('Incomplete input: destBranchId not received');
            $destBranchId = $this->get_branch_id_dtdc_d_office($destBranchCode);
            if (!$destBranchId) {
                $destBranchId = null;
            }

            $modeId = isset($manifestNumbers[$i]['modeId']) ? $manifestNumbers[$i]['modeId'] : $this->error_response('Incomplete input: modeId not received');

            $numberOfPackets = isset($manifestNumbers[$i]['numberOfPackets']) ? $manifestNumbers[$i]['numberOfPackets'] : $this->error_response('Incomplete input: numberOfPackets not received');
            $numberOfPieces = 1;
            $totalWeight = isset($manifestNumbers[$i]['totalWeight']) ? $manifestNumbers[$i]['totalWeight'] : $this->error_response('Incomplete input: totalWeight not received');
            $warDate = isset($manifestNumbers[$i]['warDate']) ? $manifestNumbers[$i]['warDate'] : $this->error_response('Incomplete input: warDate not received');
            $consgNumbers = isset($manifestNumbers[$i]['consgNumbers']) ? $manifestNumbers[$i]['consgNumbers'] : $this->error_response('Incomplete input: consgNumbers not received');
            $backgroundSync = isset($manifestNumbers[$i]['backgroundSync']) ? $manifestNumbers[$i]['backgroundSync'] : $this->error_response('Incomplete input: backgroundSync value should be be true or false in string, not boolean ');
            $search = isset($manifestNumbers[$i]['search']) ? $manifestNumbers[$i]['search'] : $this->error_response('Incomplete input: search not received');

            $remarks = "";

            $check_query = "select * from dtdc_f_manifest where manifest_number = ? and manifest_type='O'";

            $result_check = $this->db->query($check_query,[$manifestNumber]);


            if ($backgroundSync == "false") {

                $num_rows = $result_check->num_rows();
            } else {
                $num_rows = $result_check->num_rows();
                if ($num_rows > 0) {
                    $remarks = "duplicate";
                } else {
                    $remarks = "";
                }
                //Rest $num_rows to 0 for both duplicates to insert.
                $num_rows = 0;
            }

            //If search is true, execute the loop anyway.
            if ($search == 'true') {
                $num_rows = 0;
            }

            if ($num_rows == 0) {
                $tot_consg_num = count($consgNumbers);
                for ($j = 0; $j < count($consgNumbers); $j++) {
                    $consgNumber = isset($consgNumbers[$j]['consgNumber']) ? $consgNumbers[$j]['consgNumber'] : $this->error_response('Incomplete input: consgNumber not received');
                    $action = isset($consgNumbers[$j]['action']) ? $consgNumbers[$j]['action'] : null;
                    $indvWeightKgs = isset($consgNumbers[$j]['indvWeightKgs']) ? $consgNumbers[$j]['indvWeightKgs'] : $this->error_response('Incomplete input: indvWeightKgs not received');
                    $documentId = isset($consgNumbers[$j]['documentId']) ? $consgNumbers[$j]['documentId'] : $this->error_response('Incomplete input: documentId not received');
                    $productId = isset($consgNumbers[$j]['productId']) ? $consgNumbers[$j]['productId'] : $this->error_response('Incomplete input: productId not received');
                    $manifestTypeId = isset($consgNumbers[$j]['manifestTypeId']) ? $consgNumbers[$j]['manifestTypeId'] : $this->error_response('Incomplete input: manifestTypeId not received');
                    $destPincode = isset($consgNumbers[$j]['destPincode']) ? $consgNumbers[$j]['destPincode'] : $this->error_response('Incomplete input: destPincode not received');
                    $totalConsignmentNumber = isset($consgNumbers[$j]['totalConsignmentNumber']) ? $consgNumbers[$j]['totalConsignmentNumber'] : $this->error_response('Incomplete input: totalConsignmentNumber not received');
                    $desc_goods = isset($consgNumbers[$j]['goodsDescription']) ? $consgNumbers[$j]['goodsDescription'] : $this->error_response('Incomplete input: goodsDescription not received');
                    $remarks_new = isset($consgNumbers[$j]['remarks']) ? $consgNumbers[$j]['remarks'] : $this->error_response('Incomplete input: remarks not received');
                    $ctrlNumber = isset($consgNumbers[$j]['ctrlNumber']) ? $consgNumbers[$j]['ctrlNumber'] : null;
                    $wvcFlag = isset($consgNumbers[$j]['wvcFlag']) ? $consgNumbers[$j]['wvcFlag'] : null;
                    //Logic
                    $remarks = $remarks . $remarks_new;
                    $origin_branch_id = $this->get_origin_branch_id_from_dtdc_f_manifest($manifestNumber);
                    if (!$origin_branch_id) {
                        $origin_branch_id = $loginUserOfficeId;
                    }

                    if ($productId == '0' || $productId == 0) {
                        $productId = null;
                    }

                    if ($manifestTypeId == 0) {
                        $manifestTypeId = null;
                    }

                    $rep_off_id = $this->get_rep_off_id_from_dtdc_d_office($loggedInOfficeCode);

                    switch ($documentId) {
                        case '1':
                            //packet
                            # if 1 do nothing.
                            $manifestTypeDefn = $this->get_manifest_code($manifestTypeId);
                            break;
                        case '2':
                            //bag
                            // $documentId = $this->get_document_id_from_dtdc_f_booking($consgNumber);
                            if (!$documentId) {
                                $documentId = null;
                            }
                            $manifestTypeDefn = $this->get_manifest_code($manifestTypeId);
                            break;
                        case '0':
                            //manual entry
                            $documentId = $this->get_document_id_from_dtdc_f_manifest($manifestNumber);
                            if (!$documentId) {
                                $documentId = null;
                                $manifestTypeDefn = 'PMF';
                            } else {
                                $manifestTypeDefn = $this->get_manifest_code($manifestTypeId);
                            }
                            break;

                        default:
                            # code...
                            $manifestTypeDefn = $this->get_manifest_code($manifestTypeId);
                            break;
                    }
                    $manifestTypeDefn = $this->get_manifest_code($manifestTypeId);

                    if ($totalConsignmentNumber == 'null') {
                        $totalConsignmentNumber = $this->get_total_consignment_number_from_dtdc_f_manifest($manifestNumber);
                    }


                    if ($destPincode != '0') {
                        $dest_city_id = $this->get_dest_city_id_from_pincode($destPincode);
                        $pincode_id = $this->get_pincode_id_dtdc_d_pincode($destPincode);
                    } else {
                        $dest_city_id = null;
                        $pincode_id = null;
                    }

                    $check_query_1 = "select * from dtdc_f_manifest where manifest_number = ? and consg_number = ? and manifest_type='O'";

                    $result_check_1 = $this->db->query($check_query_1,[$manifestNumber,$consgNumber]);
                    $search_num_rows = $result_check_1->num_rows();
                    if ($search == 'true') {
                        $search_num_rows = 0;
                    }
                    //On 7th December 2016, Harish asked me to add NO_OF_PIECES and TOT_CONSG_NUM
                    $no_of_pieces = 1;
                    $numberOfbagMade = $this->get_number_of_bag_made($consgNumber, $loginUserOfficeId);
                    // echo $result_check->num_rows();
                    if ($search_num_rows == 0) {
                        // echo "in here saved";
                        // On 13 July 2016, Swamy asked to change again.
                        //On 14th June 2016, Swamy asked to change again to $destBranchId
                        //On 22 December 2016, Harish asekd me to remove $numberOfPieces which is coming from APP. I don't know why?

                        $insert_data = array(
                            'MANIFEST_DATE' => $manifestDate,
                            'MANIFEST_TIME' => $manifestTime,
                            'MANIFEST_NUMBER' => $manifestNumber,
                            'CONSG_NUMBER' => $consgNumber,
                            'DESC_GOODS' => $desc_goods,
                            'TOT_WEIGHT_KGS' => $totWeightKgs,
                            'INDV_WEIGHT_KGS' => $indvWeightKgs,
                            'ORIG_BRNCH_ID' => $origin_branch_id,
                            'REP_OFF_ID' => $rep_off_id,
                            'NO_OF_PIECES' => $no_of_pieces,
                            'DEST_BRNCH_ID' => $destBranchId,
                            'DEST_CITY_ID' => $dest_city_id,
                            'MODE_ID' => $modeId,
                            'DEST_PINCODE' => $pincode_id,
                            'DOCUMENT_ID' => $documentId,
                            'PRODUCT_ID' => $productId,
                            'EMPLOYEE_ID' => $employeeId,
                            'MNFST_TYPE_ID' => $manifestTypeId,
                            'TOT_CONSG_NUM' => $totalConsignmentNumber,
                            'NO_OF_PACKETS' => $numberOfPackets,
                            'TOT_WGHT_PACKETS' => $totalWeight,
                            'MNFST_STATUS' => $manifestStatus,
                            'DB_SERVER' => $dbServer,
                            'MANIFEST_TYPE' => $manifestType,
                            'MANIFEST_TYPE_DEFN' => $manifestTypeDefn,
                            'WEIGHING_TYPE' => $weighingType,
                            'TRANS_CREATE_DATE' => $server_date_time,
                            'TRANS_LAST_MODIFIED_DATE' => $server_date_time,
                            'USER_ID' => $loginUserId,
                            'READ_BY_LOCAL' => $readByLocal,
                            'NODE_ID' => $nodeId,
                            'di_flag' => $diFlag,
                            'RECORD_ENTRY_DATETIME' => $server_date_time,
                            'ARRIVAL_DATE_TIME' => $server_date_time,
                            'REMARKS' => $remarks,
                            'WAR_DATE' => $warDate,
                            'CTRL_NUMBER' => $ctrlNumber,
                            'WVC_FLAG' => $wvcFlag,
                            'ACTION' => $action,
                            'NO_OF_BAG_MADE' => $numberOfbagMade
                        );


                        // echo $query;
                        if (!$this->support_model->count_consgn_numbers_in_dtdc_f_manifest($manifestNumber, $consgNumber, $manifestType)) {
                            // echo "in here";
                            $result = $this->db->insert('dtdc_f_manifest', $insert_data);
                            if ($result) {
                                array_push($save_response, $consgNumber);
                            } else {
                                array_push($unsaved_response, $consgNumber);
                            }
                        } else {

                            $update_query = array(
                                'TOT_WEIGHT_KGS' => $totWeightKgs,
                                'TOT_CONSG_NUM' => $totalConsignmentNumber,
                                'NO_OF_PACKETS' => $numberOfPackets,
                                'TOT_WGHT_PACKETS' => $totalWeight
                            );
                            $this->db->where('manifest_number',$manifestNumber);
                            $this->db->where('consg_number',$consgNumber);
                            $this->db->where('MANIFEST_TYPE',$manifestType);

                            $this->db->update('dtdc_f_manifest',$update_query);
//
//                            $update_query = "update dtdc_f_manifest set TOT_WEIGHT_KGS = '$totWeightKgs',
//TOT_CONSG_NUM = '$totalConsignmentNumber', NO_OF_PACKETS = '$numberOfPackets', TOT_WGHT_PACKETS = '$totalWeight'
//where manifest_number = '$manifestNumber' and consg_number = '$consgNumber' and MANIFEST_TYPE = '$manifestType'";
//                            $this->db->query($update_query);
                            array_push($unsaved_response, $consgNumber);
                        }
                    }
                   

                }
                array_push($save_manifest_response, $manifestNumber);
            } else {
                array_push($unsaved_manifest_response, $manifestNumber);
            }
            // $getCount[] = $this->getCountForConsignmentNumber($manifestNumber, $loginUserOfficeId); 

        }
        // $numberOfConsignments = implode(',',$getCount);
        $numberOfConsignments = $this->getCountForConsignmentNumber($manifestNumber, $loginUserOfficeId); 
        $response = array(
            'status' => 1,
            'saved_manifest_numbers' => $save_manifest_response,
            'duplicate_manifest_numbers' => $unsaved_manifest_response,
            'info' => array(
                'saved_consg_nums' => $save_response,
                'dup_consg_nums' => $unsaved_response
            ),
            'countOfConsignments' => $numberOfConsignments
        );

        return $response;

    }
    public function getCountForConsignmentNumber($manifestNumber, $loginUserOfficeId){
        $query = "SELECT COUNT(CONSG_NUMBER) as no_of_consg FROM dtdc_f_manifest WHERE MANIFEST_NUMBER='$manifestNumber' AND MANIFEST_TYPE='O' AND ORIG_BRNCH_ID='$loginUserOfficeId' AND MANIFEST_DATE=CURDATE()";
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();
            $no_of_consg = $result_array[0]['no_of_consg'];
             return $no_of_consg;
        } else {
            return 0;
        }

    }

    public function get_number_of_bag_made($consgNumber, $branchOfficeId)
    {
        $query = "select NO_OF_PIECES from dtdc_f_booking where CONSG_NUMBER = (select PARENT_CONSG_NO from dtdc_f_booking where  CONSG_NUMBER = ?  and BRNCH_OFF_ID = ?)";
        $result = $this->db->query($query,[$consgNumber, $branchOfficeId]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();
            $numberOfPieces = $result_array[0]['NO_OF_PIECES'];
            if($numberOfPieces > 1) {
                return $numberOfPieces;
            } else {
                return 0;
            }
        } else {
            return 0;
        }
    }

    public function get_manifest_code($manifestTypeId)
    {
        $query = "select mnfst_code from dtdc_d_mnfst_type where mnfst_type_id = ?";
        $result = $this->db->query($query,[$manifestTypeId]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();

            return $result_array[0]['mnfst_code'];
        } else {
            return null;
        }
    }

    public function checkDispatchNumber($dispatch_number){
        $sql = "select * from dtdc_f_dispatch where dispatch_number = ? ";
        $query = $this->db->query($sql,[$dispatch_number]);
        if ($query->num_rows() > 0) {
                return true;
        } 
        return false;
    }
    public function savemastercondispatch($input)
    {
        $server_date = $this->server_date;
        $server_time = $this->server_time;
        $server_date_time = $this->server_date_time;

        $mastercon_header_response = array();

        //Create empty mastercon_header_data and mastercon_detail_data array
        $mastercon_header_data = array();
        $mastercon_detail_data = array();

        $inserted_header_data = array();
        $inserted_cd_numbers = array();
        $inserted_dispatch_numbers = array();
        $inserted_detail_data = array();
        $insert_input_dispatchNumber = array();

        //Hardcoded values
        $mastercon_header_data['db_server'] = $db_server = 'N';
        $mastercon_header_data['server_date'] = $server_date;
        $mastercon_header_data['server_time'] = $server_time;
        $mastercon_header_data['server_date_time'] = $server_date_time;
        $mastercon_header_data['node_id'] = 'MOP';
        $mastercon_header_data['read_by_local'] = 'N';
        $mastercon_header_data['di_flag'] = 'N';

        //Load main JSON data to mastercon_header_data, do basic validations

        $mastercon_header_data['loggedInUserId'] = $loggedInUserId = isset($input['loggedInUserId']) ? $input['loggedInUserId'] : $this->error_response('loggedInUserId is not set');
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
        $mastercon_header_data['nodeId'] = $nodeId = isset($input['nodeId']) ? $input['nodeId'] : $this->error_response('nodeId is not set');
        $mastercon_header_data['appTime'] = $appTime = isset($input['appTime']) ? $input['appTime'] : $this->error_response('appTime is not set');
        $mastercon_header_data['appDate'] = $appDate = isset($input['appDate']) ? $input['appDate'] : $this->error_response('appDate is not set');
        $mastercon_header_data['loggedInOfficeId'] = $loggedInOfficeId = isset($input['loggedInOfficeId']) ? $input['loggedInOfficeId'] : $this->error_response('loggedInOfficeId is not set');
        $mastercon_header_data['loggedInOfficeType'] = $loggedInOfficeType = isset($input['loggedInOfficeType']) ? $input['loggedInOfficeType'] : $this->error_response('loggedInOfficeType is not set');
        $consolidatedEWBNum = isset($input['consolidatedEWBNum']) ? $input['consolidatedEWBNum'] : null;

        $mastercon_header_data['appTime'] = $server_time;
        $mastercon_header_data['appDate'] = $server_date;
        

        //
        if ($consolidatedEWBNum && $this->checkConsolidatedEWBNumExists($consolidatedEWBNum)) {
            $response = array('status' => 0, 'message' => 'The consolidated EWB number already exists');

            return $response;
        }

        $master = isset($input['master']) ? $input['master'] : $this->error_response('master is not set');

        
       
        for ($i = 0; $i < count($master); $i++) {
            # code...
            $vehicleId = isset($master[$i]['vehicleId']) ? $master[$i]['vehicleId'] : $this->error_response('vehicleId is not set');
            $breakVanNumber = isset($master[$i]['breakVanNumber']) ? $master[$i]['breakVanNumber'] : $this->error_response('breakVanNumber is not set');
            $openingKm = isset($master[$i]['openingKms']) ? $master[$i]['openingKms'] : $this->error_response('openingKms is not set');
            $vehicleNumber = isset($master[$i]['vehicleNumber']) ? $master[$i]['vehicleNumber'] : $this->error_response('vehicleNumber is not set');
            $departureTime = isset($master[$i]['departureTime']) ? $master[$i]['departureTime'] : $this->error_response('departureTime is not set');
            $arrivalTime = isset($master[$i]['arrivalTime']) ? $master[$i]['arrivalTime'] : $this->error_response('arrivalTime is not set');
            $tempVehicleNumbers = isset($master[$i]['tempVehicleNumbers']) ? $master[$i]['tempVehicleNumbers'] : $this->error_response('tempVehicleNumbers is not set');
            $cdTime = isset($master[$i]['cdTime']) ? $master[$i]['cdTime'] : $this->error_response('cdTime is not set');
            $cdNumber = isset($master[$i]['cdNumber']) ? $master[$i]['cdNumber'] : $this->error_response('cdNumber is not set');
            $destOfficeType = isset($master[$i]['destOfficeType']) ? $master[$i]['destOfficeType'] : $this->error_response('destOfficeType is not set');
            $serviceType = isset($master[$i]['serviceType']) ? $master[$i]['serviceType'] : $this->error_response('serviceType is not set');
            $chargedWeight = isset($master[$i]['chargedWeight']) ? $master[$i]['chargedWeight'] : $this->error_response('chargedWeight is not set');
            $dispatchNumber = isset($master[$i]['dispatchNumber']) ? $master[$i]['dispatchNumber'] : $this->error_response('dispatchNumber is not set');

           

            $loaderId = isset($master[$i]['loaderId']) ? $master[$i]['loaderId'] : $this->error_response('loaderId is not set');
            $totalWeight = isset($master[$i]['totalWeight']) ? $master[$i]['totalWeight'] : $this->error_response('totalWeight is not set');

            $otcId = isset($master[$i]['otcId']) ? $master[$i]['otcId'] : $this->error_response('otcId is not set');
            $vendorId = isset($master[$i]['DirectConnectionId']) ? $master[$i]['DirectConnectionId'] : $this->error_response('DirectConnectionId is not set');
            $destOfficeId = isset($master[$i]['destOfficeId']) ? $master[$i]['destOfficeId'] : $this->error_response('destOfficeId is not set');
            $modeId = isset($master[$i]['modeId']) ? $master[$i]['modeId'] : $this->error_response('modeId is not set');
            $noBags = isset($master[$i]['noBags']) ? $master[$i]['noBags'] : $this->error_response('noBags is not set');
            $cdDate = isset($master[$i]['cdDate']) ? $master[$i]['cdDate'] : $this->error_response('cdDate is not set');


            switch ($modeId) {
                case '1':
                    $vehicle_column = "AIRPORT_ID";

                    if ($vehicleId == 'null') {
                        $vehicle_column = "TEMP_VEHICAL_CODE";
                        $column_value = $tempVehicleNumbers;
                    } else {

                        $flight_number = $vehicleId;


                        //Find the airport_id of the flight_number from the db

                        $airport_id_sql = "SELECT airport_id FROM dtdc_d_airport WHERE AIRLINE_NUMBER = ?";

                        $airport_id_query = $this->db->query($airport_id_sql, [$flight_number]);

                        if ($airport_id_query->num_rows() > 0) {

                            $airport_id = $airport_id_query->result_array()[0]['airport_id'];

                        } else {

                            $airport_id = null;
                        }

                        //
                        $column_value = $airport_id;

                    }
                    break;
                case '10':
                    $vehicle_column = 'TRAIN_ID';
                    $column_value = $vehicleId;
                    if ($vehicleId == 'null') {
                        $vehicle_column = "TEMP_VEHICAL_CODE";
                        $column_value = $tempVehicleNumbers;
                    }
                    break;
                case '2':
                    if ($vehicleId == 'null') {
                        $vehicle_column = "TEMP_VEHICAL_CODE";
                        $column_value = $tempVehicleNumbers;
                    }
                    break;
                default:
                    $vehicle_column = "VEHICLE_ID";
                    $column_value = $vehicleId;
                    break;
            }


            //Load remaining JSON data to mastercon_header_data
            foreach ($master[$i] as $key => $value) {
                $mastercon_header_data[$key] = $value;
            }

            // if($cdDate != 'null'){
            //     $mastercon_header_data['cdDate'] = "'".$cdDate."'";
            //     echo $mastercon_header_data['cdDate'];
            // }

            //Remove detail key and its values from mastercon_header_data
            unset($mastercon_header_data['detail']);
            if($this->checkDispatchNumber($dispatchNumber)){
                $dispatch_number =   $this->generate_random_dispatch_number($mastercon_header_data['loggedInOfficeId']);
                $mastercon_header_data['dispatchNumber'] = $dispatch_number;
                $mastercon_header_data['insert_input_dispatchNumber'] = $dispatchNumber;
              }

            $mastercon_detail_data['header_dispatch_id'] = $this->save_mastercondispatch_header($mastercon_header_data, $vehicle_column, $column_value);
            array_push($inserted_cd_numbers, $mastercon_header_data['cdNumber']);
            array_push($inserted_dispatch_numbers, $mastercon_header_data['dispatchNumber']);
            array_push($insert_input_dispatchNumber, $mastercon_header_data['insert_input_dispatchNumber']);
            $detail = isset($master[$i]['detail']) ? $master[$i]['detail'] : $this->error_response('detail is not set');

            for ($j = 0; $j < count($detail); $j++) {
                $bagManifestNumber = isset($detail[$j]['bagManifestNumber']) ? $detail[$j]['bagManifestNumber'] : $this->error_response('bagManifestNumber is not set');
                $physicalWeight = isset($detail[$j]['physicalWeight']) ? $detail[$j]['physicalWeight'] : $this->error_response('physicalWeight is not set');
                $detailConsolidatedEWBNum = isset($detail[$j]['consolidatedEWBNum']) ? $detail[$j]['consolidatedEWBNum'] : null;
                $automatedFlag = isset($detail[$j]['automatedFlag']) ? $detail[$j]['automatedFlag'] : null;
                if(!empty($detailConsolidatedEWBNum)){
                    $this->doConsolidatedEwbNumberLogic($bagManifestNumber, $detailConsolidatedEWBNum);
                }
                if ($physicalWeight == '0.0') {
                    $get_physical_weight_query = "select DISTINCT(TOT_WEIGHT_KGS) from dtdc_f_manifest where
manifest_number= ? AND ORIG_BRNCH_ID= ? UNION
select phy_weight from dtdc_f_cd_recv_mnfst_dtls where
bag_manifest_NUMBER= ? AND dest_office_ID= ?";

                    // echo $get_physical_weight_query;
                    $get_physical_weight_query_result = $this->db->query($get_physical_weight_query,[$bagManifestNumber, $loggedInOfficeId, $bagManifestNumber, $loggedInOfficeId]);
                    if ($get_physical_weight_query_result->num_rows() > 0) {
                        $get_physical_weight_query_result_array = $get_physical_weight_query_result->result_array();
                        // print_r($get_physical_weight_query_result_array);
                        $physicalWeight = $get_physical_weight_query_result_array[0]['TOT_WEIGHT_KGS'];
                        // echo $physicalWeight;
                    }
                }
                foreach ($detail[$j] as $key => $value) {
                    $mastercon_detail_data[$key] = $value;
                }

                $mastercon_detail_data['consolidatedEWBNum'] = $detailConsolidatedEWBNum;
                $mastercon_detail_data['automatedFlag'] = $automatedFlag;

                $mastercon_detail_data = array_merge($mastercon_header_data, $mastercon_detail_data);
                $inserted_bag = $this->save_mastercondispatch_detail($mastercon_detail_data, $vehicle_column, $column_value);
                array_push($inserted_detail_data, $inserted_bag);
            }
        }

        $response = array(
            'status' => 1,
            'message' => 'Data inserted successfully',
            'inserted_cd_numbers' => $inserted_cd_numbers,
            'inserted_dispatch_numbers' => $inserted_dispatch_numbers,
            'inserted_detail_data' => $inserted_detail_data,
            'inserted_input_dispatchNumber' => $insert_input_dispatchNumber
        );

        return $response;
    }

    public function doConsolidatedEwbNumberLogic($manifest_number, $consolidated_ewb_number){
        $sql = "select MC_ID from dtdc_f_manifest_consolidate where CONSOLIDATE_EWB_NO is null and MANIFEST_NO = ?";
        $query = $this->db->query($sql,[$manifest_number]);
        $mc_ids = array();
        if($query->num_rows() > 0) {
            $mc_ids =  $query->result_array();
        }

        foreach($mc_ids as $mc_id){
            $sql2 = "update dtdc_f_manifest_consolidate set CONSOLIDATE_EWB_NO = ? where MC_ID = ?";
            $query = $this->db->query($sql2,[$consolidated_ewb_number,$mc_id['MC_ID']]);
        }
    }
    public function save_mastercondispatch_header($mastercon_header_data, $vehicle_column, $column_value)
    {

        $mastercon_header_data['cdDate'] = $this->server_date;
        $mastercon_header_data['cdTime'] = $this->server_time;

        $insert_data = array(
            'DISPATCH_NUMBER' => $mastercon_header_data['dispatchNumber'],
            'ORIGIN_OFFICE_TYPE' => $mastercon_header_data['loggedInOfficeType'],
            'ORIGIN_OFFICE_ID' => $mastercon_header_data['loggedInOfficeId'],
            'DEST_OFFICE_TYPE' => $mastercon_header_data['destOfficeType'],
            'DEST_OFFICE_ID' => $mastercon_header_data['destOfficeId'],
            'MODE_ID' => $mastercon_header_data['modeId'],
            'SERVICE_TYPE' => ($mastercon_header_data['serviceType'] == 'null') ? NULL : $mastercon_header_data['serviceType'],
            'VENDOR_ID' => ($mastercon_header_data['DirectConnectionId'] == 'null') ? NULL : $mastercon_header_data['DirectConnectionId'],
            'LOAD_SENDER_EMPLOYEE_ID' => $mastercon_header_data['employeeId'],
            'LOAD_SENT_DATE' => $mastercon_header_data['cdDate'],
            'LOAD_SENT_TIME' => $mastercon_header_data['cdTime'],
            'CD_DATE' => $mastercon_header_data['cdDate'],
            'CD_TIME' => $mastercon_header_data['cdTime'],
            'DB_SERVER' => $mastercon_header_data['db_server'],
            'TRANS_CREATE_DATE' => $mastercon_header_data['server_date'],
            'TRANS_LAST_MODIFIED_DATE' => $mastercon_header_data['server_date'],
            'USER_ID' => $mastercon_header_data['loggedInUserId'],
            'CD_LT_RR_NUMBER' => ($mastercon_header_data['cdNumber'] == 'null') ? NULL : $mastercon_header_data['cdNumber'],
            $vehicle_column => $column_value,
            'TOTAL_WEIGHT' => $mastercon_header_data['totalWeight'],
            'CHARGED_WEIGHT' => $mastercon_header_data['chargedWeight'],
            'LOADER_ID' => ($mastercon_header_data['loaderId'] == 'null') ? NULL : $mastercon_header_data['loaderId'],
            'NODE_ID' => $mastercon_header_data['node_id'],
            'READ_BY_LOCAL' => $mastercon_header_data['read_by_local'],
            'di_flag' => $mastercon_header_data['di_flag'],
            'OTC_ID' => ($mastercon_header_data['otcId'] == 'null') ? NULL : $mastercon_header_data['otcId'],
            'ACTUAL_DEPARTURE_DATE' => $mastercon_header_data['cdDate'],
            'ACTUAL_DEPARTURE_TIME' => $mastercon_header_data['departureTime'],
            'EXPECTED_ARRIVAL' => $mastercon_header_data['arrivalTime'],
            'OPENING_KM' => ($mastercon_header_data['openingKms'] == 'null') ? NULL : $mastercon_header_data['openingKms'],
            'Break_Van_Number' => ($mastercon_header_data['breakVanNumber'] == 'null') ? NULL : $mastercon_header_data['breakVanNumber'],
            'Vehicle_Number' => ($mastercon_header_data['vehicleNumber'] == 'null') ? NULL : $mastercon_header_data['vehicleNumber'],
            'NO_BAGS' => $mastercon_header_data['noBags']
        );


//        $query = "INSERT INTO dtdc_f_dispatch" .
//            "(DISPATCH_NUMBER," .
//            "ORIGIN_OFFICE_TYPE," .
//            "ORIGIN_OFFICE_ID," .
//            "DEST_OFFICE_TYPE," .
//            "DEST_OFFICE_ID," .
//            "MODE_ID," .
//            "SERVICE_TYPE," .
//            "VENDOR_ID," .
//            "LOAD_SENDER_EMPLOYEE_ID," .
//            "LOAD_SENT_DATE," .
//            "LOAD_SENT_TIME," .
//            "CD_DATE," .
//            "CD_TIME," .
//            "DB_SERVER," .
//            "TRANS_CREATE_DATE," .
//            "TRANS_LAST_MODIFIED_DATE," .
//            "USER_ID," .
//            "CD_LT_RR_NUMBER," .
//            $vehicle_column . "," .
//            "TOTAL_WEIGHT," .
//            "CHARGED_WEIGHT," .
//            "LOADER_ID," .
//            "NODE_ID," .
//            "READ_BY_LOCAL," .
//            "di_flag," .
//            "OTC_ID," .
//            "ACTUAL_DEPARTURE_DATE," .
//            "ACTUAL_DEPARTURE_TIME," .
//            "EXPECTED_ARRIVAL," .
//            "OPENING_KM," .
//            "Break_Van_Number," .
//            "Vehicle_Number," .
//            "NO_BAGS) VALUES ('"
//            . $mastercon_header_data['dispatchNumber'] . "','"
//            . $mastercon_header_data['loggedInOfficeType'] . "','"
//            . $mastercon_header_data['loggedInOfficeId'] . "','"
//            . $mastercon_header_data['destOfficeType'] . "','"
//            . $mastercon_header_data['destOfficeId'] . "','"
//            . $mastercon_header_data['modeId'] . "','"
//            . $mastercon_header_data['serviceType'] . "',NULLIF('" . $mastercon_header_data['DirectConnectionId'] . "','null'),"
//            // .$mastercon_header_data['DirectConnectionId'].","
//            . $mastercon_header_data['employeeId'] . ",'"
//            . $mastercon_header_data['cdDate'] . "','"
//            . $mastercon_header_data['cdTime'] . "','"
//            . $mastercon_header_data['cdDate'] . "','"
//            . $mastercon_header_data['cdTime'] . "','"
//            . $mastercon_header_data['db_server'] . "','"
//            . $mastercon_header_data['server_date'] . "','"
//            . $mastercon_header_data['server_date'] . "',"
//            . $mastercon_header_data['loggedInUserId'] . ",NULLIF('" . $mastercon_header_data['cdNumber'] . "','null'),'"
//            // .$mastercon_header_data['cdNumber']."','"
//            . $column_value . "','"
//            . $mastercon_header_data['totalWeight'] . "','"
//            . $mastercon_header_data['chargedWeight'] . "',NULLIF('" . $mastercon_header_data['loaderId'] . "','null'),'"
//            // .$mastercon_header_data['loaderId'].",'"
//            . $mastercon_header_data['node_id'] . "','"
//            . $mastercon_header_data['read_by_local'] . "','"
//            . $mastercon_header_data['di_flag'] . "',NULLIF('" . $mastercon_header_data['otcId'] . "','null'),'"
//            // .$mastercon_header_data['otcId'].","
//            . $mastercon_header_data['cdDate'] . "','"
//            . $mastercon_header_data['departureTime'] . "','"
//            . $mastercon_header_data['arrivalTime'] . "','"
//            . $mastercon_header_data['openingKms'] . "','"
//            . $mastercon_header_data['breakVanNumber'] . "','"
//            . $mastercon_header_data['vehicleNumber'] . "','"
//            . $mastercon_header_data['noBags'] . "')";
        // echo $query;
        $result = $this->db->insert('dtdc_f_dispatch',$insert_data);
        if ($result) {
            return $this->get_last_dispatch_header_id();
        }
    }

    public function checkConsolidatedEWBNumExists($consolidatedEWBNum)
    {
        $sql = "SELECT CONS_EWB_NUMBER FROM dtdc_f_disp_bag_mnfst_dtls WHERE CONS_EWB_NUMBER = ?";
        $query = $this->db->query($sql, [$consolidatedEWBNum]);
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function get_last_dispatch_header_id()
    {
        $query = "SELECT dispatch_id FROM dtdc_f_dispatch ORDER BY dispatch_id DESC LIMIT 1";
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();

            return $result_array[0]['dispatch_id'];
        }
    }

    public function save_mastercondispatch_detail($mastercon_detail_data, $vehicle_column, $column_value)
    {

    	$mastercon_detail_data['cdDate'] = $this->server_date;
    	$mastercon_detail_data['cdTime'] = $this->server_time;

    	$insert_data = array(
    		'DISPATCH_ID' => $mastercon_detail_data['header_dispatch_id'],
		    'BAG_MANIFEST_NUMBER' => $mastercon_detail_data['bagManifestNumber'],
		    'PHYSICAL_WEIGHT' => $mastercon_detail_data['physicalWeight'],
		    'REMARKS' => $mastercon_detail_data['remarks'],
		    'ORIGIN_OFFICE_TYPE' => $mastercon_detail_data['loggedInOfficeType'],
		    'ORIGIN_OFFICE_ID' => $mastercon_detail_data['loggedInOfficeId'],
		    'DEST_OFFICE_TYPE' => $mastercon_detail_data['destOfficeType'],
		    'DEST_OFFICE_ID' => $mastercon_detail_data['destOfficeId'],
		    'MODE_ID' => $mastercon_detail_data['modeId'],
		    'SERVICE_TYPE' => ($mastercon_detail_data['serviceType'] == 'null') ? NULL : $mastercon_detail_data['serviceType'],
		    'VENDOR_ID' => ($mastercon_detail_data['DirectConnectionId'] == 'null') ? NULL  : $mastercon_detail_data['DirectConnectionId'],
		    'CD_DATE' => $mastercon_detail_data['cdDate'],
		    'CD_TIME' => $mastercon_detail_data['cdTime'],
		    'DB_SERVER' => $mastercon_detail_data['db_server'],
		    'TRANS_CREATE_DATE' => $mastercon_detail_data['server_date'],
		    'TRANS_LAST_MODIFIED_DATE' => $mastercon_detail_data['server_date'],
		    'USER_ID' => $mastercon_detail_data['loggedInUserId'],
		    'CD_LT_RR_NUMBER' => ($mastercon_detail_data['cdNumber'] == 'null') ? NULL : $mastercon_detail_data['cdNumber'],
		    $vehicle_column => $column_value,
		    'LOADER_ID' => ($mastercon_detail_data['loaderId'] == 'null') ? NULL : $mastercon_detail_data['loaderId'],
		    'di_flag' => $mastercon_detail_data['di_flag'],
		    'CONS_EWB_NUMBER' => $mastercon_detail_data['consolidatedEWBNum'],
        'REASON' => $mastercon_detail_data['automatedFlag'],
		    'Vehicle_Number' => ($mastercon_detail_data['vehicleNumber'] == 'null') ? NULL : $mastercon_detail_data['vehicleNumber']
	    );

//        $query = "INSERT INTO dtdc_f_disp_bag_mnfst_dtls" .
//            "(DISPATCH_ID," .
//            "BAG_MANIFEST_NUMBER," .
//            "PHYSICAL_WEIGHT," .
//            "REMARKS,".
//            "ORIGIN_OFFICE_TYPE," .
//            "ORIGIN_OFFICE_ID," .
//            "DEST_OFFICE_TYPE," .
//            "DEST_OFFICE_ID," .
//            "MODE_ID," .
//            "SERVICE_TYPE," .
//            "VENDOR_ID," .
//            "CD_DATE," .
//            "CD_TIME," .
//            "DB_SERVER," .
//            "TRANS_CREATE_DATE," .
//            "TRANS_LAST_MODIFIED_DATE," .
//            "USER_ID," .
//            "CD_LT_RR_NUMBER," .
//            $vehicle_column . "," .
//            "LOADER_ID," .
//            "di_flag," .
//            "CONS_EWB_NUMBER," .
//            "Vehicle_Number) VALUES ('"
//            . $mastercon_detail_data['header_dispatch_id'] . "','"
//            . $mastercon_detail_data['bagManifestNumber'] . "','"
//            . $mastercon_detail_data['physicalWeight'] . "','"
//            . $mastercon_detail_data['remarks'] . "','"
//            . $mastercon_detail_data['loggedInOfficeType'] . "','"
//            . $mastercon_detail_data['loggedInOfficeId'] . "','"
//            . $mastercon_detail_data['destOfficeType'] . "','"
//            . $mastercon_detail_data['destOfficeId'] . "','"
//            . $mastercon_detail_data['modeId'] . "','"
//            . $mastercon_detail_data['serviceType'] . "',NULLIF('" . $mastercon_detail_data['DirectConnectionId'] . "','null'),'"
//            // .$mastercon_detail_data['DirectConnectionId'].",'"
//            . $mastercon_detail_data['cdDate'] . "','"
//            . $mastercon_detail_data['cdTime'] . "','"
//            . $mastercon_detail_data['db_server'] . "','"
//            . $mastercon_detail_data['server_date'] . "','"
//            . $mastercon_detail_data['server_date'] . "',"
//            . $mastercon_detail_data['loggedInUserId'] . ",NULLIF('" . $mastercon_detail_data['cdNumber'] . "','null'),'"
//            // .$mastercon_detail_data['cdNumber']."','"
//            . $column_value . "',NULLIF('" . $mastercon_detail_data['loaderId'] . "','null'),'"
//            // .$mastercon_detail_data['loaderId'].",'"
//            . $mastercon_detail_data['di_flag'] . "','"
//            . $mastercon_detail_data['consolidatedEWBNum'] . "','"
//            . $mastercon_detail_data['vehicleNumber'] . "')";

        $result = $this->db->insert('dtdc_f_disp_bag_mnfst_dtls',$insert_data);
        if ($result) {
            return $mastercon_detail_data['bagManifestNumber'];
        }
    }

    public function mastercondispatchchangescan($input)
    {

        $originOfficeId = isset($input['originOfficeId']) ? $input['originOfficeId'] : $this->error_response('originOfficeId is required');
        $bagManifestNumberOld = isset($input['bagManifestNumberOld']) ? $input['bagManifestNumberOld'] : $this->error_response('bagManifestNumberOld is required');
        $bagManifestNumberNew = isset($input['bagManifestNumberNew']) ? $input['bagManifestNumberNew'] : $this->error_response('bagManifestNumberNew is required');
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
        $query = "SELECT * FROM dtdc_f_disp_bag_mnfst_dtls WHERE DISPATCH_ID IN (SELECT DISPATCH_ID FROM dtdc_f_dispatch WHERE ORIGIN_OFFICE_ID= ? ) AND BAG_MANIFEST_NUMBER = ? limit 1";
        $result = $this->db->query($query,[$originOfficeId,$bagManifestNumberOld]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();
            unset($result_array[0]['Vehicle_Number']);
            unset($result_array[0]['Break_Van_Number']);
            unset($result_array[0]['BAG_CONF_STATUS']);
            unset($result_array[0]['BAG_HELDUP_REASON_ID']);
            unset($result_array[0]['ORIGIN_OFFICE_ID']);
            unset($result_array[0]['DEST_OFFICE_ID']);
            unset($result_array[0]['ORIGIN_OFFICE_TYPE']);
            unset($result_array[0]['DEST_OFFICE_TYPE']);
            unset($result_array[0]['ORIGIN_OFFICE_ID']);
            // $result = $this->db->insert('dtdc_f_disp_bag_mnfst_dtls_log',$result_array[0]);

            $query_update ="UPDATE dtdc_f_disp_bag_mnfst_dtls
            INNER JOIN dtdc_f_dispatch ON dtdc_f_disp_bag_mnfst_dtls.DISPATCH_ID = dtdc_f_dispatch.DISPATCH_ID
            SET dtdc_f_disp_bag_mnfst_dtls.BAG_MANIFEST_NUMBER = ?, 
                           dtdc_f_disp_bag_mnfst_dtls.REMARKS = ? ,
            dtdc_f_disp_bag_mnfst_dtls.TRANS_LAST_MODIFIED_DATE = CURDATE()
                       WHERE dtdc_f_dispatch.ORIGIN_OFFICE_ID= ?
            AND dtdc_f_disp_bag_mnfst_dtls.BAG_MANIFEST_NUMBER= ? ";

            // $query_update = "UPDATE dtdc_f_disp_bag_mnfst_dtls
            // INNER JOIN dtdc_f_dispatch ON dtdc_f_disp_bag_mnfst_dtls.DISPATCH_ID = dtdc_f_dispatch.DISPATCH_ID
            // SET BAG_MANIFEST_NUMBER = ? WHERE dtdc_f_dispatch.ORIGIN_OFFICE_ID= ?
            // AND dtdc_f_disp_bag_mnfst_dtls.BAG_MANIFEST_NUMBER= ? ";
            $result_update = $this->db->query($query_update,[$bagManifestNumberNew, $bagManifestNumberOld, $originOfficeId, $bagManifestNumberOld]);
            if ($result_update) {
                $this->response = array('status' => 1, 'message' => 'Updated');
            } else {
                $this->response = array('status' => 0, 'message' => 'Already updated!');
            }
        } else {
            $this->response = array('status' => 0, 'message' => 'Record not found');
        }

        return $this->response;
    }

    public function mastercondispatchremovalscan($input)
    {
        $originOfficeId = isset($input['originOfficeId']) ? $input['originOfficeId'] : $this->error_response('originOfficeId is not set');
        $bagManifestNumberOld = isset($input['bagManifestNumberOld']) ? $input['bagManifestNumberOld'] : $this->error_response('bagManifestNumberOld is not set');
        $bagManifestNumberNew = isset($input['bagManifestNumberNew']) ? $input['bagManifestNumberNew'] : $this->error_response('bagManifestNumberNew is not set');
        $reason = isset($input['reason']) ? $input['reason'] : $this->error_response('reason is not set');
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
        $consignments = isset($input['consignments']) ? $input['consignments'] : $this->error_response('consignments is not set');

        for ($i = 0; $i < count($consignments); $i++) {
            $consignmentNumber = $consignments[$i]['consignmentNumber'];
            if ($this->check_manifest_number_for_removal_scan($bagManifestNumberOld, $consignmentNumber, $originOfficeId)) {

                $this->update_manifest_number_for_removal_scan($bagManifestNumberOld, $bagManifestNumberNew, $consignmentNumber, $originOfficeId, $reason);
                //success response
                $this->response = array('status' => 1, 'message' => 'Removal scan done');
            } else {
                $check_details_query = "select * from  dtdc_f_disp_bag_mnfst_dtls where bag_manifest_number='$bagManifestNumberOld'";
                $result = $this->db->query($check_details_query);
                if ($result->num_rows() > 0) {
                    for ($j = 0; $j < $result->num_rows(); $j++) {
                        $update_details_query = "UPDATE dtdc_f_disp_bag_mnfst_dtls
            INNER JOIN dtdc_f_manifest ON dtdc_f_disp_bag_mnfst_dtls.MANIFEST_ID = dtdc_f_manifest.MANIFEST_ID
            SET BAG_MANIFEST_NUMBER ='$bagManifestNumberNew', dtdc_f_disp_bag_mnfst_dtls.REASON ='$reason'
            WHERE dtdc_f_disp_bag_mnfst_dtls.BAG_MANIFEST_NUMBER='$bagManifestNumberOld'
            AND dtdc_f_manifest.ORIG_BRNCH_ID='$originOfficeId'
            AND dtdc_f_manifest.CONSG_NUMBER='$consignmentNumber'";
                    }
                    //success response
                    $this->response = array('status' => 1, 'message' => 'Removal scan done');
                } else {
                    //Record not found
                    $this->response = array('status' => 0, 'message' => 'Record not found');
                }
            }
        }

        return $this->response;

    }

    public function check_manifest_number_for_removal_scan($manifestNumber, $consignmentNumber, $originOfficeId)
    {
        $check_query = "select * from dtdc_f_manifest where manifest_number= ? and consg_number= ? and orig_brnch_id= ?";
        $result = $this->db->query($check_query,[$manifestNumber,$consignmentNumber,$originOfficeId]);
        if ($result->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function update_manifest_number_for_removal_scan($manifestNumberOld, $manifestNumberNew, $consignmentNumber, $originOfficeId, $reason)
    {
        $update_query = "update dtdc_f_manifest
          SET MANIFEST_NUMBER = ?, REASON = ? WHERE CONSG_NUMBER = ? AND ORIG_BRNCH_ID= ? AND MANIFEST_NUMBER = ? ";
        if ($this->db->query($update_query,[$manifestNumberNew, $reason, $consignmentNumber, $originOfficeId, $manifestNumberOld])) {
            return true;
        }
    }

    public function mastercondispatchupdatecdno($input)
    {
        $loggedInOfficeId = isset($input['loggedInOfficeId']) ? $input['loggedInOfficeId'] : $this->error_response('loggedInOfficeId is not set');
        $cdDate = isset($input['cdDate']) ? $input['cdDate'] : $this->error_response('cdDate is not set');
        $cdTime = isset($input['cdTime']) ? $input['cdTime'] : $this->error_response('cdTime is not set');
        $cdNumber = isset($input['cdNumber']) ? $input['cdNumber'] : $this->error_response('cdNumber is not set');
        $dispatchNumber = isset($input['dispatchNumber']) ? $input['dispatchNumber'] : $this->error_response('dispatchNumber is not set');
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
        $this->mastercondispatch_update_in_header_table($cdDate, $cdTime, $cdNumber, $dispatchNumber, $loggedInOfficeId);
        // $this->db->select('dispatch_id');
        // $this->db->where('dispatch_number',$dispatchNumber);
        // $result = $this->db->get('dtdc_f_dispatch');
        $query = "select dispatch_id from dtdc_f_dispatch where dispatch_number = ? order by dispatch_id desc limit 1";
        $result = $this->db->query($query,[$dispatchNumber]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();
            $dispatchId = $result_array[0]['dispatch_id'];
            $bags = isset($input['bags']) ? $input['bags'] : $this->error_response('bags is not set');
            for ($i = 0; $i < count($bags); $i++) {
                $bagManifestNumber = $bags[$i]['bagManifestNumber'];
                $this->mastercondispatch_update_in_details_table($cdDate, $cdTime, $cdNumber, $dispatchId, $bagManifestNumber, $loggedInOfficeId);
            }
            $this->response = array('status' => 1, 'message' => 'Updated');
        } else {

            $this->response = array('status' => 0, 'message' => 'Record not found');
        }

        return $this->response;
    }

    public function mastercondispatch_update_in_header_table($cdDate, $cdTime, $cdNumber, $dispatchNumber, $loggedInOfficeId)
    {
        $query = "update dtdc_f_dispatch set cd_date = ?, cd_time= ?,CD_LT_RR_NUMBER= ? where dispatch_number = ? and ORIGIN_OFFICE_ID = ? ";
        if ($this->db->query($query,[$cdDate, $cdTime, $cdNumber, $dispatchNumber, $loggedInOfficeId])) {
            return true;
        }
    }

    public function mastercondispatch_update_in_details_table($cdDate, $cdTime, $cdNumber, $dispatchId, $bagManifestNumber, $loggedInOfficeId)
    {
        $query = "update dtdc_f_disp_bag_mnfst_dtls set cd_date = ?, cd_time = ? ,CD_LT_RR_NUMBER= ? where dispatch_id = ? and bag_manifest_number = ? and ORIGIN_OFFICE_ID = ? ";
        if ($this->db->query($query,[$cdDate, $cdTime, $cdNumber,$dispatchId, $bagManifestNumber,$loggedInOfficeId])) {
            return true;
        }
    }

    public function mastercondispatchgetdocumentid($input)
    {
        //Server response error.
        $loggedInOfficeId = isset($input['loggedInOfficeId']) ? $input['loggedInOfficeId'] : $this->error_response('loggedInOfficeId is not set');
        $manifest_number = isset($input['manifestNumber']) ? $input['manifestNumber'] : $this->error_response('manifestNumber is not set');

        //Previous changes Comments removed on 23 March 2018

        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        if($this->bookingModel->getBookingIdFromConsgNumber($manifest_number)){
            $this->response = array('status' => 0, 'message' => 'The Mother consignment is not allowed to process further. Please scan child consignments"');
            return $this->response;
        }

        $ewb_flag = 1;
        $manifestNumbersAssociationResultArray = [];
        $consignmentNumbersAssociationArray = [];

        if(strlen($manifest_number) == 8){

            $parentConsgResults = $this->getTheParentConsgNumberIfItsMultiPiceConsg($manifest_number);

            if($parentConsgResults) {
                foreach($parentConsgResults as $parentConsgResult){

                    $parentConsgNumber = $parentConsgResult['PARENT_CONSG_NO'];
                    $numOfPieces = $parentConsgResult['NO_OF_PIECES'];
                    $manifestNumbersAssociationResult = $this->getAllTheManifestNumbersAssociatedWithChildConsignments($parentConsgNumber, $loggedInOfficeId);
                    if( count($manifestNumbersAssociationResult) != $numOfPieces) {
                        $this->response = array('status' => 0, 'message' => 'Please manifest all the child consignments of the  parent consignment number '.$parentConsgNumber);
                        return $this->response;
                    }

                    $manifestNumbersAssociationResultArray = array_merge($manifestNumbersAssociationResultArray,$manifestNumbersAssociationResult);

                }

            }
        } else if(strlen($manifest_number) == 12){
            $consignmentNumbersAssociationArray = $this->getAllTheConsignmentNumbersAssociated($manifest_number);
        }


        $sql3 = "select dest_brnch_id from dtdc_f_manifest
        where manifest_number = ? and manifest_type='O' order by manifest_id desc limit 1";
        $sql3 = "select distinct(manifest_number) MF,dest_brnch_id, mode_id from dtdc_f_manifest
        where manifest_number = ? and manifest_type='O' order by manifest_date desc limit 1";
       

        $dest_branch_id = null;

        $query3 = $this->db->query($sql3,[$manifest_number]);

        if ($query3->num_rows() > 0) {
            $dest_branch_id = $query3->result_array()[0]['dest_brnch_id'];
        }

        if (strlen($manifest_number) === 8) {

        $sql1= "(select manifest_id MF,tot_weight_kgs,
        document_id, no_of_pieces from dtdc_f_manifest
        where manifest_number = ? and manifest_type='O' and orig_brnch_id= ? and mnfst_type_id in (1,2,5) )
        union
        (select cd_recv_mnfst_dtls_id MF, phy_weight, 1 document_id,
        1 no_of_pieces from dtdc_f_cd_recv_mnfst_dtls where
        bag_manifest_number = ? and dest_office_id = ? and phy_weight > 0) order by MF desc LIMIT 1";
       
        //     $sql2 = "(select manifest_id MF, mode_id from dtdc_f_manifest
        // where manifest_number = ? and manifest_type='O')
        // union
        // (select cd_recv_mnfst_dtls_id MF, mode_id from dtdc_f_cd_recv_mnfst_dtls where
        // bag_manifest_number = ? and dest_office_id = ? and phy_weight > 0) order by MF desc LIMIT 1";

        $sql2 = "select distinct(manifest_number) MF, mode_id from dtdc_f_manifest
        where manifest_number = ? and manifest_type='O' order by manifest_date desc limit 1";
        
            $query1 = $this->db->query($sql1,[$manifest_number, $loggedInOfficeId, $manifest_number, $loggedInOfficeId]);

            if ($query1->num_rows() > 0) {
                //check if bag is offloaded
                if ($this->is_bag_duplicate_or_offloaded($manifest_number, $loggedInOfficeId)) {
                    $bag_status = 'duplicate';
                } else {
                    $bag_status = 'allow';
                }

                $query2 = $this->db->query($sql2, [$manifest_number]);

                if ($query2->num_rows() > 0) {
                    $result2 = $query2->result_array()[0];
                    $mode_id = $result2['mode_id'];
                } else {
                    $mode_id = null;
                }


                $result_array = $query1->result_array()[0];
                $result_array['mode_id'] = $mode_id;
                $result_array['ewb_numbers'] = $this->getCtrlNumbersFromManifest($manifest_number, $loggedInOfficeId);
                $result_array['dest_branch_id'] = $dest_branch_id;
                $consignment_numbers = $this->getGorConsignmentNumbersFromManifest($manifest_number, $loggedInOfficeId);

                $ewb_mixed_allow = 0;

                if ($this->checkForMixedEwb($manifest_number, $loggedInOfficeId)) {
                    $ewb_mixed_allow = 1;
                }

                if (count($consignment_numbers) > 0) {

                    $ewb_status = $this->getEwbStatusFromConsignments($consignment_numbers);
                    if ($ewb_status) {
                        $ewb_flag = 0;
                    }
                }


                $this->response = array(
                    'status' => 1,
                    'details' => $result_array,
                    'bag_allow_status' => $bag_status,
                    'ewb_flag' => $ewb_flag,
                    'manifest_numbers_association' => $manifestNumbersAssociationResultArray,
                    'consignment_numbers_association' => $consignmentNumbersAssociationArray,
                    'ewb_mixed_allow' => $ewb_mixed_allow
                );

            } else {
                $this->response = array('status' => 0, 'message' => 'The Incoming or Outgoing bag data is not available.');
            }

            return $this->response;

        } else {

            $sql = "(select booking_id MF,FINAL_WEIGHT as tot_weight_kgs,
                  document_id, no_of_pieces, mode_id from dtdc_f_booking
                  where CONSG_NUMBER = ? and BRNCH_OFF_ID = ?)
                  union
                  (select cd_recv_mnfst_dtls_id MF, phy_weight as tot_weight_kgs, 1 document_id,
                  1 no_of_pieces, mode_id from dtdc_f_cd_recv_mnfst_dtls where
                  bag_manifest_number = ? and dest_office_id = ? and phy_weight > 0)
                  union
                  (select manifest_id MF,INDV_WEIGHT_KGS,
                  document_id, no_of_pieces, mode_id from dtdc_f_manifest
                  where CONSG_NUMBER = ? and manifest_type='I' and DEST_BRNCH_ID = ?)
                  order by MF desc LIMIT 1";
            $query = $this->db->query($sql, [
                $manifest_number,
                $loggedInOfficeId,
                $manifest_number,
                $loggedInOfficeId,
                $manifest_number,
                $loggedInOfficeId
            ]);


            if ($query->num_rows() > 0) {
                $result_array = $query->result_array()[0];
                $result_array['dest_branch_id'] = $dest_branch_id;
                $result_array['ewb_numbers'] = $this->getCtrlNumbersForConsignmentNumber($manifest_number, $loggedInOfficeId);
                if ($this->is_bag_duplicate_or_offloaded($manifest_number, $loggedInOfficeId)) {
                    $bag_status = 'duplicate';
                } else {
                    $bag_status = 'allow';
                }

                $ewb_flag = $this->getEwbFlagForConsignment($manifest_number, $loggedInOfficeId);

                $this->response = array(
                    'status' => 1,
                    'details' => $result_array,
                    'bag_allow_status' => $bag_status,
                    'ewb_flag' => $ewb_flag,
                    'manifest_numbers_association' => $manifestNumbersAssociationResultArray,
                    'consignment_numbers_association' => $consignmentNumbersAssociationArray,
                    'ewb_mixed_allow' => 1
                );
            } else {
                $this->response = array('status' => 0, 'message' => 'Record not found');
            }

            return $this->response;

        }


    }

    public function getModeIdForMCD($input){
        //Server response error.
        $loggedInOfficeId = isset($input['loggedInOfficeId']) ? $input['loggedInOfficeId'] : $this->error_response('loggedInOfficeId is not set');
        $manifest_number = isset($input['manifestNumber']) ? $input['manifestNumber'] : $this->error_response('manifestNumber is not set');

        //Previous changes Comments removed on 23 March 2018
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $sql2 = "select distinct(manifest_number) MF, mode_id from dtdc_f_manifest
        where manifest_number = ? and manifest_type='O' order by manifest_date desc limit 1";
        $query2 = $this->db->query($sql2, [$manifest_number]);
         $result_array = $query2->result_array();
        if ($query2->num_rows() > 0) {
            $mode_id = $result_array[0]['mode_id'];
        } else {
            $mode_id = null;
        }
       
        if(!$result_array){
            return $this->response = array('status' => 0, 'message' => 'Record not found');
        }
        $result['mode_id'] = $mode_id;
        return $this->response = array(
            'status' => 1,
            'details' => $result
        );
     

    }

    public function getTheParentConsgNumberIfItsMultiPiceConsg($manifestNumber) {

        $sql1 = "select CONSG_NUMBER from dtdc_f_manifest where MANIFEST_NUMBER = ? and (NO_OF_BAG_MADE != null or NO_OF_BAG_MADE !=0);";
        $query1 = $this->db->query($sql1, [$manifestNumber]);
        $consignment_numbers = [];
        if ($query1->num_rows() > 0) {
            $query_results =  $query1->result_array();
            foreach($query_results as $query_result) {
            	array_push($consignment_numbers, $query_result['CONSG_NUMBER']);
            }
        } else {
            return false;
        }

        $sql2 = "select b1.PARENT_CONSG_NO, b2.NO_OF_PIECES from dtdc_f_booking b1 left join dtdc_f_booking b2 on b1.PARENT_CONSG_NO = b2.CONSG_NUMBER where b1.CONSG_NUMBER in  ? ;";
        $query2 = $this->db->query($sql2, [$consignment_numbers]);


        if ($query2->num_rows() > 0) {
            return $query2->result_array();
        } else {
            return false;
        }

    }

    public function getAllTheManifestNumbersAssociatedWithChildConsignments($parentConsgNumber, $loggedInOfficeId) {

        $sql = "select m.MANIFEST_NUMBER from dtdc_f_manifest m,dtdc_f_booking b where m.CONSG_NUMBER=b.CONSG_NUMBER and b.PARENT_CONSG_NO = ? and m.ORIG_BRNCH_ID = ? and m.MANIFEST_TYPE='O';";
        $query = $this->db->query($sql, [$parentConsgNumber, $loggedInOfficeId]);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return [];
        }
    }

    public function getAllTheConsignmentNumbersAssociated($consgNumber) {

        $sql = "select consg_number from dtdc_f_booking where PARENT_CONSG_NO = (select PARENT_CONSG_NO from dtdc_f_booking where CONSG_NUMBER = ?);";
        $query = $this->db->query($sql, [$consgNumber]);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return [];
        }
    }

    public function getCtrlNumbersForConsignmentNumber($manifest_number, $origin_office_id)
    {
        $sql = "SELECT EWB_NUMBER as CTRL_NUMBER, CONSG_NUMBER FROM dtdc_f_ewb_info WHERE CONSG_NUMBER = ? AND TRANS_OFFICE_ID = ?";
        $query = $this->db->query($sql, [$manifest_number, $origin_office_id]);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return [];
        }
    }

    public function getEwbFlagForConsignment($consignment_number, $logged_in_office_id)
    {
        $sql = "select EWB_STATUS from dtdc_f_ewb_info where CONSG_NUMBER = ? and TRANS_OFFICE_ID = ? and EWB_STATUS = 'N'";
        $query = $this->db->query($sql, [$consignment_number, $logged_in_office_id]);
        if ($query->num_rows() > 0) {
            return 0;
        } else {
            return 1;
        }
    }

    public function getCtrlNumbersFromManifest($manifest_number, $origin_office_id)
    {
        $sql = "SELECT CTRL_NUMBER, CONSG_NUMBER FROM dtdc_f_manifest WHERE MANIFEST_NUMBER = ? AND ORIG_BRNCH_ID = ?";
        $query = $this->db->query($sql, [$manifest_number, $origin_office_id]);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return [];
        }
    }

    public function checkForMixedEwb($manifest_number, $logged_in_office_id)
    {
        $sql = "SELECT EWB_STATUS FROM dtdc_f_ewb_info WHERE consg_number IN (SELECT substring(consg_number,1,9) FROM dtdc_f_manifest WHERE manifest_number = ? AND WVC_FLAG = 'Y') AND TRANS_OFFICE_ID = ?";
        $query = $this->db->query($sql, [$manifest_number, $logged_in_office_id]);
        if ($query->num_rows() > 0) {
            $results = $query->result_array();
            for ($i = 0; $i < count($results); $i++) {
                if ($results[$i]['EWB_STATUS'] !== 'Y') {
                    return false;
                }
            }

            return true;
        } else {
            return true;
        }
    }


    public function getGorConsignmentNumbersFromManifest($manifest_number, $origin_branch_id)
    {
        $sql = "SELECT consg_number FROM dtdc_f_manifest WHERE MANIFEST_NUMBER = ? AND ORIG_BRNCH_ID = ? AND NODE_ID = 'GOR'";
        $query = $this->db->query($sql, [$manifest_number, $origin_branch_id]);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return [];
        }
    }

    public function getEwbStatusFromConsignments($consignment_numbers)
    {
        $consignment_numbers_9_digit_array = [];

        foreach ($consignment_numbers as $consignment_number) {
            $consignment_number_9_digit = "'" . substr($consignment_number['consg_number'], 0, 9) . "'";
            array_push($consignment_numbers_9_digit_array, $consignment_number_9_digit);
        }

        $consignment_numbers_csv = implode(',', $consignment_numbers_9_digit_array);


//        $sql = "select * from dtdc_f_ewb_info where consg_number in ($consignment_numbers_csv) AND EWB_STATUS = 'Y'";

        $sql = "select * from dtdc_f_ewb_info where consg_number in ( ? ) AND (EWB_STATUS = 'N' OR EWB_STATUS = null)";

        $query = $this->db->query($sql,[$consignment_numbers_csv]);

        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }

    }


    public function is_bag_duplicate_or_offloaded($manifest_number, $loggedInOfficeId)
    {
        $sql = "SELECT * FROM dtdc_f_disp_bag_mnfst_dtls where  bag_manifest_number= ? and (bag_conf_status != '2' or bag_conf_status is null) and ORIGIN_OFFICE_ID = ? ";
        $query = $this->db->query($sql,[$manifest_number,$loggedInOfficeId]);
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function gettsroutemapping($input)
    {
        foreach ($input as $key => $value) {
            if (strlen($value) == 1) {
                $input[$key] = "00" . $value;
            }
            if (strlen($value) == 2) {
                $input[$key] = "0" . $value;
            }
        }
        $originOfficeId = isset($input['originOfficeId']) ? $input['originOfficeId'] : $this->error_response('originOfficeId is not set');
        $destOfficeId = isset($input['destOfficeId']) ? $input['destOfficeId'] : $this->error_response('destOfficeId is not set');
        // $rm_code = isset($input['rmCode']) ? $input['rmCode'] : $this->error_response('rmCode is not set');
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
        $query = "select this_.RTM_TS1 , this_.RTM_TS2 , this_.RTM_TS3  from route_ts_mapping this_ where
(this_.RTM_ORG_OFF_ID like '%".$this->db->escape_like_str($originOfficeId)."%' or (this_.RTM_ORG_OFF_ID like '%".$this->db->escape_like_str($originOfficeId)."%' or (this_.RTM_ORG_OFF_ID like '%".$this->db->escape_like_str($originOfficeId)."%' or
this_.RTM_ORG_OFF_ID like '%".$this->db->escape_like_str($originOfficeId)."%'))) and (this_.RTM_DEST_OFF_ID like '%".$this->db->escape_like_str($destOfficeId)."%' or
(this_.RTM_DEST_OFF_ID like '%".$this->db->escape_like_str($destOfficeId)."%' or (this_.RTM_DEST_OFF_ID like '%".$this->db->escape_like_str($destOfficeId)."%' or this_.RTM_DEST_OFF_ID like '%".$this->db->escape_like_str($destOfficeId)."%')))";

// echo $query;

        // $query = "select this_.RTM_TS1 , this_.RTM_TS2 , this_.RTM_TS3  from
        // route_ts_mapping this_ where (this_.RTM_ORG_OFF_ID like '$origin_branch_num_code' or
        // (this_.RTM_ORG_OFF_ID like '$origin_branch_num_code%' or (this_.RTM_ORG_OFF_ID like '%$origin_branch_num_code%'
        // or this_.RTM_ORG_OFF_ID like '%$origin_branch_num_code'))) and (this_.RTM_DEST_OFF_ID like '$dest_branch_num_code' or
        // (this_.RTM_DEST_OFF_ID like '$dest_branch_num_code%' or (this_.RTM_DEST_OFF_ID like '%$dest_branch_num_code%' or
        // this_.RTM_DEST_OFF_ID like '%$dest_branch_num_code'))) and this_.RTM_TO_PROD_CODE>='$rm_code' and this_.RTM_FROM_PROD_CODE<='$rm_code' and this_.THU='1'";

        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();
            $this->response = array('status' => 1, 'details' => $result_array[0]);
        } else {
            $this->response = array('status' => 0, 'message' => 'Record not found');
        }

        return $this->response;
    }


    public function get_origin_branch_id_from_dtdc_f_manifest($manifestNumber)
    {
        $query = "select ORIG_BRNCH_ID from dtdc_f_manifest where manifest_type='O' AND MANIFEST_NUMBER= ? ";
        // echo $query;
        $result = $this->db->query($query,[$manifestNumber]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();

            return $result_array[0]['ORIG_BRNCH_ID'];
        } else {
            return false;
        }
    }

    public function get_pincode_id_dtdc_d_pincode($pincode)
    {
        $query = "select pincode_id FROM dtdc_d_pincode where pin_code= ? ";
        $result = $this->db->query($query,[$pincode]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();

            return $result_array[0]['pincode_id'];
        } else {
            return false;
        }
    }

    public function get_dest_city_id_from_pincode($pincode)
    {
        $query = "select CITY_ID FROM dtdc_d_area WHERE pincode_id = (select pincode_id FROM dtdc_d_pincode where pin_code= ? limit 1) LIMIT 1";
        $result = $this->db->query($query,[$pincode]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();

            return $result_array[0]['CITY_ID'];
        } else {
            return false;
        }
    }

    public function get_branch_id_dtdc_d_office($destBranchCode)
    {
        $query = "select office_id from dtdc_d_office where office_code = ? ";
        $result = $this->db->query($query,[$destBranchCode]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();

            return $result_array[0]['office_id'];
        } else {
            return false;
        }
    }

    public function get_document_id_from_dtdc_f_booking($consgNumber)
    {
        $query = "select document_id from dtdc_f_booking where consg_number = ? ";
        $result = $this->db->query($query,[$consgNumber]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();

            return $result_array[0]['document_id'];
        } else {
            return false;
        }
    }

    public function get_rep_off_id_from_dtdc_d_office($loggedinOfficeCode)
    {
        $query = "select REPORT_REGOFF_ID from dtdc_d_office where office_code= ? ";
        $result = $this->db->query($query,[$loggedinOfficeCode]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();

            return $result_array[0]['REPORT_REGOFF_ID'];
        } else {
            return false;
        }
    }

    public function get_rm_entity_type_from_dtdc_d_routing_master($productId)
    {
        $query = "select RM_ENTITY_TYPE from dtdc_d_routing_master WHERE RM_CODE= ? ";
        $result = $this->db->query($query,[$productId]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();

            return $result_array[0]['RM_ENTITY_TYPE'];
        } else {
            return false;
        }
    }

    public function get_document_id_from_dtdc_f_manifest($manifestNumber)
    {
        $query = "select DOCUMENT_ID from dtdc_f_manifest where manifest_number= ? and manifest_type='O'";
        $result = $this->db->query($query,[$manifestNumber]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();

            return $result_array[0]['DOCUMENT_ID'];
        } else {
            return false;
        }
    }

    public function get_total_consignment_number_from_dtdc_f_manifest($manifestNumber)
    {
        $query = "select TOT_CONSG_NUM from dtdc_f_manifest where manifest_number= ? and manifest_type='O'";
        $result = $this->db->query($query,[$manifestNumber]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();

            return $result_array[0]['TOT_CONSG_NUM'];
        } else {
            return false;
        }
    }

    public function outgoingbagmanifestsearch($input)
    {
        $manifestNumber = isset($input['manifestNumber']) ? $input['manifestNumber'] : $this->error_response('Manifest number is required');
        $officeId = isset($input['loggedInOfficeId']) ? $input['loggedInOfficeId'] : $this->error_response('Logged in office id is not set');
//ORIG_BRNCH_ID
        $query = "select consg_number,desc_goods, remarks, mnfst_type_id, document_id, manifest_type_defn, dest_brnch_id, indv_weight_kgs, mode_id from dtdc_f_manifest where manifest_number = ? and manifest_type = 'O' and orig_brnch_id = ?";
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
        $result = $this->db->query($query,[$manifestNumber,$officeId]);
        // echo $query;
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();
            $dest_brnch_id = $result_array[0]['dest_brnch_id']; //mode_id
            $mode_id = $result_array[0]['mode_id'];
            $document_id = $result_array[0]['document_id'];
            $manifest_type_defn = $result_array[0]['manifest_type_defn'];

            if (($document_id == 1) || $document_id == 2) {
                $query_check_in_consignments = "select manifest_number from dtdc_f_manifest where consg_number = ? and manifest_type = 'O' and orig_brnch_id = ?";
                $result_check_in_consignments = $this->db->query($query_check_in_consignments,[$manifestNumber,$officeId]);
                if ($result_check_in_consignments->num_rows() > 0) {
                    $allow_update = 'false';
                } else {
                    $allow_update = 'true';
                    if ($document_id == 2) {
                        $query_check_in_bag_mnfst_dtls = "select bag_manifest_number from dtdc_f_disp_bag_mnfst_dtls where bag_manifest_number = ?";
                        $result_check_in_bag_mnfst_dtls = $this->db->query($query_check_in_bag_mnfst_dtls,[$manifestNumber]);
                        if ($result_check_in_bag_mnfst_dtls->num_rows() > 0) {
                            $allow_update = 'false';
                        } else {
                            $allow_update = 'true';
                        }
                    }
                }
            }

            //office
            $office_query = "select office_code, office_name from dtdc_d_office where office_id = ? limit 1";
            $office_result = $this->db->query($office_query,[$dest_brnch_id]);
            $office_array = $office_result->result();

            //mode
            $mode_query = "select mode_id, mode_name from dtdc_d_mode where mode_id = ?";
            $mode_result = $this->db->query($mode_query,[$mode_id]);
            $mode_array = $mode_result->result_array();

            return $response = array(
                'result' => $result_array,
                'office' => $office_array,
                'mode' => $mode_array,
                'allow_update' => $allow_update
            );
        } else {
            return $response = array('result' => array());
        }
    }

    public function removalentity($input)
    {
        $number = isset($input['num']) ? $input['num'] : $this->error_response('num is required');
        $logOffId = isset($input['logOffId']) ? $input['logOffId'] : $this->error_response('logOffId is required');
        // $central = isset($input['central']) ? $input['central'] : $this->error_response('central is required');
        $numType = isset($input['numType']) ? $input['numType'] : $this->error_response('numType is required');
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
        if ($numType == 'pmfsticker/surelock') {
            $query = "select manifest_type_defn from dtdc_f_manifest where manifest_number = ? order by manifest_id desc limit 1";
            $result = $this->db->query($query,[$number]);
            if ($result->num_rows() > 0) {
                $result_array = $result->result_array();
                $numType = strtolower($result_array[0]['manifest_type_defn']);
                if (!$numType) {
                    $numType = 'surelock';
                }
            }
        }
        // echo $numType;
        switch ($numType) {
            case 'consignment':
                $response = $this->removalentity_consignment($number, $logOffId);
                break;
            case 'pmf':
                $manifest_number = $number;
                $response = $this->removalentity_pmf_bmf_pmfsticker($manifest_number, $logOffId);
                break;
            case 'bmf':
                $manifest_number = $number;
                $response = $this->removalentity_pmf_bmf_pmfsticker($manifest_number, $logOffId);
                break;
            case 'pmfsticker':
                break;
            case 'surelock':
                $manifest_number = $number;
                $response = $this->removalentity_surelock($manifest_number, $logOffId);
                break;

            default:
                # code...
                break;
        }

        return $response;
    }

    public function removalentity_consignment($consignmentNumber, $logOffId)
    {
        $support = new Support_model();
        $result_incoming_array = $support->get_row_incoming_from_dtdc_f_manifest($consignmentNumber, $logOffId);
        $result_outgoing_array = $support->get_row_outgoing_from_dtdc_f_manifest($consignmentNumber, $logOffId);
        if (count($result_incoming_array) > 0) {
            $incoming_date = $result_incoming_array[0]['RECORD_ENTRY_DATETIME'];
        } else {
            $incoming_date = "0000-00-00 00:00:00";
        }
        if (count($result_outgoing_array) > 0) {
            $outgoing_date = $result_outgoing_array[0]['RECORD_ENTRY_DATETIME'];
        } else {
            $outgoing_date = "0000-00-00 00:00:00";
        }
        $incoming_date_obj = new DateTime($incoming_date, new DateTimeZone('Asia/Kolkata'));
        $outgoing_date_obj = new DateTime($outgoing_date, new DateTimeZone('Asia/Kolkata'));
        if ($outgoing_date_obj > $incoming_date_obj) {
            $insert_query_array = $result_outgoing_array[0];
            $update_query_array_all = $support->outgoing_get_all_manifests_from_manifest_number($result_outgoing_array[0]['MANIFEST_NUMBER']);
            $new_total_weight = $result_outgoing_array[0]['TOT_WEIGHT_KGS'] - $result_outgoing_array[0]['INDV_WEIGHT_KGS'];
            $new_total_consignment_numbers = $result_outgoing_array[0]['TOT_CONSG_NUM'] - 1;
            $manifest_id_to_be_null = $result_outgoing_array[0]['manifest_id'];
            $update_query_make_null = "update dtdc_f_manifest set manifest_number = null where manifest_id = ? ";
            $this->db->query($update_query_make_null,[$manifest_id_to_be_null]);
            for ($i = 0; $i < count($update_query_array_all); $i++) {
                $manifest_id = $update_query_array_all[$i]['MANIFEST_ID'];
                $query = "update dtdc_f_manifest set TOT_WEIGHT_KGS = ? ,  TOT_CONSG_NUM = ? where MANIFEST_ID = ? ";
                $this->db->query($query,[$new_total_weight,$new_total_consignment_numbers,$manifest_id]);
            }

        } else if ($incoming_date_obj > $outgoing_date_obj) {
            $insert_query_array = $result_incoming_array[0];
            $update_query_array_all = $support->incoming_get_all_manifests_from_manifest_number($result_incoming_array[0]['MANIFEST_NUMBER']);
            $new_total_weight = $result_outgoing_array[0]['TOT_WEIGHT_KGS'] - $result_outgoing_array[0]['INDV_WEIGHT_KGS'];
            $new_total_consignment_numbers = $result_outgoing_array[0]['TOT_CONSG_NUM'] - 1;
            $manifest_id_to_be_null = $result_incoming_array[0]['manifest_id'];
            $update_query_make_null = "update dtdc_f_manifest set manifest_number = null where manifest_id = ? ";
            $this->db->query($update_query_make_null,[$manifest_id_to_be_null]);
            for ($i = 0; $i < count($update_query_array_all); $i++) {
                $manifest_id = $update_query_array_all[$i]['MANIFEST_ID'];
                $query = "update dtdc_f_manifest set TOT_WEIGHT_KGS = ?,  TOT_CONSG_NUM = ? where MANIFEST_ID = ? ";
                $this->db->query($query,[$new_total_weight,$new_total_consignment_numbers,$manifest_id]);
            }
        } else {
            $response = array('status' => 0, 'message' => 'No records found');

            return $response;
        }
        $unknown_columns = array(
            'MANIFEST_ID',
            'INTL_CMMDTY_ID',
            'DESC_GOODS',
            'DOM_CMMDTY_ID',
            'RECORD_ENTRY_DATETIME',
            'WVC_FLAG',
            'RLP_Status',
            'GET_TRANS_FLAG',
            'ITBS_TRANSFER_TIME',
            'GETONLINE_TRANSFER_TIME',
            'MANUAL_DOWNLOAD_FLAG',
            'ARRIVAL_DATE_TIME',
            'WAR_DATE',
            'SMS_STATUS'
        );
        foreach ($unknown_columns as $key => $value) {
            unset($insert_query_array[$value]);
        }
        if ($this->db->insert('dtdc_l_manifest', $insert_query_array)) {
            $response = array('status' => 1, 'message' => 'Consignment removal success');
        } else {
            $response = array('status' => 0, 'message' => 'Consignment removal failed');
        }

        return $response;
    }

    public function removalentity_pmf_bmf_pmfsticker($manifestNumber, $logOffId)
    {
        $support = new Support_model();
        $result_incoming_array = $support->get_row_incoming_from_dtdc_f_manifest_using_manifest_number($manifestNumber, $logOffId);
        $result_outgoing_array = $support->get_row_outgoing_from_dtdc_f_manifest_using_manifest_number($manifestNumber, $logOffId);
        if (count($result_incoming_array) > 0) {
            $incoming_date = $result_incoming_array[0]['RECORD_ENTRY_DATETIME'];
        } else {
            $incoming_date = "0000-00-00 00:00:00";
        }
        if (count($result_outgoing_array) > 0) {
            $outgoing_date = $result_outgoing_array[0]['RECORD_ENTRY_DATETIME'];
        } else {
            $outgoing_date = "0000-00-00 00:00:00";
        }

        $incoming_date_obj = new DateTime($incoming_date, new DateTimeZone('Asia/Kolkata'));
        $outgoing_date_obj = new DateTime($outgoing_date, new DateTimeZone('Asia/Kolkata'));
        if ($outgoing_date_obj > $incoming_date_obj) {
            $insert_query_array = $result_outgoing_array[0];
            $update_query_array_all = $support->outgoing_get_all_manifests_from_manifest_number($result_outgoing_array[0]['MANIFEST_NUMBER']);
            $new_total_weight = $result_outgoing_array[0]['TOT_WEIGHT_KGS'] - $result_outgoing_array[0]['INDV_WEIGHT_KGS'];
            $new_total_consignment_numbers = $result_outgoing_array[0]['TOT_CONSG_NUM'] - 1;
            $manifest_id_to_be_null = $result_outgoing_array[0]['manifest_id'];
            $update_query_make_null = "update dtdc_f_manifest set manifest_number = null where manifest_id = ? ";
            $this->db->query($update_query_make_null,[$manifest_id_to_be_null]);
            for ($i = 0; $i < count($update_query_array_all); $i++) {
                $manifest_id = $update_query_array_all[$i]['MANIFEST_ID'];
                $query = "update dtdc_f_manifest set TOT_WEIGHT_KGS = ?,  TOT_CONSG_NUM = ? where MANIFEST_ID = ?";
                $this->db->query($query,[$new_total_weight,$new_total_consignment_numbers,$manifest_id]);
            }

        } else if ($incoming_date_obj > $outgoing_date_obj) {
            $insert_query_array = $result_incoming_array[0];
            $update_query_array_all = $support->incoming_get_all_manifests_from_manifest_number($result_incoming_array[0]['MANIFEST_NUMBER']);
            $new_total_weight = $result_outgoing_array[0]['TOT_WEIGHT_KGS'] - $result_outgoing_array[0]['INDV_WEIGHT_KGS'];
            $new_total_consignment_numbers = $result_outgoing_array[0]['TOT_CONSG_NUM'] - 1;
            $manifest_id_to_be_null = $result_incoming_array[0]['manifest_id'];
            $update_query_make_null = "update dtdc_f_manifest set manifest_number = null where manifest_id = ?";
            $this->db->query($update_query_make_null,[$manifest_id_to_be_null]);
            for ($i = 0; $i < count($update_query_array_all); $i++) {
                $manifest_id = $update_query_array_all[$i]['MANIFEST_ID'];
                $query = "update dtdc_f_manifest set TOT_WEIGHT_KGS = ?,  TOT_CONSG_NUM = ? where MANIFEST_ID = ?";
                $this->db->query($query,[$new_total_weight,$new_total_consignment_numbers,$manifest_id]);
            }
        } else {
            $response = array('status' => 0, 'message' => 'No records found');

            return $response;
        }
        $unknown_columns = array(
            'MANIFEST_ID',
            'INTL_CMMDTY_ID',
            'DESC_GOODS',
            'DOM_CMMDTY_ID',
            'RECORD_ENTRY_DATETIME',
            'WVC_FLAG',
            'RLP_Status',
            'GET_TRANS_FLAG',
            'ITBS_TRANSFER_TIME',
            'GETONLINE_TRANSFER_TIME',
            'MANUAL_DOWNLOAD_FLAG',
            'ARRIVAL_DATE_TIME',
            'WAR_DATE',
            'SMS_STATUS'
        );
        foreach ($unknown_columns as $key => $value) {
            unset($insert_query_array[$value]);
        }
        if ($this->db->insert('dtdc_l_manifest', $insert_query_array)) {
            $response = array('status' => 1, 'message' => 'pmf removal success');
        } else {
            $response = array('status' => 0, 'message' => 'pmf removal failed');
        }

        return $response;
    }

    public function removalentity_surelock($manifestNumber, $logOffId)
    {
        $support = new Support_model();
        $result_incoming_array = $support->get_row_incoming_from_dtdc_f_cd_receive_using_manifest_number($manifestNumber, $logOffId);
        $result_outgoing_array = $support->get_row_outgoing_from_dtdc_f_dispatch_using_manifest_number($manifestNumber, $logOffId);
        // print_r($result_incoming_array);
        if (count($result_incoming_array) > 0) {
            $incoming_date = $result_incoming_array[0]['TRANS_CREATE_DATE'];
        } else {
            $incoming_date = "0000-00-00 00:00:00";
        }
        if (count($result_outgoing_array) > 0) {
            $outgoing_date = $result_outgoing_array[0]['TRANS_CREATE_DATE'];
        } else {
            $outgoing_date = "0000-00-00 00:00:00";
        }


        $incoming_date_obj = new DateTime($incoming_date, new DateTimeZone('Asia/Kolkata'));
        $outgoing_date_obj = new DateTime($outgoing_date, new DateTimeZone('Asia/Kolkata'));
        if ($outgoing_date_obj > $incoming_date_obj) {
            $insert_query_array = $result_outgoing_array[0];
            $update_query_array_all = $result_outgoing_array;
            // $update_query_array_all = $support->incoming_get_all_manifests_from_dtdc_f_cd_receive_using_manifest_number($result_incoming_array[0]['BAG_MANIFEST_NUMBER']);
            $new_total_weight = $result_outgoing_array[0]['TOTAL_WEIGHT'] - $result_outgoing_array[0]['PHYSICAL_WEIGHT'];
            $new_no_of_bags = $result_outgoing_array[0]['NO_BAGS'] - 1;

            for ($i = 1; $i < count($update_query_array_all); $i++) {
                $dispatch_id = $update_query_array_all[$i]['DISPATCH_ID'];
                $query = "update dtdc_f_dispatch set TOTAL_WEIGHT = ?,  NO_BAGS = ? where DISPATCH_ID = ?";
                $this->db->query($query,[$new_total_weight,$new_no_of_bags,$dispatch_id]);
            }
            $unknown_columns = array(
                'DISPATCH_ID',
                'ACTUAL_DEPARTURE_TIME',
                'OTC_ID',
                'ACTUAL_DEPARTURE_DATE',
                'BAGGAGE_COST',
                'BAGGAGE_WEIGHT',
                'FR_SYNC',
                'franchisee_id',
                'Vehicle_Number',
                'Break_Van_Number',
                'TRIP_SHEET_NUMBER',
                'NO_BAGS',
                'BAG_MANIFEST_NUMBER',
                'PHYSICAL_WEIGHT',
                'REASON',
                'BAG_CONF_STATUS',
                'BAG_HELDUP_REASON_ID',
                'OAD_ALERT_FLAG',
                'OPENING_KM',
                'LENGTH',
                'BREADTH',
                'HEIGHT',
                'VOLUMETRIC_WEIGHT',
                'MANUAL_DOWNLOAD_FLAG',
                'ARRIVAL_DATE_TIME',
                'REMARKS',
                'DISPATCH_ID_DN'
            );
            foreach ($unknown_columns as $key => $value) {
                unset($insert_query_array[$value]);
            }
            if ($this->db->insert('dtdc_l_dispatch', $insert_query_array)) {
                $response = array('status' => 1, 'message' => 'surelock removal success');
            } else {
                $response = array('status' => 0, 'message' => 'surelock removal failed');
            }

        } else if ($incoming_date_obj > $outgoing_date_obj) {

            $insert_query_array = $result_incoming_array[0];
            $update_query_array_all = $result_incoming_array;
            // $update_query_array_all = $support->incoming_get_all_manifests_from_dtdc_f_cd_receive_using_manifest_number($result_incoming_array[0]['BAG_MANIFEST_NUMBER']);
            $new_total_weight = $result_outgoing_array[0]['TOTAL_WEIGHT'] - $result_outgoing_array[0]['PHYSICAL_WEIGHT'];
            $new_no_of_bags = $result_outgoing_array[0]['NO_BAGS'] - 1;

            for ($i = 1; $i < count($update_query_array_all); $i++) {
                $dispatch_id = $update_query_array_all[$i]['DISPATCH_ID'];
                $query = "update dtdc_f_cd_receive set TOTAL_WEIGHT = ?,  NO_BAGS = ? where DISPATCH_ID = ?";
                $this->db->query($query,[$new_total_weight,$new_no_of_bags,$dispatch_id]);
            }

            $unknown_columns = array(
                'TEMP_VEHICAL_NAME',
                'OTC_ID',
                'bag_manifest_number',
                'phy_weight',
                'deps_category',
                'remarks',
                'cd_date',
                'cd_time',
                'CLOSING_KM',
                'TRIP_STATUS',
                'ARRIVAL_DATE_TIME',
                'TEMP_FLIGHT_NUMBER',
                'TEMP_TRAIN_NUMBER',
                'MANUAL_DOWNLOAD_FLAG',
                'CD_RECEIVE_DISPATCH_ID_DN'
            );
            foreach ($unknown_columns as $key => $value) {
                unset($insert_query_array[$value]);
            }
            if ($this->db->insert('dtdc_l_cd_receive', $insert_query_array)) {
                $response = array('status' => 1, 'message' => 'surelock removal success');
            } else {
                $response = array('status' => 0, 'message' => 'surelock removal failed');
            }

        } else if ($incoming_date_obj == $outgoing_date_obj) {
            $response = array('status' => 0, 'message' => 'Both dates same');

            return $response;
        } else {
            $response = array('status' => 0, 'message' => 'No records found');

            return $response;
        }

        return $response;
    }


    public function getDmcIdFromDmcTable($consgNumber) {
        $sql = "select DMC_ID from dtdc_f_dmc where RTO_CONSG_NUMBER is not null and CONSG_NUMBER = ?";
        $query = $this->db->query($sql,[$consgNumber]);
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function getweightfordoxconsignment($input)
    {
        $consgNum = isset($input['consgNum']) ? $input['consgNum'] : $this->error_response('consgNum is required');
        $logOffId = isset($input['logOffId']) ? $input['logOffId'] : $this->error_response('logOffId is required');
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        $parcel_branch_code = isset($input['parcel_branch_code']) ? $input['parcel_branch_code'] : $this->error_response('Error: parcel_branch_code is not set.');
        $product_code = isset($input['product_code']) ? $input['product_code'] : $this->error_response('Error: product_code is not set.');
        $is_parcel_branch_code = isset($input['is_parcel_branch_code']) ? $input['is_parcel_branch_code'] : $this->error_response('Error: is_parcel_branch_code is not set.');
        $isFirstRow = isset($input['isFirstRow']) ? $input['isFirstRow'] : $this->error_response('isFirstRow is required');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        if ($this->getConsignmentSavedStatusInOutgoingManifest($consgNum, $logOffId)) {
            $response = [];
            $this->error_response('The consignment already saved');
            return $response;
        }

        if($this->getDmcIdFromDmcTable($consgNum)){
            $response = [];
            $this->error_response('Please scan RTO consignment.');
            return $response;
        }

        if($this->bookingModel->getBookingIdFromConsgNumber($consgNum)){
            $response = [];
            $this->error_response('The Mother consignment is not allowed to process further. Please scan child consignments');
            return $response;
        }

        $pincode_id = '0';
        $office_id = '';
        $pincode_fun_res = $this->getPincodeForInscan($consgNum);
        if (count($pincode_fun_res) > 0) {
            $pincode_id = $pincode_fun_res['PINCODE_ID'];
            $office_id = $pincode_fun_res['OFFICE_ID'];
        }

        $office_code = $this->getOfficeCodeforInscan($office_id);

        $consignment_number_9_digit = substr($consgNum, 0, 9);

        $invoice_value = 0;
        $weight_for_dotzot = 0;
        $series_type = 'normal';
        $first_digit = substr($consignment_number_9_digit, 0, 1);

        if (strtoupper($first_digit) === 'I' || $first_digit === '7') {
            $series_type = 'dotzot';
            $sql = "SELECT invoice_value, shipment_type, weight FROM dtdc_f_spl_cust_data WHERE consg_number = ? AND consg_status = 'A' LIMIT 1";
            $query = $this->db->query($sql, [$consignment_number_9_digit]);
            $dotzot_document_id = '';
            if ($query->num_rows() > 0) {
                $shipment_type = strtolower($query->result_array()[0]['shipment_type']);
                $weight_for_dotzot = $query->result_array()[0]['weight'];
                $invoice_value = $query->result_array()[0]['invoice_value'];
                if ($shipment_type === 'dox') {
                    $dotzot_document_id = 1;
                } else {
                    $dotzot_document_id = 2;
                }
            }
        }

        $ewb_data = $this->getEWayStatusFromConsignmentNumber($consignment_number_9_digit, $logOffId);

        /*if ( $series_type === 'normal' || $invoice_value >= 50000 ) {
			$ewb_data = $this->getEWayStatusFromConsignmentNumber( $consignment_number_9_digit, $logOffId );
		} else {
			$ewb_data = [];
		}*/

        if (count($ewb_data) > 0) {
            $ewb_allow = 0;

            if ($ewb_data['EWB_STATUS'] === 'Y') {
                $ewb_allow = 1;
            }

        } else {
            $ewb_allow = 1;
            $ewb_number = null;
        }

        // $query = "select indv_weight_kgs from dtdc_f_manifest where consg_number='$consgNum' and manifest_type='I' and recv_office_id = '$logOffId'";
        //On 20 Feb 2017, Harish told me to make changes.
//        $query = "select indv_weight_kgs, document_id from dtdc_f_manifest where consg_number='$consgNum' and manifest_type='I' and recv_office_id = '$logOffId' UNION
//select ACTUAL_WEIGHT, document_id from dtdc_f_booking where consg_number='$consgNum' and BRNCH_OFF_ID = '$logOffId'";

//        $query = "select ACTUAL_WEIGHT as indv_weight_kgs, document_id from dtdc_f_booking where consg_number='$consgNum' and BRNCH_OFF_ID = '$logOffId'
//                  UNION
//                 select indv_weight_kgs, document_id from dtdc_f_manifest where consg_number='$consgNum' and manifest_type='I' and recv_office_id = '$logOffId'";
	    $query = "select ACTUAL_WEIGHT as indv_weight_kgs, document_id, ".$pincode_id." as pincode_id from dtdc_f_booking where consg_number= ? and BRNCH_OFF_ID = ?
                 UNION
                select indv_weight_kgs, document_id, DEST_PINCODE from dtdc_f_manifest where consg_number= ? and manifest_type='I' and recv_office_id = ?
                UNION
                select phy_weight, '2', ".$pincode_id." from dtdc_f_cd_recv_mnfst_dtls where bag_manifest_number= ?  and dest_office_id = ? and phy_weight>0";

	    $result = $this->db->query($query,[$consgNum,$logOffId,$consgNum,$logOffId,$consgNum,$logOffId]);

	    $modeId = $this->getModeIdForOutgoing($consgNum, $logOffId);
      $goodsDesc = $this->getGoodsDescription($consgNum);

        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();
            $indv_weight_kgs = $result_array[0]['indv_weight_kgs'];
            $document_id = $result_array[0]['document_id'];
            $pincodeIdToSend = $result_array[0]['pincode_id'];
            if (empty($pincodeIdToSend)) {
                $pincodeIdToSend = $pincode_id;
            }
            $response = array(
                'status' => 1,
                'indv_weight_kgs' => $indv_weight_kgs,
                'ewb_allow' => $ewb_allow,
                'document_id' => $document_id,
                'ewb_data' => $ewb_data,
                'mode_id' => $modeId,
                'office_code' => $office_code,
                'pincode' => $this->getPincodeFromPincodeId($pincodeIdToSend),
                'goods_desc' => $goodsDesc,
                'pincode_pb_config' => $this->getParcelBranchPincodeConfiguration($this->getPincodeFromPincodeId($pincodeIdToSend), $parcel_branch_code, $product_code, $is_parcel_branch_code, $isFirstRow,$office_code)
            );
        } else {

            if ($series_type == 'dotzot') {
                $response = [
                    'status' => 1,
                    'indv_weight_kgs' => $weight_for_dotzot,
                    'document_id' => $dotzot_document_id,
                    'ewb_allow' => $ewb_allow,
                    'ewb_data' => $ewb_data,
                    'mode_id' => $modeId,
                    'office_code' => $office_code,
                    'pincode' => $this->getPincodeFromPincodeId($pincode_id),
                    'goods_desc' => $goodsDesc,
                    'pincode_pb_config' => $this->getParcelBranchPincodeConfiguration($this->getPincodeFromPincodeId($pincode_id), $parcel_branch_code, $product_code, $is_parcel_branch_code, $isFirstRow,$office_code)
                ];
            } else {
                $response = [];
                if($this->support_model->checkBookingDataIsAvailableForOPF($consgNum)) {
                  $this->error_response('Consignment details not found in neither Booking nor Inscan');
                } else {
                  $this->error_response('Do OPF. Data not found in Booking.');
                }

            }

        }

        return $response;
    }

    public function getPincodeForInscan($consg_number)
    {
        $sql = "select PINCODE_ID, PIN_CODE,OFFICE_ID from dtdc_d_pincode where PINCODE_ID = (select DEST_PINCODE_ID from dtdc_f_booking where CONSG_NUMBER = ?) and SERVICEABLE = 'Y'";
        $query = $this->db->query($sql, [$consg_number]);
        if ($query->num_rows() > 0) {
            return $query->result_array()[0];
        } else {
            return [];
        }
    }

    public function getPincodeFromPincodeId($pincodeId)
    {
        $sql = "select PIN_CODE from dtdc_d_pincode where PINCODE_ID = ? and SERVICEABLE = 'Y'";
        $query = $this->db->query($sql, [$pincodeId]);
        if ($query->num_rows() > 0) {
            return $query->result_array()[0]['PIN_CODE'];
        } else {
            return '';
        }
    }

    public function getParcelBranchPincodeConfiguration($pincode, $parcel_branch_code, $product_code, $is_parcel_branch, $isFirstRow,$office_code)
    {
        if ($is_parcel_branch) {
            $sql1 = "select * from dtdc_d_pincode_pb_product_mapping where PARCEL_BRANCH_CODE= ?
            and  PINCODE = ? and PRODUCT = ? and RECORD_STATUS = 'A'";
            $query = $this->db->query($sql1, [$parcel_branch_code, $pincode, $product_code]);
        } else {
            $sql2 = "select * from dtdc_d_pincode_pb_product_mapping where PINCODE = ? and PRODUCT = ? and RECORD_STATUS = 'A'";
            $query = $this->db->query($sql2, [$pincode, $product_code]);
        }

        if ($query->num_rows() > 0) {
            return $query->result_array()[0];
        } else {
            return [];
        }

    }

    public function getEWayStatusFromConsignmentNumber($consignment_number, $logged_in_office_id)
    {
        $sql = "SELECT EWB_STATUS, EWB_NUMBER, DECLARED_VALUE, GST_REG_STATUS FROM  dtdc_f_ewb_info WHERE CONSG_NUMBER = ? AND TRANS_OFFICE_ID = ?";
        $query = $this->db->query($sql, [$consignment_number, $logged_in_office_id]);
        if ($query->num_rows() > 0) {
            return $query->result_array()[0];
        } else {
            return [];
        }
    }

    public function validatingsurelockpmfsticker($input)
    {
        $num = isset($input['num']) ? $input['num'] : $this->error_response('num is required');
        $logOffId = isset($input['logOffId']) ? $input['logOffId'] : $this->error_response('logOffId is required');
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $query = "SELECT RECEIVING_PLANT_ID FROM dtdc_f_goods_issue_item_detl it where it.ITEM_CODE in
('PA15','PA16','PA17','PA18','PA19','PA20','PA21','PA22','PA23','VA05','PM34','PM35','PM36','PM37','PM38','PM39','PM40','PM41',
'PM42','PM43','PM44','PM45','PM46','PM47','PM48','PM49','PM50','T010','T012','T007','T008','T009','T010','T012','T006','T013','T011','T014','PA02','T030')
and (".$this->db->escape_str($num)." BETWEEN it.START_SL_NUMBER AND  it.END_SL_NUMBER )  AND  LENGTH(it.START_SL_NUMBER) = LENGTH('".$this->db->escape_str($num)."') AND it.RECORD_STATUS='A'";
        $result = $this->db->query($query);

        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();
            $receiving_plant_id = strval($result_array[0]['RECEIVING_PLANT_ID']);
            if ($receiving_plant_id == $logOffId) {
                $response = array('status' => 1, 'message' => 'Success');
            } else {
                $response = array('status' => 0, 'message' => 'Failed to validate surelock');
            }
        } else {
            $this->error_response('Records not found');
        }

        return $response;
    }

    public function get_desc_goods($input)
    {
        $cnsgNum = isset($input['cnsgNum']) ? $input['cnsgNum'] : $this->error_response('cnsgNum is required');
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        $is_rto = isset($input['is_rto']) ? $input['is_rto'] : $this->error_response('Error: is_rto is not set.');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
        $is_rto = false;
        if ($is_rto) {
            $sql = "select booking_id, booking_number, description, desc_goods, remarks from dtdc_f_booking where consg_number = '".$this->db->escape_str($cnsgNum)."' or rto_consg_number = '".$this->db->escape_str($cnsgNum)."'";
        } else {
            $sql = "select booking_id, booking_number, description, desc_goods, remarks from dtdc_f_booking where consg_number = '".$this->db->escape_str($cnsgNum)."'";
        }
        $query = $this->db->query($sql);
        if ($query->num_rows() > 0) {
            $result_array = $query->result_array()[0];

            return $response = array('status' => 1, 'result' => $result_array);
        } else {
            if ($is_rto) {
                $rto_consg_number = $this->get_consg_num_for_rto($cnsgNum);
                if ($rto_consg_number) {
                    $sql_rto = "select booking_id, booking_number, description, desc_goods, remarks from dtdc_f_booking where consg_number = ? or rto_consg_number = ? ";
                    $query_rto = $this->db->query($sql_rto,[$rto_consg_number,$rto_consg_number]);
                    if ($query_rto->num_rows() > 0) {
                        $result_array_rto = $query_rto->result_array()[0];

                        return $response = array('status' => 1, 'result' => $result_array_rto);
                    }
                }
            }

            return $response = array('status' => 0, 'message' => 'No records found');
        }
    }

    public function getGoodsDescription($cnsgNum) {

        $first_four_digit = substr($cnsgNum,0,4);
        $is_rto = false;
        if($first_four_digit == '0000') {
          $is_rto = true;
        }

        if ($is_rto) {
            $sql = "select booking_id, booking_number, description, desc_goods, commodity_id, remarks from dtdc_f_booking where consg_number = '".$this->db->escape_str($cnsgNum)."' or rto_consg_number = '".$this->db->escape_str($cnsgNum)."'";
        } else {
            $sql = "select booking_id, booking_number, description, desc_goods, commodity_id, remarks from dtdc_f_booking where consg_number = '".$this->db->escape_str($cnsgNum)."'";
        }
        $query = $this->db->query($sql);
        if ($query->num_rows() > 0) {
            $result_array = $query->result_array()[0];
            $goodsDescValue = $this->getTheGoodsDescValueFromCommodityId($result_array['commodity_id']);
            return $goodsDescValue;
        } else {
            if ($is_rto) {
                $rto_consg_number = $this->get_consg_num_for_rto($cnsgNum);
                if ($rto_consg_number) {
                    $sql_rto = "select booking_id, booking_number, description, desc_goods, commodity_id, remarks from dtdc_f_booking where consg_number = ? or rto_consg_number = ? ";
                    $query_rto = $this->db->query($sql_rto,[$rto_consg_number,$rto_consg_number]);
                    if ($query_rto->num_rows() > 0) {
                        $result_array_rto = $query_rto->result_array()[0];
                        $goodsDescValueRTO = $this->getTheGoodsDescValueFromCommodityId($result_array_rto['commodity_id']);
                        return $goodsDescValueRTO;
                    }
                }
            }

            return '';
        }
    }

    public function getTheGoodsDescValueFromCommodityId($commodityId) {

        $sql = " select COMMODITY_NAME from dtdc_d_commodity where commodity_id = ?;";
        $query = $this->db->query($sql, array($commodityId));
        if ($query->num_rows() > 0) {
            return $query->result_array()[0]['COMMODITY_NAME'];
        } else {
            return '';
        }
    }


    public function get_consg_num_for_rto($consg_number)
    {
        $sql = "SELECT desc_goods FROM dtdc_f_booking WHERE consg_number = (SELECT CONSG_NUMBER FROM DTDC_F_DMC WHERE RTO_CONSG_NUMBER = ?)";
        $query = $this->db->query($sql, array($consg_number));
        if ($query->num_rows() > 0) {
            return $query->result_array()[0]['desc_goods'];
        } else {
            return false;
        }
    }

    public function get_dispatch_number($input)
    {

        $office_id = isset($input['office_id']) ? $input['office_id'] : $this->error_response('Error: office_id is not set.');
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $random_number = $this->generate_random_dispatch_number($office_id);

        $response = array('status' => 1, 'dispatch_number' => $random_number);

        return $response;
    }

    public function generate_random_dispatch_number($office_id)
    {
        $mt_rand = mt_rand(1, 999999);
        $formatted_rand = sprintf('%06d', $mt_rand);
        $dispatch_number = $office_id . $formatted_rand;
        if ($this->check_dispatch_number_in_db($dispatch_number)) {
            return $dispatch_number;
        } else {
            $this->generate_random_dispatch_number($office_id);
        }
    }

    public function check_dispatch_number_in_db($dispatch_number)
    {
        $sql = "select count(dispatch_number) as total_number from dtdc_f_dispatch where dispatch_number = ? ";
        $query = $this->db->query($sql,[$dispatch_number]);
        if ($query->num_rows() > 0) {
            $result_array = $query->result_array();
            $total_number = $result_array[0]['total_number'];
            if ($total_number == 0) {
                return true;
            } else {
                return false;
            }
        } else {
            //Exit loop incase of failed query to prevent infinite loop
            return true;
        }
    }

    public function mastercondispatchvalidatecdno($input)
    {
        $loader_id = isset($input['loaderId']) ? $input['loaderId'] : $this->error_response('loaderId is required');
        $cd_number = isset($input['cdNumber']) ? $input['cdNumber'] : $this->error_response('cdNumber is required');
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $sql = "SELECT * FROM dtdc_f_disp_bag_mnfst_dtls WHERE LOADER_ID = ? AND CD_LT_RR_NUMBER = ?";
        $query = $this->db->query($sql, array($loader_id, $cd_number));
        if ($query->num_rows() > 0) {
            return $response = array('status' => 0, 'message' => 'duplicate');
        } else {
            return $response = array('status' => 1, 'message' => 'allow');
        }
    }

    public function getCoLoaders($logged_in_office_id, $mode_id)
    {
        $sql = "SELECT DISTINCT c.LOADER_ID, c.LOADER_CODE, c.LOADER_NAME,
            t.TRNST_TIME_ID FROM dtdc_d_trns_time t, dtdc_d_coloader c WHERE t.route_id IN
            ( SELECT route_id FROM dtdc_d_route WHERE orig_office_id = ?
            AND cur_status= 'A') AND mode_id = ?
            AND c.LOADER_ID = t.CO_LOADER_ID AND t.CUR_STATUS= 'A'";

        $query = $this->db->query($sql, array($logged_in_office_id, $mode_id));
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return [];
        }
    }

    public function validateSureLockNumber($manifest_number, $logged_in_office_id)
    {
        $sql1 = "select manifest_id from dtdc_f_manifest where manifest_number = ? and manifest_type='O'";
        $query1 = $this->db->query($sql1, [$manifest_number]);
        if ($query1->num_rows() > 0) {
            return 2;
        }
        $sql = "select
      goodsissue0_.GOODS_ISSUE_ITEM_DETL_ID as col_0_0_
  	from
      dtdc_f_goods_issue_item_detl goodsissue0_,
      dtdc_f_goods_issue goodsissue1_
  where
      goodsissue0_.GOODS_ISSUE_ID=goodsissue1_.GOODS_ISSUE_ID
      and (
           ? between goodsissue0_.START_SL_NUMBER and goodsissue0_.END_SL_NUMBER
      )
      and    goodsissue0_.RECORD_STATUS='A'
      and goodsissue1_.RECEIVING_PLANT_ID= ?
      and goodsissue1_.ISSUE_DOCUMENT_DATE <= ?";

        $query = $this->db->query($sql, [$manifest_number, $logged_in_office_id, $this->server_date]);

        return ($query->num_rows() > 0) ? 1 : 0;

    }

    public function getWeightForConsgNumber($consg_number)
    {
        $sql = "select actual_weight from dtdc_f_dmc where  rto_consg_number = ? and actual_weight <> '0';";
        $query = $this->db->query($sql, [$consg_number]);
        if ($query->num_rows() > 0) {
            return $query->result_array()[0]['actual_weight'];
        } else {
            return 0.0;
        }
    }

    public function checkBranchIsParcelBranch($branch_code)
    {
        $sql = "select * from
				dtdc_d_pincode_pb_product_mapping where PARCEL_BRANCH_CODE = ? and RECORD_STATUS = 'A'";
        $query = $this->db->query($sql, [$branch_code]);
        return ($query->num_rows() > 0) ? $query->result_array()[0] : [];
    }

    public function error_response($e)
    {
        $response = array('status' => 0, 'message' => $e);
        echo json_encode($response);
        exit;
    }

    public function getDirectConnection($logged_in_office_id, $report_office_id)
    {
        $sql = "select VENDOR_ID, VENDOR_CODE, BUSINESS_NAME from dtdc_d_vendor where VENDOR_TYPE = 'D' and OFFICE_ID in (?, ?) and CUR_STATUS = 'A'";

        $query = $this->db->query($sql, array($logged_in_office_id, $report_office_id));
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return [];
        }
    }

    public function getTheOtcs($origin_office_id)
    {
        $sql = "select DISTINCT c.OTC_ID, c.OTC_CODE, c.PRIVATE_OTC_NAME from dtdc_d_otc_master c, dtdc_d_trns_time t
where t.TRNST_TIME_ID in(select ROUTE_ID from dtdc_d_route where ORIG_OFFICE_ID  = ? and CUR_STATUS = 'A')
and c.OTC_CODE = t.trnst_code and t.CUR_STATUS = 'A'";

        $query = $this->db->query($sql, array($origin_office_id));
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return [];
        }
    }

    public function getConsignmentSavedStatusInOutgoingManifest($consg_number, $originBranchId)
    {
        $sql = "select MANIFEST_ID from dtdc_f_manifest where consg_number = ? and ORIG_BRNCH_ID = ? and MANIFEST_TYPE = 'O';";
        $query = $this->db->query($sql, [$consg_number, $originBranchId]);
        return ($query->num_rows() > 0);
    }

    public function getOfficeCodeforInscan($office_id)
    {
        $sql = "select OFFICE_CODE from dtdc_d_office where OFFICE_ID = ?";
        $query = $this->db->query($sql, [$office_id]);
        if ($query->num_rows() > 0) {
            return $query->result_array()[0]['OFFICE_CODE'];
        } else {
            return '';
        }
    }


    public function automateConsolidatedEwbNumber($transaction_uid, $ewb_details,$nodeId,$warDate) {

        $mc_ids = [];

        foreach($ewb_details as $ewb_detail) {
            $manifest_number = $ewb_detail['manifestNumber'];
            if(!$this->checkManifestIsSaved($manifest_number)){
                $insert_data = array(
                    'TRANSACTION_UID' => $transaction_uid,
                    'MANIFEST_NO' => $ewb_detail['manifestNumber'],
                    'EWB_NUMBER' => $ewb_detail['ewbNumber'],
                    'VEHICLE_NO' => $ewb_detail['vehicleNumber'],
                    'CONSG_NUMBER' => $ewb_detail['consgNumber'],
                    'CD_LT_RR_NUMBER' => $ewb_detail['cdNumber'],
                    'TRANSACTION_DATE' => $this->server_date_time,
                    'NODE_ID' => $nodeId,
                    'WAR_DATE' => $warDate
                );
                $this->db->insert('dtdc_f_manifest_consolidate', $insert_data);
                $insert_id = $this->db->insert_id();
                array_push($mc_ids,$insert_id);
            }
        }

        return $mc_ids;

    }

    public function checkManifestIsSaved($manifest_number){
        $sql = "select MC_ID from dtdc_f_manifest_consolidate where MANIFEST_NO = ?";
        $query = $this->db->query($sql,[$manifest_number]);
        if($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function getConsolidateEwbNumberFromTransactionUid($transaction_uid) {
        $sql = "select CONSOLIDATE_EWB_NO from dtdc_f_manifest_consolidate where TRANSACTION_UID = ?";
        $query = $this->db->query($sql,[$transaction_uid]);
        if($query->num_rows() > 0) {
            return $query->result_array()[0]['CONSOLIDATE_EWB_NO'];
        } else {
            return null;
        }
    }

	public function getModeIdForOutgoing($consgNumber, $officeId) {
    	$sql = "select SERVICE_ID, CASE WHEN SERVICE_ID IN (12,13,29,30,31,32,33,61,75,95,96,97,98,103,139,193) THEN (SELECT '1') ELSE (SELECT mode_id)END mode_id from dtdc_d_srv_mode_relation where service_id = (select service_id from dtdc_f_booking where CONSG_NUMBER = ? )
                UNION
                select ''SERVICE_ID, mode_id from dtdc_f_manifest where consg_number = ?  and manifest_type='I' and recv_office_id = ?
                UNION
                select ''SERVICE_ID, mode_id from dtdc_f_cd_recv_mnfst_dtls where bag_manifest_number= ? and dest_office_id = ? and phy_weight>0";
    	$query = $this->db->query($sql,[$consgNumber, $consgNumber, $officeId, $consgNumber, $officeId]);
    	if($query->num_rows() > 0) {
    		return $query->result_array()[0]['mode_id'];
	    } else {
    		return 1;
	    }
    }

    public function bagManifestValidationForDox($input){

        $consg_number =  $input['consg_number'];
        $origin_branch_id = $input['origin_branch_id'];
        // $sql = "SELECT CONSG_NUMBER as MFNO FROM DTDC_F_MANIFEST WHERE CONSG_NUMBER= ?  AND MANIFEST_TYPE='I' AND DEST_BRNCH_ID= ? AND MNFST_TYPE_ID=5
        //         UNION
        //         SELECT distinct(MANIFEST_NUMBER) as MFNO FROM DTDC_F_MANIFEST WHERE MANIFEST_NUMBER = ?  AND MANIFEST_TYPE='O' AND ORIG_BRNCH_ID=  ?  AND MNFST_TYPE_ID=3";
        
        // $sql = "SELECT CONSG_NUMBER as MFNO,
        //         CASE WHEN TOT_WEIGHT_KGS=0 THEN (
        //         SELECT INDV_WEIGHT_KGS FROM dtdc_f_manifest WHERE CONSG_NUMBER= ? OR MANIFEST_NUMBER = ?
        //         AND MANIFEST_TYPE='O'  LIMIT 1)
        //         ELSE (SELECT '1') END WT,
        //         MODE_ID MDE ,IFNULL(PRODUCT_ID,'1') PRODUCT_ID,DEST_BRNCH_ID,
        //         CASE WHEN TOT_CONSG_NUM =0 THEN (
        //         SELECT TOT_CONSG_NUM FROM dtdc_f_manifest WHERE CONSG_NUMBER= ? OR MANIFEST_NUMBER = ?
        //         AND MANIFEST_TYPE='O'  LIMIT 1)
        //         ELSE (SELECT '0') END
        //         TOT_CONSG_NUM
        //         FROM DTDC_F_MANIFEST WHERE CONSG_NUMBER= ?
        //         AND MANIFEST_TYPE='I' AND DEST_BRNCH_ID= ? AND MNFST_TYPE_ID=5
        //         UNION
        //         SELECT distinct(MANIFEST_NUMBER) as MFNO, TOT_WEIGHT_KGS AS WT,MODE_ID MDE ,IFNULL(PRODUCT_ID,'1') PRODUCT_ID,DEST_BRNCH_ID,
        //         TOT_CONSG_NUM
        //         FROM DTDC_F_MANIFEST
        //         WHERE MANIFEST_NUMBER = ? AND MANIFEST_TYPE='O'
        //         AND ORIG_BRNCH_ID= ? AND MNFST_TYPE_ID=3";


$sql = "SELECT CONSG_NUMBER as MFNO,
CASE WHEN TOT_WEIGHT_KGS=0 THEN (
SELECT INDV_WEIGHT_KGS FROM dtdc_f_manifest WHERE CONSG_NUMBER= ? OR MANIFEST_NUMBER = ?
AND MANIFEST_TYPE='O'  LIMIT 1)
ELSE (SELECT '1') END WT,
MODE_ID MDE ,IFNULL(PRODUCT_ID,'1') PRODUCT_ID,
CASE WHEN DEST_BRNCH_ID is not null THEN (
SELECT DEST_BRNCH_ID FROM dtdc_f_manifest WHERE CONSG_NUMBER= ? OR MANIFEST_NUMBER = ?
AND MANIFEST_TYPE='O'  LIMIT 1)
 END DEST_BRNCH_ID,
CASE WHEN TOT_CONSG_NUM =0 THEN (
SELECT TOT_CONSG_NUM FROM dtdc_f_manifest WHERE CONSG_NUMBER= ? OR MANIFEST_NUMBER = ?
AND MANIFEST_TYPE='O'  LIMIT 1)
ELSE (SELECT '0') END
TOT_CONSG_NUM,

CASE WHEN consg_number is not null THEN (
SELECT ORIG_BRNCH_ID FROM dtdc_f_manifest WHERE CONSG_NUMBER= ? OR MANIFEST_NUMBER = ? 
AND MANIFEST_TYPE='O'  LIMIT 1)
ELSE (SELECT '0') END
ORIG_BRNCH_ID

FROM DTDC_F_MANIFEST WHERE CONSG_NUMBER= ?
AND MANIFEST_TYPE='I' AND DEST_BRNCH_ID= ? AND MNFST_TYPE_ID=5
UNION
SELECT distinct(MANIFEST_NUMBER) as MFNO, TOT_WEIGHT_KGS AS WT,MODE_ID MDE ,IFNULL(PRODUCT_ID,'1') PRODUCT_ID,DEST_BRNCH_ID,
TOT_CONSG_NUM,ORIG_BRNCH_ID
FROM DTDC_F_MANIFEST
WHERE MANIFEST_NUMBER = ? AND MANIFEST_TYPE='O'
AND ORIG_BRNCH_ID= ? AND MNFST_TYPE_ID IN (3,8,4)";

$query = $this->db->query($sql,[$consg_number,$consg_number, $consg_number, $consg_number, $consg_number, $consg_number, $consg_number, $consg_number, $consg_number, $origin_branch_id, $consg_number, $origin_branch_id]);
        $result = $query->result_array();

        if($result){

            $sql1 = "SELECT DATE_FORMAT(MANIFEST_DATE,'%d-%m-%Y') as DT,office_code  FROM DTDC_F_MANIFEST,dtdc_d_office WHERE CONSG_NUMBER= ?  AND MANIFEST_TYPE='O' AND ORIG_BRNCH_ID= ? AND MNFST_TYPE_ID=5
                    and dest_brnch_id=office_id order by manifest_date desc LIMIT 1";
            $query1 = $this->db->query($sql1,[$consg_number, $origin_branch_id]);
            $result1 =  $query1->result_array();
            if($result1) {
                $branch_code = $result1[0]['office_code'];
                $date = $result1[0]['DT'];
                return  $response = [
                                        'status' => 0,
                                        'message' => 'The Packet Manifest is already dispatched on '. $date . ' to Branch ' .$branch_code,
                                        'data' => null                                  
                                    ];
               
            }
            return $response = [
                                'status' => 1,
                                'message' => 'Proceed further',
                                'data'=> $result
                            ];
        }

        $response = [
                    'status' => 0,
                    'message' => 'Entered Manifest number is either not Prepared Or not Inscaned',
                    'data' => null
                    ];
        return  $response;
        
    }

}
