<?php

Class Employee_model extends CI_model {


  public function __construct(){
    // $this->load->database();
  }

  public function get_employee_details($username){
    $employee_details = array();

    $query = "select emp.EMPLOYEE_ID,CONCAT(emp.FIRST_NAME,' ',emp.LAST_NAME) as NAME,emp.OFFICE_ID, emp.DEPARTMENT_CODE, off.OFFICE_NAME,off.REPORT_REGOFF_ID,off.OFFICE_CODE,off.OFF_TYPE from dtdc_d_employee emp,dtdc_d_office off where emp.OFFICE_ID=off.OFFICE_ID and emp.EMP_CODE='".$this->db->escape_str($username)."'";
    $result = $this->db->query($query);
    if($result->num_rows()>0){
      $result_array = $result->result_array();
      $employee_details = $result_array[0];
    }

    return $employee_details;
  }

  public function get_all_employees($loggedInOfficeId){
    $all_employees = array();

    $query = "select e.EMP_CODE, e.FIRST_NAME, e.EMPLOYEE_ID, u.USER_ID from dtdc_d_employee e inner join cg_d_user u on e.EMP_CODE = u.USER_CODE WHERE e.OFFICE_ID = ? AND e.RECORD_STATUS='A'";

    $result = $this->db->query($query,[$loggedInOfficeId]);
    if($result->num_rows()>0){
      $result_array = $result->result_array();
      $all_employees = $result_array;
    }

    return $all_employees;
  }
}
