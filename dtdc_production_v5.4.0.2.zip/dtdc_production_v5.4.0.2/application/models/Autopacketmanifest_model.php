<?php

/**
 *
 */
class Autopacketmanifest_model extends CI_model
{
  public $branchCode;
  public $firstLetter;
  public $csc_id;
  public $cn_start_no;
  public $cn_end_no;
  public $csc_stock_no;

  public $response;

  function __construct()
  {
    # code...
    // $this->load->database();
  }

  public function generate($input){
    $branchCode = $this->branchCode = isset($input['branchCode']) ? $input['branchCode'] : $this->error_response('Please send branch code as branchCode');
    $firstLetter = $this->firstLetter = isset($input['firstLetter']) ? $input['firstLetter'] : $this->error_response('Please send first letter as firstLetter');
    $central = isset($input['central']) ? $input['central'] : $this->error_response('central is required');

    $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
    if($local_db_ip != 'null'){
      $connect = new Connection_model();
      $connect->custom($local_db_ip);
    }else{
      $connect = new Connection_model();
      $connect->central();
    }

	  if($central == 'true'){
		  $query = "select CSC_ID,CSC_STOCK, CSC_START_CNNO,CSC_END_CNNO from dtdc_f_cn_stock_ctrl where CSC_BRANCH_CODE='".$this->db->escape_str($branchCode)."' and CSC_CUST_CODE = '".$this->db->escape_str($branchCode)."' and CSC_START_CNNO like '".$this->db->escape_like_str($firstLetter)."%' and CSC_ONLINE_USE  = 1 and STATUS = 'A' and CSC_STOCK > 0 order by CSC_STOCK DESC LIMIT 1";
	  }else {
		  $query = "select CSC_ID,CSC_STOCK, CSC_START_CNNO,CSC_END_CNNO from dtdc_f_cn_stock_ctrl where CSC_BRANCH_CODE='".$this->db->escape_str($branchCode)."' and CSC_CUST_CODE = '".$this->db->escape_str($branchCode)."' and CSC_START_CNNO like '".$this->db->escape_like_str($firstLetter)."%' and CSC_ONLINE_USE  = 0 and STATUS = 'A' and CSC_STOCK > 0 order by CSC_STOCK DESC LIMIT 1";
	  }

    // echo $query;
    $result = $this->db->query($query);
    if($result->num_rows() >0){
      $result_array = $result->result_array();

      //Get the CSC details from DB
      $this->csc_id = $result_array[0]['CSC_ID'];
      $this->cn_start_no = $result_array[0]['CSC_START_CNNO'];
      $this->cn_end_no = $result_array[0]['CSC_END_CNNO'];
      $this->csc_stock_no = $result_array[0]['CSC_STOCK'];

      //Get the start letter to later send with response.
      $startLetter = $this->cn_start_no[0];
      // echo 'start letter is '.$startLetter.'<br>';
      // echo 'CSC start no :'.$this->cn_start_no.'<br>';
      // echo 'CSC end no :' .$this->cn_end_no.'<br>';
      // echo 'Original CSC stock no :'.$this->csc_stock_no.'<br>';
      if(($this->csc_stock_no > 0) && (strlen($this->cn_start_no) == 8) && (strlen($this->cn_end_no) == 8)):
        //Get the numeric from the alpha_numeric CSC number.
        $numeric_cn_start_no = $this->strip_first_letter($this->cn_start_no);
        $numeric_cn_end_no = $this->strip_first_letter($this->cn_end_no);
        //Find the diff
        $diff_cn_no = ($numeric_cn_end_no - $numeric_cn_start_no);
        //Increment the number
        $diff_cn_no++;
        //Find the difference in stock
        $diff_stock_no = ($diff_cn_no - $this->csc_stock_no);
        //Decrement the stock number
        $decremented_stock_number = --$this->csc_stock_no;
        // Update the decremented stock number in database
        $update_status = $this->update_decremented_stock_number($decremented_stock_number);
        // Create the final stock response.

        $tmp_stock_number = $numeric_cn_start_no +$diff_stock_no;
        $formatted_stock_number = sprintf('%07d', $tmp_stock_number);
        $final_stock = $startLetter. $formatted_stock_number;
        if($update_status){

            $this->response = array('status'=>1,'finalStock'=>$final_stock);
        }else{
            $this->response = array('status'=>1,'finalStock'=>$final_stock,'message'=>'Failed to update stock');
        }

        elseif(($this->csc_stock_no > 0) && (strlen($this->cn_start_no) == 11) && (strlen($this->cn_end_no) == 11)):
	        $numeric_cn_start_no = $this->strip_first_letter($this->cn_start_no);
	        $numeric_cn_end_no = $this->strip_first_letter($this->cn_end_no);
	        //Find the diff
	        $diff_cn_no = ($numeric_cn_end_no - $numeric_cn_start_no);
	        //Increment the number
	        $diff_cn_no++;
	        //Find the difference in stock
	        $diff_stock_no = ($diff_cn_no - $this->csc_stock_no);
	        //Decrement the stock number
	        $decremented_stock_number = --$this->csc_stock_no;
	        // Update the decremented stock number in database
	        $update_status = $this->update_decremented_stock_number($decremented_stock_number);
	        // Create the final stock response.

	        $tmp_stock_number = $numeric_cn_start_no +$diff_stock_no;
	        $formatted_stock_number = sprintf('%010d', $tmp_stock_number);
	        $final_stock = $startLetter. $formatted_stock_number;
	        if($update_status){

		        $this->response = array('status'=>1,'finalStock'=>$final_stock);
	        }else{
		        $this->response = array('status'=>1,'finalStock'=>$final_stock,'message'=>'Failed to update stock');
	        }

      else:
          $this->error_response('System could not find virtual series allocation');
      endif;
    }else{
      $this->response = array('status'=>0,'message'=>'Stock not found');
    }
    return $this->response;
  }

  public function strip_first_letter($alpha_numeric){
    return $numeric = filter_var($alpha_numeric,FILTER_SANITIZE_NUMBER_INT);
  }

  public function update_decremented_stock_number($decremented_stock_number){
    $query = "update dtdc_f_cn_stock_ctrl set CSC_STOCK = '".$this->db->escape_str($decremented_stock_number)."' where csc_id = '".$this->db->escape_str($this->csc_id)."'";
    if($this->db->query($query)){
      return true;
    }else{
      return false;
    }
  }

  public function error_response($e){
    $response = array('status'=>0,'message'=>$e);
    echo json_encode($response);
    exit;
  }
}
