<?php

defined('BASEPATH') OR exit('No direct script access allowed');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require APPPATH.'libraries/phpmailer/phpmailer/src/Exception.php';
require APPPATH. 'libraries/phpmailer/phpmailer/src/PHPMailer.php';
require APPPATH. 'libraries/phpmailer/phpmailer/src/SMTP.php';


class Incoming_model extends CI_Model
{

    public $date;
    public $time;
    public $server_date_time;
    public $date_obj;
    

    //user details
    public $currentLoginInfo = array();

    protected $originOfficeIdForHeaderTable;


    function __construct()
    {
        # code...
        parent::__construct();
        $dateObj = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
        $this->date = $dateObj->format('Y-m-d');
        $this->time = $dateObj->format('H:i');
        $this->server_date_time = $dateObj->format('Y-m-d H:i:s');
        $this->date_obj = $dateObj;
        $this->originOfficeIdForHeaderTable = null;
    }

    public function savemastercon($input)
    {
        $consignment_numbers_unique = [];
        $arrival_date = $this->date;
        $arrival_time = $this->time;
        $load_receive_date = $this->date;
        $load_receive_time = $this->time;
        $save_response = array();
        $duplicate_response = array();
        $vehicle_response = array();

        $CI =& get_instance();
        $CI->load->model('User_model');

        foreach ($input as $key => $value) {
            try {
                if (empty($value) && ($value != "0")) {
                    throw new Exception("Error Processing Request " . $key . " is required!", 1);
                }
            } catch (Exception $e) {
                $this->error_response($e->getMessage());
            }
        }

        $userId = isset($input['userId']) ? $input['userId'] : $this->error_response('Error: userId is not set.');
        $employeeId = isset($input['employeeId']) ? $input['employeeId'] : $this->error_response('Error: employeeId is not set.');
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $nodeId = isset($input['nodeId']) ? $input['nodeId'] : $this->error_response('Error: nodeId is not set.');
        $officeCode = isset($input['officeCode']) ? $input['officeCode'] : $this->error_response('Error: officeCode is not set.');
        $user_in_apex = isset($input['userInApex']) ? $input['userInApex'] : $this->error_response('Error: userInApex is not set.');
        $destinationId = isset($input['loggedInOfficeId']) ? $input['loggedInOfficeId'] : $this->error_response('Error: loggedInOfficeId is not set.');
        $destinationOfficeType = $this->_get_office_type_from_dtdc_d_office($destinationId);
        $transactionTime = isset($input['transactionTime']) ? $input['transactionTime'] : $this->error_response('Error: transactionTime is not set.');
        $transactionDate = isset($input['transactionDate']) ? $input['transactionDate'] : $this->error_response('Error: transactionDate is not set.');
        $lastTransaction = $transactionDate . " " . $transactionTime;
        $masterConVehicles = isset($input['masterConVehicles']) ? $input['masterConVehicles'] : $this->error_response('Error: masterConVehicles is not set.');

        for ($i = 0; $i < count($masterConVehicles); $i++) {

            foreach ($masterConVehicles[$i] as $key => $value) {
                try {
                    if (empty($value) && ($value != "0")) {
                        throw new Exception("Error Processing Request " . $key . " is required!", 1);
                    }
                } catch (Exception $e) {
                    $this->error_response($e->getMessage());
                }
            }

            $modeId = isset($masterConVehicles[$i]['modeId']) ? $masterConVehicles[$i]['modeId'] : $this->error_response('Error: modeId is not set.');
            $vehicleNumber = isset($masterConVehicles[$i]['vehicleNumber']) ? $masterConVehicles[$i]['vehicleNumber'] : $this->error_response('Error: vehicleNumber is not set.');
            $vehicleId = isset($masterConVehicles[$i]['vehicleId']) ? $masterConVehicles[$i]['vehicleId'] : $this->error_response('Error: vehicleId is not set.');
            $vehicleType = isset($masterConVehicles[$i]['vehicleType']) ? $masterConVehicles[$i]['vehicleType'] : $this->error_response('Error: vehicleType is not set.');
            $closingKm = isset($masterConVehicles[$i]['closingKm']) ? $masterConVehicles[$i]['closingKm'] : $this->error_response('Key error: closingKm is not set.');

            if ($vehicleType == "1") {
                switch ($modeId) {
                    case '1':
                        $vehicle_column = "AIRPORT_ID";

                        //Store the sent flight number
                        $flight_number = $vehicleId;


                        //Find the airport_id of the flight_number from the db

                        $airport_id_sql = "select airport_id from dtdc_d_airport where AIRLINE_NUMBER = ?";

                        $airport_id_query = $this->db->query($airport_id_sql, [$flight_number]);

                        if ($airport_id_query->num_rows() > 0) {

                            $airport_id = $airport_id_query->result_array()[0]['airport_id'];

                        } else {

                            $airport_id = null;
                        }

                        //
                        $column_value = $airport_id;
                        break;
                    case '10':
                        $vehicle_column = 'TRAIN_ID';
                        $column_value = (int)$vehicleId;
                        break;
                    case '2':
                        //Based on observation on 22march 2017, we found our the vehicle_number
                        //colum not there in db, so since there are duplicate data for vehicle_number and
                        //cannot reliably get vehicle_id, we are storing vehicle_number in temp_vehicle_code column
                        $vehicle_column = "VEHICLE_ID";
                        $column_value = null;
                        // $vehicle_column = "TEMP_VEHICAL_CODE";
                        // $column_value = $vehicleNumber;
                        break;
                    default:
                        $vehicle_column = "VEHICLE_ID";
                        $column_value = null;
                        // $vehicle_column = "TEMP_VEHICAL_CODE";
                        // $column_value = $vehicleNumber;
                        break;
                }
            }

            if ($vehicleType == '0') {
                switch ($modeId) {
                    case '1':
                        $vehicle_column = "TEMP_FLIGHT_NUMBER";
                        $column_value = $vehicleNumber;
                        break;
                    case '10':
                        $vehicle_column = 'TEMP_TRAIN_NUMBER';
                        $column_value = $vehicleNumber;
                        break;
                    case '2':
                        $vehicle_column = "TEMP_VEHICAL_CODE";
                        $column_value = $vehicleNumber;
                        break;
                    default:
                        $vehicle_column = "TEMP_VEHICAL_CODE";
                        $column_value = $vehicleNumber;
                        break;
                }
            }
            $db_server = 'N';
            if ($modeId == 2) {
                $TEMP_VEHICAL_NAME = $vehicleNumber;
            } else {
                $TEMP_VEHICAL_NAME = null;
            }


//            //12 May 2017, getting origin office id in header table
//            $shipments = $masterConVehicles[$i]['shipments'];
//            for ($j = 0; $j < count($shipments); $j++) {
//                $bagManifest = isset($shipments[$j]['bagManifest']) ? $shipments[$j]['bagManifest'] : $this->error_response('Error: bagManifest is not set.');
//
//
//            }


            $insert_data = array(
                'ARRIVAL_DATE' => $arrival_date,
                'ARRIVAL_TIME' => $arrival_time,
                'LOAD_RECV_DATE' => $load_receive_date,
                'LOAD_RECV_TIME' => $load_receive_time,
                $vehicle_column => $column_value,
                'RECIEVER_EMP_ID' => $employeeId,
                'TEMP_VEHICAL_NAME' => $TEMP_VEHICAL_NAME,
                'DB_SERVER' => $db_server,
                'TRANS_CREATE_DATE' => $lastTransaction,
                'TRANS_LAST_MODIFIED_DATE' => $lastTransaction,
                'USER_ID' => $userId,
                'DEST_OFFICE_ID' => $destinationId,
                'DEST_OFFICE_TYPE' => $destinationOfficeType,
                'MODE_ID' => $modeId,
                'NODE_ID' => $nodeId,
                'CLOSING_KM' => $closingKm,
                'EMPLOYEE_ID' => $employeeId
            );


            $this->db->insert('dtdc_f_cd_receive', $insert_data);
            $last_cd_receive_dispatch_id = $this->db->insert_id();

            $shipments = $masterConVehicles[$i]['shipments'];


            for ($j = 0; $j < count($shipments); $j++) {

                foreach ($shipments[$j] as $key => $value) {
                    try {
                        if (empty($value) && ($value != "0")) {
                            throw new Exception("Error Processing Request " . $key . " is required!", 1);
                        }
                    } catch (Exception $e) {
                        $this->error_response($e->getMessage());
                    }
                }

                $bagManifest = isset($shipments[$j]['bagManifest']) ? $shipments[$j]['bagManifest'] : $this->error_response('Error: bagManifest is not set.');
                $depsId = isset($shipments[$j]['depsId']) ? $shipments[$j]['depsId'] : $this->error_response('Error: depsId is not set.');
                $depsRemarks = isset($shipments[$j]['depsRemarks']) ? $shipments[$j]['depsRemarks'] : $this->error_response('Error: depsRemakrs is not set.');
                $bagCaptureTime = isset($shipments[$j]['bagCaptureTime']) ? $shipments[$j]['bagCaptureTime'] : $this->error_response('Error: bagCaptureTime is not set.');
                $bagCaptureDate = isset($shipments[$j]['bagCaptureDate']) ? $shipments[$j]['bagCaptureDate'] : $this->error_response('Error: bagCaptureDate is not set.');
                $phyWeight = isset($shipments[$j]['phyWeight']) ? $shipments[$j]['phyWeight'] : $this->error_response('Error: phyWeight is not set.');
                $isBooked = $shipments[$j]['isBooked'];

                $cd_details = $this->getOutboundRecordStatusOfConsignment($bagManifest, $destinationId);

                $cd_number = $cd_details['CD_LT_RR_NUMBER'];
                $loader_id = $cd_details['LOADER_ID'];
                $vendor_id = $cd_details['VENDOR_ID'];
                $originOfficeId = $cd_details['ORIGIN_OFFICE_ID'];
                if($originOfficeId == null){
                    $originOfficeId = $destinationId;
                }

                //$originOfficeId = $this->get_origin_office_id_from_dtdc_f_disp_bag_mnfst_dtls($bagManifest, $destinationId);

                if (!$this->originOfficeIdForHeaderTable && ($originOfficeId != null)) {
                    $this->originOfficeIdForHeaderTable = $originOfficeId;
                    $sql = "update dtdc_f_cd_receive set  ORIGIN_OFFICE_ID = ? where CD_RECEIVE_DISPATCH_ID = ?";
                    $this->db->query($sql, array($originOfficeId, $last_cd_receive_dispatch_id));
                }
                if ($originOfficeId) {
                    $originOfficeType = $this->_get_office_type_from_dtdc_d_office($originOfficeId);
                } else {
                    $originOfficeType = null;
                }

                if (($user_in_apex === 1) && $this->checkWvcFlagForManifestNumber($bagManifest)) {
                    $consignment_numbers_unique = $this->getConsignmentNumbersFromManifest($bagManifest);
                    foreach ($consignment_numbers_unique as $key => $value) {
                        if (!$this->checkEwbDataExists($value, $destinationId)) {
                            $this->insertIntoEwbTable($value, $destinationId, $userId, 'CD RECEIVE');
                        }

                    }

                }

                if (($user_in_apex === 1) && ((strlen($bagManifest) === 9) || (strlen($bagManifest) === 12))) {

                    if ($this->checkConsignIsEway($bagManifest)) {

                        if (!$this->checkEwbDataExists($bagManifest, $destinationId)) {
                            $this->insertIntoEwbTable($bagManifest, $destinationId, $userId, 'CD RECEIVE');
                        }

                    }
                }


                if ($this->isBagAvailable($bagManifest, $destinationId, $nodeId)) {

                    if(!$this->isBagAvailableLCDmnfstDtls($bagManifest, $phyWeight)){
                            if ($this->insert_dtdc_l_cd_recv_mnfst_dtls($last_cd_receive_dispatch_id, $phyWeight, $bagManifest, $depsId, $depsRemarks, $lastTransaction, $arrival_date, $userId, $modeId, $nodeId, $vehicle_column, $column_value, $originOfficeId, $destinationId, $destinationOfficeType, $originOfficeType, $cd_number, $loader_id, $vendor_id)) {
                                array_push($save_response, $bagManifest);
                            } else {
                                $this->error_response("Query failed while saving master con data into dtdc_f_cd_recv_mnfst_dtls");
                            }
                    }else{
                        array_push($duplicate_response,$bagManifest);
                    }

                } else {
                   
                            if ($this->insert_into_f_cd_recv_mnfst_dtls($last_cd_receive_dispatch_id, $phyWeight, $bagManifest, $depsId, $depsRemarks, $lastTransaction, $arrival_date, $userId, $modeId, $nodeId, $vehicle_column, $column_value, $originOfficeId, $destinationId, $destinationOfficeType, $originOfficeType, $cd_number, $loader_id, $vendor_id)) {
                                array_push($save_response, $bagManifest);
                            } else {
                                $this->error_response("Query failed while saving master con data into dtdc_f_cd_recv_mnfst_dtls");
                            }
                
                }

                if ($isBooked) {
                    $processType = 'CD-RECEIVES';
                    $CI->User_model->updateStatusCodeForConsignment($bagManifest, $officeCode, $userId, $nodeId, $destinationOfficeType, $processType);
                }


            } // for loop
            array_push($vehicle_response, $vehicleNumber);
        }
        $response = array(
            'status' => 1,
            'saved' => $save_response,
            'duplicates' => $duplicate_response,
            'delete' => $vehicle_response,
            'unique_cnsg_numbers' => $consignment_numbers_unique
        );

        return $response;
    }

    public function savemasterconReceiveOfflineProcess($input)
    {
        $consignment_numbers_unique = [];
        $arrival_date = $this->date;
        $arrival_time = $this->time;
        $load_receive_date = $this->date;
        $load_receive_time = $this->time;
        $save_response = array();
        $duplicate_response = array();
        $vehicle_response = array();

        $CI =& get_instance();
        $CI->load->model('User_model');

        foreach ($input as $key => $value) {
            try {
                if (empty($value) && ($value != "0")) {
                    throw new Exception("Error Processing Request " . $key . " is required!", 1);
                }
            } catch (Exception $e) {
                $this->error_response($e->getMessage());
            }
        }
      
        $userId = isset($input['userId']) ? $input['userId'] : $this->error_response('Error: userId is not set.');
        $employeeId = isset($input['employeeId']) ? $input['employeeId'] : $this->error_response('Error: employeeId is not set.');
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        ///$device_id = isset($input['device_id']) ? $input['device_id'] : NULL;
       
       
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $nodeId = isset($input['nodeId']) ? $input['nodeId'] : $this->error_response('Error: nodeId is not set.');
        $officeCode = isset($input['officeCode']) ? $input['officeCode'] : $this->error_response('Error: officeCode is not set.');
        $user_in_apex = isset($input['userInApex']) ? $input['userInApex'] : $this->error_response('Error: userInApex is not set.');
        $destinationId = isset($input['loggedInOfficeId']) ? $input['loggedInOfficeId'] : $this->error_response('Error: loggedInOfficeId is not set.');
        $destinationOfficeType = $this->_get_office_type_from_dtdc_d_office($destinationId);
        $transactionTime = isset($input['transactionTime']) ? $input['transactionTime'] : $this->error_response('Error: transactionTime is not set.');
        $transactionDate = isset($input['transactionDate']) ? $input['transactionDate'] : $this->error_response('Error: transactionDate is not set.');
        $lastTransaction = $transactionDate . " " . $transactionTime;
        $masterConVehicles = isset($input['masterConVehicles']) ? $input['masterConVehicles'] : $this->error_response('Error: masterConVehicles is not set.');
        
        $mail_send_status = $this->sendEmail($masterConVehicles, $officeCode, $userId);
     
       
        $offloadData = $this->insertBagOffLoad($input, $mail_send_status);
       
        for ($i = 0; $i < count($masterConVehicles); $i++) {

            foreach ($masterConVehicles[$i] as $key => $value) {
                try {
                    if (empty($value) && ($value != "0")) {
                        throw new Exception("Error Processing Request " . $key . " is required!", 1);
                    }
                } catch (Exception $e) {
                    $this->error_response($e->getMessage());
                }
            }

            $originCode = isset($masterConVehicles[$i]['originCode']) ? $masterConVehicles[$i]['originCode'] : $this->error_response('Error: originCode is not set.');
            $cdLtRrNumber = isset($masterConVehicles[$i]['cdLtRrNumber']) ? $masterConVehicles[$i]['cdLtRrNumber'] : $this->error_response('Error: cdLtRrNumber is not set.');

            $modeId = isset($masterConVehicles[$i]['modeId']) ? $masterConVehicles[$i]['modeId'] : $this->error_response('Error: modeId is not set.');
            $vehicleNumber = isset($masterConVehicles[$i]['vehicleNumber']) ? $masterConVehicles[$i]['vehicleNumber'] : $this->error_response('Error: vehicleNumber is not set.');
            $vehicleId = isset($masterConVehicles[$i]['vehicleId']) ? $masterConVehicles[$i]['vehicleId'] : $this->error_response('Error: vehicleId is not set.');
            $vehicleType = isset($masterConVehicles[$i]['vehicleType']) ? $masterConVehicles[$i]['vehicleType'] : $this->error_response('Error: vehicleType is not set.');
            $closingKm = isset($masterConVehicles[$i]['closingKm']) ? $masterConVehicles[$i]['closingKm'] : $this->error_response('Key error: closingKm is not set.');

            $deleted_array = [
                'vehicleNumber' => $vehicleNumber,
                'originCode' => $originCode,
                'cdLtRrNumber' => $cdLtRrNumber
            ];


            if ($vehicleType == "1") {
                switch ($modeId) {
                    case '1':
                        $vehicle_column = "AIRPORT_ID";

                        //Store the sent flight number
                        $flight_number = $vehicleId;


                        //Find the airport_id of the flight_number from the db

                        $airport_id_sql = "select airport_id from dtdc_d_airport where AIRLINE_NUMBER = ?";

                        $airport_id_query = $this->db->query($airport_id_sql, [$flight_number]);

                        if ($airport_id_query->num_rows() > 0) {

                            $airport_id = $airport_id_query->result_array()[0]['airport_id'];

                        } else {

                            $airport_id = null;
                        }

                        //
                        $column_value = $airport_id;
                        break;
                    case '10':
                        $vehicle_column = 'TRAIN_ID';
                        $column_value = (int)$vehicleId;
                        break;
                    case '2':
                        //Based on observation on 22march 2017, we found our the vehicle_number
                        //colum not there in db, so since there are duplicate data for vehicle_number and
                        //cannot reliably get vehicle_id, we are storing vehicle_number in temp_vehicle_code column
                        $vehicle_column = "VEHICLE_ID";
                        $column_value = null;
                        // $vehicle_column = "TEMP_VEHICAL_CODE";
                        // $column_value = $vehicleNumber;
                        break;
                    default:
                        $vehicle_column = "VEHICLE_ID";
                        $column_value = null;
                        // $vehicle_column = "TEMP_VEHICAL_CODE";
                        // $column_value = $vehicleNumber;
                        break;
                }
            }

            if ($vehicleType == '0') {
                switch ($modeId) {
                    case '1':
                        $vehicle_column = "TEMP_FLIGHT_NUMBER";
                        $column_value = $vehicleNumber;
                        break;
                    case '10':
                        $vehicle_column = 'TEMP_TRAIN_NUMBER';
                        $column_value = $vehicleNumber;
                        break;
                    case '2':
                        $vehicle_column = "TEMP_VEHICAL_CODE";
                        $column_value = $vehicleNumber;
                        break;
                    default:
                        $vehicle_column = "TEMP_VEHICAL_CODE";
                        $column_value = $vehicleNumber;
                        break;
                }
            }
            $db_server = 'N';
            if ($modeId == 2) {
                $TEMP_VEHICAL_NAME = $vehicleNumber;
            } else {
                $TEMP_VEHICAL_NAME = null;
            }


//            //12 May 2017, getting origin office id in header table
//            $shipments = $masterConVehicles[$i]['shipments'];
//            for ($j = 0; $j < count($shipments); $j++) {
//                $bagManifest = isset($shipments[$j]['bagManifest']) ? $shipments[$j]['bagManifest'] : $this->error_response('Error: bagManifest is not set.');
//
//
//            }


            $insert_data = array(
                'ARRIVAL_DATE' => $arrival_date,
                'ARRIVAL_TIME' => $arrival_time,
                'LOAD_RECV_DATE' => $load_receive_date,
                'LOAD_RECV_TIME' => $load_receive_time,
                $vehicle_column => $column_value,
                'RECIEVER_EMP_ID' => $employeeId,
                'TEMP_VEHICAL_NAME' => $TEMP_VEHICAL_NAME,
                'DB_SERVER' => $db_server,
                'TRANS_CREATE_DATE' => $lastTransaction,
                'TRANS_LAST_MODIFIED_DATE' => $lastTransaction,
                'USER_ID' => $userId,
                'DEST_OFFICE_ID' => $destinationId,
                'DEST_OFFICE_TYPE' => $destinationOfficeType,
                'MODE_ID' => $modeId,
                'NODE_ID' => $nodeId,
                'CLOSING_KM' => $closingKm,
                'EMPLOYEE_ID' => $employeeId
            );


            $this->db->insert('dtdc_f_cd_receive', $insert_data);
            $last_cd_receive_dispatch_id = $this->db->insert_id();

            $shipments = $masterConVehicles[$i]['shipments'];
                   
        


            for ($j = 0; $j < count($shipments); $j++) {

                foreach ($shipments[$j] as $key => $value) {
                    try {
                        if (empty($value) && ($value != "0")) {
                            throw new Exception("Error Processing Request " . $key . " is required!", 1);
                        }
                    } catch (Exception $e) {
                        $this->error_response($e->getMessage());
                    }
                }

                $bagManifest = isset($shipments[$j]['bagManifest']) ? $shipments[$j]['bagManifest'] : $this->error_response('Error: bagManifest is not set.');
                $depsId = isset($shipments[$j]['depsId']) ? $shipments[$j]['depsId'] : $this->error_response('Error: depsId is not set.');
                $depsRemarks = isset($shipments[$j]['depsRemarks']) ? $shipments[$j]['depsRemarks'] : $this->error_response('Error: depsRemakrs is not set.');
                $bagCaptureTime = isset($shipments[$j]['bagCaptureTime']) ? $shipments[$j]['bagCaptureTime'] : $this->error_response('Error: bagCaptureTime is not set.');
                $bagCaptureDate = isset($shipments[$j]['bagCaptureDate']) ? $shipments[$j]['bagCaptureDate'] : $this->error_response('Error: bagCaptureDate is not set.');
                $phyWeight = isset($shipments[$j]['phyWeight']) ? $shipments[$j]['phyWeight'] : $this->error_response('Error: phyWeight is not set.');
                $isBooked = $shipments[$j]['isBooked'];

                $cd_details = $this->getOutboundRecordStatusOfConsignment($bagManifest, $destinationId);

                $cd_number = $cd_details['CD_LT_RR_NUMBER'];
                $loader_id = $cd_details['LOADER_ID'];
                $vendor_id = $cd_details['VENDOR_ID'];
                $originOfficeId = $cd_details['ORIGIN_OFFICE_ID'];
                if($originOfficeId == null){
                    $originOfficeId = $destinationId;
                }

                //$originOfficeId = $this->get_origin_office_id_from_dtdc_f_disp_bag_mnfst_dtls($bagManifest, $destinationId);

                if (!$this->originOfficeIdForHeaderTable && ($originOfficeId != null)) {
                    $this->originOfficeIdForHeaderTable = $originOfficeId;
                    $sql = "update dtdc_f_cd_receive set  ORIGIN_OFFICE_ID = ? where CD_RECEIVE_DISPATCH_ID = ?";
                    $this->db->query($sql, array($originOfficeId, $last_cd_receive_dispatch_id));
                }
                if ($originOfficeId) {
                    $originOfficeType = $this->_get_office_type_from_dtdc_d_office($originOfficeId);
                } else {
                    $originOfficeType = null;
                }

                if (($user_in_apex === 1) && $this->checkWvcFlagForManifestNumber($bagManifest)) {
                    $consignment_numbers_unique = $this->getConsignmentNumbersFromManifest($bagManifest);
                    foreach ($consignment_numbers_unique as $key => $value) {
                        if (!$this->checkEwbDataExists($value, $destinationId)) {
                            $this->insertIntoEwbTable($value, $destinationId, $userId, 'CD RECEIVE');
                        }

                    }

                }

                if (($user_in_apex === 1) && ((strlen($bagManifest) === 9) || (strlen($bagManifest) === 12))) {

                    if ($this->checkConsignIsEway($bagManifest)) {

                        if (!$this->checkEwbDataExists($bagManifest, $destinationId)) {
                            $this->insertIntoEwbTable($bagManifest, $destinationId, $userId, 'CD RECEIVE');
                        }

                    }
                }


                if ($this->isBagAvailable($bagManifest, $destinationId, $nodeId)) {

                    if(!$this->isBagAvailableLCDmnfstDtls($bagManifest, $phyWeight)){
                            if ($this->insert_dtdc_l_cd_recv_mnfst_dtls($last_cd_receive_dispatch_id, $phyWeight, $bagManifest, $depsId, $depsRemarks, $lastTransaction, $arrival_date, $userId, $modeId, $nodeId, $vehicle_column, $column_value, $originOfficeId, $destinationId, $destinationOfficeType, $originOfficeType, $cd_number, $loader_id, $vendor_id)) {
                                array_push($save_response, $bagManifest);
                            } else {
                                $this->error_response("Query failed while saving master con data into dtdc_f_cd_recv_mnfst_dtls");
                            }
                    }else{
                        array_push($duplicate_response,$bagManifest);
                    }

                } else {
                   
                            if ($this->insert_into_f_cd_recv_mnfst_dtls($last_cd_receive_dispatch_id, $phyWeight, $bagManifest, $depsId, $depsRemarks, $lastTransaction, $arrival_date, $userId, $modeId, $nodeId, $vehicle_column, $column_value, $originOfficeId, $destinationId, $destinationOfficeType, $originOfficeType, $cd_number, $loader_id, $vendor_id)) {
                                array_push($save_response, $bagManifest);
                            } else {
                                $this->error_response("Query failed while saving master con data into dtdc_f_cd_recv_mnfst_dtls");
                            }
                
                }

                if ($isBooked) {
                    $processType = 'CD-RECEIVES';
                    $CI->User_model->updateStatusCodeForConsignment($bagManifest, $officeCode, $userId, $nodeId, $destinationOfficeType, $processType);
                }


            } // for loop
            // array_push($vehicle_response, $vehicleNumber);
            array_push($vehicle_response, $deleted_array);
        }
        $response = array(
            'status' => 1,
            'saved' => $save_response,
            'duplicates' => $duplicate_response,
            'delete' => $vehicle_response,
            'unique_cnsg_numbers' => $consignment_numbers_unique,
            'offloadData' => $offloadData
        );

        return $response;
    }

    public function insertBagOffLoad($input, $mail_send_status){

        $masterConVehicles = $input['masterConVehicles'];
        $device_id = $input['deviceId'];
        $userId = $input['userId'];
        $warDate = $input['warDate'];
        $nodeId = $input['nodeId'];
        
      
        $offloadResult = NULL;
        if($masterConVehicles){
            $offloadResult['offloadSaved'] = [];
            $offloadResult['offloadDuplicate'] = [];
            foreach($masterConVehicles as $key => $values){
                $mode = $values['modeId'];
                $shipments = $values['shipments'];
                $flightNumber = $values['vehicleNumber'];
                $cdLtRrNumber = $values['cdLtRrNumber'];
                $originCode = $values['originCode'];
                $device_id = $device_id;  
                $office_id = isset($values['originOfficeId']) ? $values['originOfficeId'] : NULL ;
               
                $cdDisptchDate = $values['cdDisptchDate'];
                $transactionDate = $values['transactionDate'];
                $transactionTime = $values['transactionTime'];
                $loaderId = isset($values['loaderId']) ? $values['loaderId'] : 0;
                $originOfficeId = $values['originOfficeId'];
                $destOfficeId = $values['destOfficeId'];
              

                for ($j = 0; $j < count($shipments); $j++) {
                    $bagManifest = $shipments[$j]['bagManifest'];
                    $receivedStatus = $shipments[$j]['bookingStatus'];
                   

                

                $isAlreadyExist = $this->isAlreadyExistOffloadData($bagManifest);
                if($isAlreadyExist){
                    $offloadResult['offloadDuplicate'][] = $bagManifest;
                }

                if(!$isAlreadyExist){
                    $insertData =   ['BAG_NUMBER' => $bagManifest,
                    'FLIGHT_NO' =>  $flightNumber,
                    'CD_LT_RR_NO' =>  $cdLtRrNumber,
                    'ORIGIN_OFFICE_ID' =>  $originOfficeId,
                    'USER_ID' =>  $userId,
                    'MODE' => $mode,
                    'CD_DISPATCH_DATE' => $cdDisptchDate,
                    'TRANSACTION_CREATE_DATE' => $transactionDate,
                    'TRANSACTION_CREATE_TIME' => $transactionTime,
                    'RECORD_STATUS'=> 'A',
                    'NODE_ID' => $nodeId,
                    'DEVICE_ID' => $device_id,
                    'WAR_DATE' => $warDate,
                    'OFFICE_ID' => $office_id,
                    'LOADER_ID' => $loaderId,
                   // 'ORIGIN_OFFICE_ID'=> NULL,
                    'DEST_OFFICE_ID' => $destOfficeId,
                    'RECEIVED' => $receivedStatus,
                    'EMAIL_SEND_STATUS' => $mail_send_status ];
                     $offloadSaved =  $this->db->insert('DTDC_F_BAG_OFFLOAD', $insertData);
                        if($offloadSaved){
                            $offloadResult['offloadSaved'][] = $bagManifest;  
                        }
                    }
                }
            }
        }
       
         return $offloadResult;

    }

    public function isAlreadyExistOffloadData($bagManifest){
        $sql = "select * from DTDC_F_BAG_OFFLOAD where BAG_NUMBER = ? ";
        $query = $this->db->query($sql, array($bagManifest));
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }

    }
    public function getEmailAddress($officeCode){

        $sql = "select * from dtdc_d_offloadmail_config where branch_code = ? ";
        $query = $this->db->query($sql, array($officeCode));
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return null;
        }



    }
    public function testEmail($inputdata){
        $mail = new PHPMailer(true);
        
//        $this->load->library('PHPMailer');
//
//        // PHPMailer object
//        $mail = $this->phpmailer_lib->load();
        
        // SMTP configuration
        $mail->isSMTP();
        $mail->Host     = 'smtp.gmail.com';
        // $mail->Host     = 'smtp.example.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'prasad@dtdc.com';
        $mail->Password = 'prasad_123';
        // $mail->Username = 'support_nettiapps@dtdc.com';
        // $mail->Password = 'india123$$';
        $mail->SMTPSecure = 'tls';
        $mail->Port     = 587;
        
        $mail->setFrom('prasad@dtdc.com', 'DTDC');
        $mail->addReplyTo('prasad@dtdc.com', 'DTDC');
        
        // Add a recipient
        $mail->addAddress('janagiraman@netiapps.com');
        
        // Add cc or bcc 
        // $mail->addCC('cc@example.com');
        // $mail->addBCC('bcc@example.com');
        
        // Email subject
        $mail->Subject = 'Send Email via SMTP using PHPMailer in CodeIgniter';
        
        // Set email format to HTML
        $mail->isHTML(true);
        
        // Email body content
        $mailContent = "<h1>Send HTML Email using SMTP in CodeIgniter</h1>
            <p>This is a test email sending using SMTP mail server with PHPMailer.</p>";
        $mail->Body = $mailContent;
        
        // Send email
        if($mail->send()){
            echo 'Message has been sent';
        }
        else{
            echo 'Message could not be sent.';
            echo 'Mailer Error: ' . $mail->ErrorInfo;
        }
            
    }

    public function sendEmail($masterConVehicles, $officeCode, $userId){

        $emailAddress = $this->getEmailAddress($officeCode);
        if($masterConVehicles){
            foreach($masterConVehicles as $key => $values){

                $originCode =  $values['originCode'];
                $cdLtRrNumber =  $values['cdLtRrNumber'];
                $flightNumber = $values['vehicleNumber'];
                $transactionDate = $values['transactionDate'];
                $transactionTime = $values['transactionTime'];
                $loaderId  = $values['loaderId'];
                $shipments = $values['shipments'];

                $bag_received_cdltrrnumber_mismatch = null;
                $bag_received_without_any_data = null;
                $bag_received = null;
                $bag_received_with_flight_mismatch = null;
                $bag_not_received = null;
                $table_bag_received_cdltrrnumber_mismatch = null;
                $table_bag_received_without_any_data = null;
                $table_bag_received = null;
                $table_bag_received_with_flight_mismatch = null;
                $table_bag_not_received = null;

                for ($j = 0; $j < count($shipments); $j++) {

                
                    $bagManifest = isset($shipments[$j]['bagManifest']) ? $shipments[$j]['bagManifest'] : $this->error_response('Error: bagManifest is not set.');
                    $depsId = isset($shipments[$j]['depsId']) ? $shipments[$j]['depsId'] : $this->error_response('Error: depsId is not set.');
                    $depsRemarks = isset($shipments[$j]['depsRemarks']) ? $shipments[$j]['depsRemarks'] : $this->error_response('Error: depsRemakrs is not set.');
                    $bagCaptureTime = isset($shipments[$j]['bagCaptureTime']) ? $shipments[$j]['bagCaptureTime'] : $this->error_response('Error: bagCaptureTime is not set.');
                    $bagCaptureDate = isset($shipments[$j]['bagCaptureDate']) ? $shipments[$j]['bagCaptureDate'] : $this->error_response('Error: bagCaptureDate is not set.');
                    $phyWeight = isset($shipments[$j]['phyWeight']) ? $shipments[$j]['phyWeight'] : $this->error_response('Error: phyWeight is not set.');
                    $isBooked = $shipments[$j]['isBooked'];
                    $bookingStatus = $shipments[$j]['bookingStatus'];
                  
                    
                    if($bookingStatus == 1){
                        $bag_received[] = ['bagManifest' => $bagManifest,
                                           'flightNumber' =>  $flightNumber,
                                           'cdLtRrNumber' =>  $cdLtRrNumber,
                                           'originCode' =>  $originCode,
                                           'userId' =>  $userId,
                                           'cdLtRrNumber' =>  $cdLtRrNumber];
                    }
                   
                    if($bookingStatus == 2){
                        $bag_received_with_flight_mismatch[] = ['bagManifest' => $bagManifest,
                                                                'flightNumber' =>  $flightNumber,
                                                                'cdLtRrNumber' =>  $cdLtRrNumber,
                                                                'originCode' =>  $originCode,
                                                                'userId' =>  $userId,
                                                                'cdLtRrNumber' =>  $cdLtRrNumber];
                    }
                    if($bookingStatus == 3){
                        $bag_received_cdltrrnumber_mismatch[] = ['bagManifest' => $bagManifest,
                                                                'flightNumber' =>  $flightNumber,
                                                                'cdLtRrNumber' =>  $cdLtRrNumber,
                                                                'originCode' =>  $originCode,
                                                                'userId' =>  $userId,
                                                                'cdLtRrNumber' =>  $cdLtRrNumber];
                    }
                    if($bookingStatus == 4){
                        $bag_received_without_any_data[] = ['bagManifest' => $bagManifest,
                                                            'flightNumber' =>  $flightNumber,
                                                            'cdLtRrNumber' =>  $cdLtRrNumber,
                                                            'originCode' =>  $originCode,
                                                            'userId' =>  $userId,
                                                            'cdLtRrNumber' =>  $cdLtRrNumber];
                    }
                    if($bookingStatus == 0){
                        $bag_not_received[] = ['bagManifest' => $bagManifest,
                                                            'flightNumber' =>  $flightNumber,
                                                            'cdLtRrNumber' =>  $cdLtRrNumber,
                                                            'originCode' =>  $originCode,
                                                            'userId' =>  $userId,
                                                            'cdLtRrNumber' =>  $cdLtRrNumber];
                    }
                   
                }

                $table_bag_received = null;
                if($bag_received){
                    $table_bag_received = "<table style='border:1px solid black;border-collapse:collapse;'>
                                                <tr style='border:1px solid black;border-collapse:collapse;'>
                                                <th colspan='7'>Bag Received</th>
                                                </tr>
                                                <tr>
                                                <th style='border:1px solid black;border-collapse:collapse;'>S.No</th> 
                                                <th style='border:1px solid black;border-collapse:collapse;'>Bag Number</th> 
                                                <th style='border:1px solid black;border-collapse:collapse;'>Flight Number</th> 
                                                <th style='border:1px solid black;border-collapse:collapse;'>cdLtRrNumber</th> 
                                                <th style='border:1px solid black;border-collapse:collapse;'>originofficeCode</th> 
                                                <th style='border:1px solid black;border-collapse:collapse;'>userId</th> 
                                                
                                                </tr>
                    ";
                    $i =1;
                    foreach($bag_received as $key => $value){
                        $table_bag_received .= "<tr style='border:1px solid black;border-collapse:collapse;'>
                                                <td style='border:1px solid black;border-collapse:collapse;' >".$i."</td>
                                                <td style='border:1px solid black;border-collapse:collapse;'>".$value['bagManifest']."</td>
                                                <td style='border:1px solid black;border-collapse:collapse;'>".$value['flightNumber']."</td>
                                                <td style='border:1px solid black;border-collapse:collapse;'>".$value['cdLtRrNumber']."</td>
                                                <td style='border:1px solid black;border-collapse:collapse;'>".$value['originCode']."</td>
                                                <td style='border:1px solid black;border-collapse:collapse;'>".$value['userId']."</td>
                                            </tr>";
                                            $i++;
                    }
                    $table_bag_received .= "</table>"; 
                }

                if($bag_received_with_flight_mismatch){
                    $table_bag_received_with_flight_mismatch = "<table style='border:1px solid black;border-collapse:collapse;'>
                                        <tr style='border:1px solid black;'>
                                        <th colspan='7'>Bag Received With Flight Mismatch</th>
                                        </tr>                    
                                        <tr style='border:1px solid black;'>
                                        <th style='border:1px solid black;'>S.No</th> 
                                        <th style='border:1px solid black;'>Bag Number</th> 
                                        <th style='border:1px solid black;'>Flight Number</th> 
                                        <th style='border:1px solid black;'>cdLtRrNumber</th> 
                                        <th style='border:1px solid black;'>originofficeCode</th> 
                                        <th style='border:1px solid black;'>userId</th> 
                                        </tr>
                    ";
                    $j=1;
                    foreach($bag_received_with_flight_mismatch as $key => $value){
                        $table_bag_received_with_flight_mismatch .= "<tr style='border:1px solid black;'>
                                                <td style='border:1px solid black;'>$j</td>
                                                <td style='border:1px solid black;'>".$value['bagManifest']."</td>
                                                <td style='border:1px solid black;'>".$value['flightNumber']."</td>
                                                <td style='border:1px solid black;'>".$value['cdLtRrNumber']."</td>
                                                <td style='border:1px solid black;'>".$value['originCode']."</td>
                                                <td style='border:1px solid black;'>".$value['userId']."</td>
                                            </tr>";
                        $j++;
                    }
                    $table_bag_received_with_flight_mismatch .= "</table>"; 
                }

                if($bag_received_cdltrrnumber_mismatch){
                    $table_bag_received_cdltrrnumber_mismatch = "<table style='border:1px solid black;border-collapse:collapse;'>
                                                                <tr style='border:1px solid black;'>
                                                                <th colspan='7' >Bag Received cdLrrNumber Mismatch</th>
                                                                </tr>  
                                                                <tr>
                                                                <th style='border:1px solid black;'>S.No</th> 
                                                                <th style='border:1px solid black;border-collapse:collapse;'>Bag Number</th> 
                                                                <th style='border:1px solid black;border-collapse:collapse;'>Flight Number</th> 
                                                                <th style='border:1px solid black;border-collapse:collapse;'>cdLtRrNumber</th> 
                                                                <th style='border:1px solid black;border-collapse:collapse;'>originofficeCode</th> 
                                                                <th style='border:1px solid black;border-collapse:collapse;'>userId</th> 
                                                                </tr>";
                    $k=1;
                    foreach($bag_received_cdltrrnumber_mismatch as $key => $value){
                        $table_bag_received_cdltrrnumber_mismatch .= "<tr style='border:1px solid black;border-collapse:collapse;'>
                                                <td style='border:1px solid black;border-collapse:collapse;'>$k</td>
                                                <td style='border:1px solid black;border-collapse:collapse;'>".$value['bagManifest']."</td>
                                                <td style='border:1px solid black;border-collapse:collapse;'>".$value['flightNumber']."</td>
                                                <td style='border:1px solid black;border-collapse:collapse;'>".$value['cdLtRrNumber']."</td>
                                                <td style='border:1px solid black;border-collapse:collapse;'>".$value['originCode']."</td>
                                                <td style='border:1px solid black;border-collapse:collapse;'>".$value['userId']."</td>
                                            </tr>";
                        $k++;
                    }
                    $table_bag_received_cdltrrnumber_mismatch .= "</table>"; 
                }

                if($bag_received_without_any_data){
                    $table_bag_received_without_any_data = "<table style='border:1px solid black;border-collapse:collapse;'>
                                                                <tr style='border:1px solid black;border-collapse:collapse;'>
                                                                <th colspan='7' style='border:1px solid black;'>Bag Received Without any data</th>
                                                                </tr>  
                                                                <tr style='border:1px solid black;border-collapse:collapse;'>
                                                                <th style='border:1px solid black;border-collapse:collapse;'>S.No</th> 
                                                                <th style='border:1px solid black;border-collapse:collapse;'>Bag Number</th> 
                                                                <th style='border:1px solid black;border-collapse:collapse;'>Flight Number</th> 
                                                                <th style='border:1px solid black;border-collapse:collapse;'>cdLtRrNumber</th> 
                                                                <th style='border:1px solid black;border-collapse:collapse;'>originofficeCode</th> 
                                                                <th style='border:1px solid black;border-collapse:collapse;'>userId</th> 
                                                                </tr>";
                    $l=1;
                    foreach($bag_received_without_any_data as $key => $value){
                        $table_bag_received_without_any_data .= "<tr style='border:1px solid black;border-collapse:collapse;'>
                                                <td style='border:1px solid black;border-collapse:collapse;'>$l</td>
                                                <td style='border:1px solid black;border-collapse:collapse;'>".$value['bagManifest']."</td>
                                                <td style='border:1px solid black;border-collapse:collapse;'>".$value['flightNumber']."</td>
                                                <td style='border:1px solid black;border-collapse:collapse;'>".$value['cdLtRrNumber']."</td>
                                                <td style='border:1px solid black;border-collapse:collapse;'>".$value['originCode']."</td>
                                                <td style='border:1px solid black;border-collapse:collapse;'>".$value['userId']."</td>
                                            </tr>";
                        $l++;
                    }
                    $table_bag_received_without_any_data .= "</table>"; 
                }

                if($bag_not_received){
                    $table_bag_not_received = "<table style='border:1px solid black;border-collapse:collapse;'>
                                                                <tr style='border:1px solid black;border-collapse:collapse;'>
                                                                <th colspan='7' style='border:1px solid black;'>Bag Not Received </th>
                                                                </tr>  
                                                                <tr style='border:1px solid black;border-collapse:collapse;'>
                                                                <th style='border:1px solid black;border-collapse:collapse;'>S.No</th> 
                                                                <th style='border:1px solid black;border-collapse:collapse;'>Bag Number</th> 
                                                                <th style='border:1px solid black;border-collapse:collapse;'>Flight Number</th> 
                                                                <th style='border:1px solid black;border-collapse:collapse;'>cdLtRrNumber</th> 
                                                                <th style='border:1px solid black;border-collapse:collapse;'>originofficeCode</th> 
                                                                <th style='border:1px solid black;border-collapse:collapse;'>userId</th> 
                                                                </tr>";
                    $m=1;
                    foreach($bag_not_received as $key => $value){
                        $table_bag_not_received .= "<tr style='border:1px solid black;border-collapse:collapse;'>
                                                <td style='border:1px solid black;border-collapse:collapse;'>$m</td>
                                                <td style='border:1px solid black;border-collapse:collapse;'>".$value['bagManifest']."</td>
                                                <td style='border:1px solid black;border-collapse:collapse;'>".$value['flightNumber']."</td>
                                                <td style='border:1px solid black;border-collapse:collapse;'>".$value['cdLtRrNumber']."</td>
                                                <td style='border:1px solid black;border-collapse:collapse;'>".$value['originCode']."</td>
                                                <td style='border:1px solid black;border-collapse:collapse;'>".$value['userId']."</td>
                                            </tr>";
                        $m++;
                    }
                    $table_bag_not_received .= "</table>"; 
                }
               
                $mailContent = '';
        
        
                $mail = new PHPMailer(true);
                // SMTP configuration
                $mail->isSMTP();
                $mail->Host     = 'smtp.gmail.com';
                // $mail->Host     = 'smtp.example.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'prasad@dtdc.com';
                $mail->Password = 'prasad_123';
                $mail->SMTPSecure = 'tls';
                $mail->Port     = 587;
                $mail->setFrom('prasad@dtdc.com', 'DTDC');
                $mail->addReplyTo('prasad@dtdc.com', 'DTDC');
         
         
                if($emailAddress){
                    $to_email = null;
                    $cc_email = null;
                    foreach($emailAddress as $key => $value){
                        
                            $to_email = $value['TO_EMAIL'];
                            $cc_email = $value['CC_EMAIL'];
                            $mail->addAddress($to_email);
                            $mail->addCC($cc_email);
                            // Email subject
                            $mail->Subject = 'DTDC';
                            // Set email format to HTML
                            $mail->isHTML(true);
                            // Email body content
                            $mailContent .= $table_bag_received . "<br>".
                                                $table_bag_received_with_flight_mismatch . "<br>".
                                                $table_bag_received_cdltrrnumber_mismatch . "<br>".
                                                $table_bag_received_without_any_data . "<br>".
                                                $table_bag_not_received . "<br>";
                            $mail->Body = $mailContent;
                            
                            // Send email
                            if($mail->send()){
                                return 1;
                            }
                            else{
                                return 0;
                            }
                    }
                }
             
            }
        }
        
    }

    public function error_response($e)
    {
        $response = array('status' => 0, 'message' => $e);
        echo json_encode($response);
        exit;
    }

    protected function _get_office_type_from_dtdc_d_office($office_id)
    {

        $office_type_query = "SELECT off_type FROM dtdc_d_office where office_id = ? limit 1";

        $office_type_result = $this->db->query($office_type_query,[$office_id]);
        try {
            if ($office_type_result->num_rows() > 0) {
                $office_type_result_array = $office_type_result->result_array();
                $office_type = $office_type_result_array[0]['off_type'];

                return $office_type;
            } else {
                $office_type = null;

                return $office_type;
                // throw new Exception("Error Processing Request: Wrong office id", 1);
            }
        } catch (Exception $e) {
            $this->error_response($e->getMessage());
        }
    }

    //22Jan2018

    public function get_cd_number($bag_manifest_number, $logged_in_office_id)
    {
        $sql = "select d.CD_LT_RR_NUMBER, d.LOADER_ID, d.VENDOR_ID, d.ORIGIN_OFFICE_ID from dtdc_f_dispatch h, dtdc_f_disp_bag_mnfst_dtls d where h.dispatch_id = d.dispatch_id
and d.bag_manIfest_number=? AND h.DEST_OFFICE_ID=?";
        $query = $this->db->query($sql, array($bag_manifest_number, $logged_in_office_id));
        if ($query->num_rows() > 0) {
            return $query->result_array()[0];
        } else {
            return null;
        }

    }

    public function get_origin_office_id_from_dtdc_f_disp_bag_mnfst_dtls($bag_manifest_number, $logged_in_office_id)
    {
        $sql = "select ORIGIN_OFFICE_ID from dtdc_f_disp_bag_mnfst_dtls where bag_manifest_number = ? and dest_office_id=?";
        $query = $this->db->query($sql, array($bag_manifest_number, $logged_in_office_id));
        if ($query->num_rows() > 0) {
            return $query->result_array()[0]['ORIGIN_OFFICE_ID'];
        } else {
            return null;
        }
    }

    public function checkWvcFlagForManifestNumber($manifest_number)
    {
        $sql = "SELECT CONSG_NUMBER FROM DTDC_F_MANIFEST WHERE MANIFEST_NUMBER = ? and WVC_FLAG = 'Y'";

        $query = $this->db->query($sql, [$manifest_number]);

        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    //2May2017

    public function getConsignmentNumbersFromManifest($manifest_number)
    {
        $consignment_numbers_9_digit_array = [];

        $sql = "select CONSG_NUMBER from dtdc_f_manifest where MANIFEST_NUMBER = ? and WVC_FLAG = 'Y'";
        $query = $this->db->query($sql, [$manifest_number]);
        if ($query->num_rows() > 0) {
            $consignment_numbers = $query->result_array();
            foreach ($consignment_numbers as $consignment_number) {
                $consignment_number_9_digit = substr($consignment_number['CONSG_NUMBER'], 0, 9);
                array_push($consignment_numbers_9_digit_array, $consignment_number_9_digit);
            }

            $consignment_numbers_9_digit_array = array_unique($consignment_numbers_9_digit_array);


        }

        return $consignment_numbers_9_digit_array;
    }

    //2May2017

    public function checkEwbDataExists($consignment_number, $office_id)
    {
        $sql = "select EWB_ID from dtdc_f_ewb_info where CONSG_NUMBER = ? and TRANS_OFFICE_ID = ?";
        $query = $this->db->query($sql, [$consignment_number, $office_id]);
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function insertIntoEwbTable($consignment_number, $logged_in_office_id, $user_id, $process)
    {

        $sql = "select * from dtdc_f_ewb_info where consg_number = ? limit 1";

        $query = $this->db->query($sql, [$consignment_number]);

        $additional_fields = [
            'DECLARED_VALUE' => null,
            'EWB_NUMBER' => null,
            'GST_REG_STATUS' => null,
            'INVOICE_NUMBER' => null,
            'INVOICE_DATE' => null,
            'HSN_CODE' => null,
            'CONSOLIDATED_EW' => null,
            'SENDERGSTIN' => null,
            'TOTALVALUE' => null,
            'CGSTVALUE' => null,
            'SGSTVALUE' => null,
            'IGSTVALUE' => null,
            'CESSVALUE' => null
        ];

        if ($query->num_rows() > 0) {
            $result = $query->result_array()[0];
            $additional_fields['DECLARED_VALUE'] = $result['DECLARED_VALUE'];
            $additional_fields['EWB_NUMBER'] = $result['EWB_NUMBER'];
            $additional_fields['GST_REG_STATUS'] = $result['GST_REG_STATUS'];
            $additional_fields['INVOICE_NUMBER'] = $result['INVOICE_NUMBER'];
            $additional_fields['INVOICE_DATE'] = $result['INVOICE_DATE'];
            $additional_fields['HSN_CODE'] = $result['HSN_CODE'];
            $additional_fields['CONSOLIDATED_EW'] = $result['CONSOLIDATED_EW'];
            $additional_fields['SENDERGSTIN'] = $result['SENDERGSTIN'];
            $additional_fields['TOTALVALUE'] = $result['TOTALVALUE'];
            $additional_fields['CGSTVALUE'] = $result['CGSTVALUE'];
            $additional_fields['SGSTVALUE'] = $result['SGSTVALUE'];
            $additional_fields['IGSTVALUE'] = $result['IGSTVALUE'];
            $additional_fields['CESSVALUE'] = $result['CESSVALUE'];

            $insert_data = [
                'CONSG_NUMBER' => $consignment_number,
                'TRANS_OFFICE_ID' => $logged_in_office_id,
                'USERID' => $user_id,
                'NODEID' => 'MOP',
                'TRANS_CREATE_DATE' => $this->server_date_time,
                'MOD_DATE_TIME' => $this->server_date_time,
                'RECORD_STATUS' => 'A',
                'EWB_STATUS' => 'N',
                'PROCESS' => $process
            ];

            $this->db->insert('dtdc_f_ewb_info', array_merge($insert_data, $additional_fields));

            if ($this->db->affected_rows() > 0) {

                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }


    }


    public function insertIntoEwbTableUpdateData($consignment_number, $logged_in_office_id, $user_id, $process)
    {

        $sql = "select * from dtdc_f_ewb_info where consg_number = ? limit 1";

        $query = $this->db->query($sql, [$consignment_number]);

        $additional_fields = [
            'DECLARED_VALUE' => null,
            'EWB_NUMBER' => null,
            'GST_REG_STATUS' => null,
            'INVOICE_NUMBER' => null,
            'INVOICE_DATE' => null,
            'HSN_CODE' => null,
            'CONSOLIDATED_EW' => null,
            'SENDERGSTIN' => null,
            'TOTALVALUE' => null,
            'CGSTVALUE' => null,
            'SGSTVALUE' => null,
            'IGSTVALUE' => null,
            'CESSVALUE' => null
        ];

        if ($query->num_rows() > 0) {
            $result = $query->result_array()[0];
            $additional_fields['DECLARED_VALUE'] = $result['DECLARED_VALUE'];
            $additional_fields['EWB_NUMBER'] = $result['EWB_NUMBER'];
            $additional_fields['GST_REG_STATUS'] = $result['GST_REG_STATUS'];
            $additional_fields['INVOICE_NUMBER'] = $result['INVOICE_NUMBER'];
            $additional_fields['INVOICE_DATE'] = $result['INVOICE_DATE'];
            $additional_fields['HSN_CODE'] = $result['HSN_CODE'];
            $additional_fields['REASON_TRANSPORT'] = $result['REASON_TRANSPORT'];
            $additional_fields['CONSOLIDATED_EW'] = $result['CONSOLIDATED_EW'];
            $additional_fields['SENDERGSTIN'] = $result['SENDERGSTIN'];
            $additional_fields['SENDERNAME'] = $result['SENDERNAME'];
            $additional_fields['SENDERADDR1'] = $result['SENDERADDR1'];
            $additional_fields['SENDERADDR2'] = $result['SENDERADDR2'];
            $additional_fields['SENDERPLACE'] = $result['SENDERPLACE'];
            $additional_fields['SENDERPINCODE'] = $result['SENDERPINCODE'];
            $additional_fields['SENDERSTATECODE'] = $result['SENDERSTATECODE'];
            $additional_fields['TOTALVALUE'] = $result['TOTALVALUE'];
            $additional_fields['CGSTVALUE'] = $result['CGSTVALUE'];
            $additional_fields['SGSTVALUE'] = $result['SGSTVALUE'];
            $additional_fields['IGSTVALUE'] = $result['IGSTVALUE'];
            $additional_fields['CESSVALUE'] = $result['CESSVALUE'];
            $additional_fields['EWB_STATUS'] = $result['EWB_STATUS'];
            $additional_fields['RECORD_STATUS'] = $result['RECORD_STATUS'];
            $additional_fields['RECEIVERGSTIN'] = $result['RECEIVERGSTIN'];
            $additional_fields['RECEIVERNAME'] = $result['RECEIVERNAME'];
            $additional_fields['RECEIVERADDR1'] = $result['RECEIVERADDR1'];
            $additional_fields['RECEIVERADDR2'] = $result['RECEIVERADDR2'];
            $additional_fields['RECEIVERPLACE'] = $result['RECEIVERPLACE'];
            $additional_fields['RECEIVERPINCODE'] = $result['RECEIVERPINCODE'];
            $additional_fields['RECEIVERSTATECODE'] = $result['RECEIVERSTATECODE'];
            $additional_fields['TRANSMODE'] = $result['TRANSMODE'];
            $additional_fields['VEHICLE_NUMBER'] = $result['VEHICLE_NUMBER'];
            $additional_fields['TRANSACTION_TYPE'] = $result['TRANSACTION_TYPE'];
            $additional_fields['READ_BY_LOCAL'] = $result['READ_BY_LOCAL'];
            $additional_fields['EWB_ERROR_MSG'] = $result['EWB_ERROR_MSG'];
            $additional_fields['VALID_TILL'] = $result['VALID_TILL'];
            $additional_fields['PROCESSED_STATUS'] = $result['PROCESSED_STATUS'];
            $additional_fields['PROCESSED_ON'] = $result['PROCESSED_ON'];

            $insert_data = [
                'CONSG_NUMBER' => $consignment_number,
                'TRANS_OFFICE_ID' => $logged_in_office_id,
                'USERID' => $user_id,
                'NODEID' => 'MOP',
                'TRANS_CREATE_DATE' => $this->server_date_time,
                'MOD_DATE_TIME' => $this->server_date_time,
                'PROCESS' => $process
            ];

            $this->db->insert('dtdc_f_ewb_info', array_merge($insert_data, $additional_fields));

            if ($this->db->affected_rows() > 0) {

                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }


    }

    public function checkConsignIsEway($manifest_number)
    {
        $sql = "select CONSG_NUMBER from dtdc_f_ewb_info where CONSG_NUMBER = ?";

        $query = $this->db->query($sql, [$manifest_number]);

        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function isBagAvailableLCDmnfstDtls($bag_number, $phyWeight){

       // if ($node_id == 'MOP') {
        if($phyWeight == 0){
            $sql = "Select CD_RECEIVE_DISPATCH_ID from dtdc_l_cd_recv_mnfst_dtls where BAG_MANIFEST_NUMBER = ? AND PHY_WEIGHT = 0 ";
        } 
        if($phyWeight > 0 ){
            $sql = "Select CD_RECEIVE_DISPATCH_ID from dtdc_l_cd_recv_mnfst_dtls where BAG_MANIFEST_NUMBER = ? AND PHY_WEIGHT > 0 ";
        }
        // }else {
        //     $sql = "Select CD_RECEIVE_DISPATCH_ID from dtdc_l_cd_recv_mnfst_dtls where BAG_MANIFEST_NUMBER = ? and DEST_OFFICE_ID = ? and PHY_WEIGHT >='0'";
        // }
        $query = $this->db->query($sql, array($bag_number));

        if ($query->num_rows() > 0) {

            //Already exists

            return true;


        } else {

            return false;
        }

    }

    public function toCheckIsBagAvail($bag_number){

        $sql = "SELECT DISTINCT(MANIFEST_NUMBER ) FROM DTDC_F_MANIFEST WHERE MANIFEST_NUMBER= ? AND MANIFEST_TYPE='O' ";
        $query = $this->db->query($sql, array($bag_number));
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }
    public function toCheckBagOrPacket($bag_number){

        $sql = "SELECT DISTINCT(MANIFEST_NUMBER ) FROM DTDC_F_MANIFEST WHERE MANIFEST_NUMBER= ? AND MNFST_TYPE_ID IN (2,5) AND  MANIFEST_TYPE='O' ";
        $query = $this->db->query($sql, array($bag_number));
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function isBagAvailable($bag_number, $logged_in_office_id, $node_id)
    {

        //check if exists in

        //$sql = "select CD_RECEIVE_DISPATCH_ID from dtdc_f_cd_recv_mnfst_dtls where BAG_MANIFEST_NUMBER = ? and DEST_OFFICE_ID = ? and node_id = ?";

        ## added on 24.7.18 commented prev line

        ## added on 02.02.19
        if ($node_id == 'MOP') {
            $sql = "Select CD_RECEIVE_DISPATCH_ID from dtdc_f_cd_recv_mnfst_dtls where BAG_MANIFEST_NUMBER = ? and DEST_OFFICE_ID = ?  and PHY_WEIGHT > 0";
        } else {
            $sql = "Select CD_RECEIVE_DISPATCH_ID from dtdc_f_cd_recv_mnfst_dtls where BAG_MANIFEST_NUMBER = ? and DEST_OFFICE_ID = ? ";
        }
        $query = $this->db->query($sql, array($bag_number, $logged_in_office_id));

        if ($query->num_rows() > 0) {

            //Already exists

            return true;


        } else {

            return false;
        }

    }

    public function getBookingWeight($consg_number)
    {
        $sql = "select FINAL_WEIGHT from dtdc_f_booking where CONSG_NUMBER = ?";
        $query = $this->db->query($sql, [$consg_number]);
        if ($query->num_rows() > 0) {
            return $query->result_array()[0]['FINAL_WEIGHT'];
        } else {
            return false;
        }

    }

    public function getOutboundRecordStatusOfConsignment($consg_number, $dest_off_id)
    {
        $cd_details = $this->get_cd_number($consg_number, $dest_off_id);
        if ($cd_details) {
            return $cd_details;
        } else {
            if (strlen($consg_number) != 8) {
                $manifest_number = $this->getOutgoingManifestNumber($consg_number, $dest_off_id);
                if ($manifest_number) {
                    $cd_details_manifest = $this->get_cd_number($manifest_number, $dest_off_id);
                    if ($cd_details_manifest) {
                        return $cd_details_manifest;
                    } else {
                        return null;
                    }
                } else {
                    return null;
                }
            } else {
                return null;
            }
        }
    }

    public function getOutgoingManifestNumber($consg_number, $dest_off_id)
    {
        $sql = "select manifest_number from  dtdc_f_manifest where CONSG_NUMBER = ? and DEST_BRNCH_ID = ?";
        $query = $this->db->query($sql, [$consg_number, $dest_off_id]);
        if ($query->num_rows() > 0) {
            return $query->result_array()[0]['manifest_number'];
        } else {
            return false;
        }
    }

    protected function insert_dtdc_l_cd_recv_mnfst_dtls($cd_receive_dispatch_id, $phyWeight, $manifestNumber, $depsId, $depsRemarks, $lastTransaction, $arrival_date, $userId, $modeId, $nodeId, $vehicle_column, $column_value, $originOfficeId, $destinationId, $destinationOfficeType, $originOfficeType, $cd_number, $loader_id, $vendor_id)
    {

        $arrival_time = $this->time;
        $db_server = 'N';

        $insert_data = array(
            'CD_RECEIVE_DISPATCH_ID' => $cd_receive_dispatch_id,
            'BAG_MANIFEST_NUMBER' => $manifestNumber,
            'DEPS_CATEGORY' => $depsId,
            'TRANS_CREATE_DATE' => $arrival_date,
            'TRANS_LAST_MODIFIED_DATE' => $arrival_date,
            'DB_SERVER' => $db_server,
            'USER_ID' => $userId,
            'MODE_ID' => $modeId,
            'NODE_ID' => $nodeId,
//            $vehicle_column => $column_value,
            'CD_DATE' => $arrival_date,
            'CD_TIME' => $arrival_time,
            'CD_LT_RR_NO' => $cd_number,
            'ARRIVAL_TIME' => $arrival_time,
//            'ORIGIN_OFFICE_ID' => $originOfficeId,
//            'DEST_OFFICE_ID' => $destinationId,
//            'DEST_OFFICE_TYPE' => $destinationOfficeType,
            'PHY_WEIGHT' => $phyWeight,
//            'ORIGIN_OFFICE_TYPE' => $originOfficeType,
            'LOADER_ID' => $loader_id,
            'VENDOR_ID' => $vendor_id

        );

        $this->db->insert('dtdc_l_cd_recv_mnfst_dtls', $insert_data);

        if ($this->db->affected_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    protected function insert_into_f_cd_recv_mnfst_dtls($cd_receive_dispatch_id, $phyWeight, $manifestNumber, $depsId, $depsRemarks, $lastTransaction, $arrival_date, $userId, $modeId, $nodeId, $vehicle_column, $column_value, $originOfficeId, $destinationId, $destinationOfficeType, $originOfficeType, $cd_number, $loader_id, $vendor_id)
    {

        $arrival_time = $this->time;
        $db_server = 'N';

        $insert_data = array(
            'CD_RECEIVE_DISPATCH_ID' => $cd_receive_dispatch_id,
            'BAG_MANIFEST_NUMBER' => $manifestNumber,
            'DEPS_CATEGORY' => $depsId,
            'TRANS_CREATE_DATE' => $arrival_date,
            'TRANS_LAST_MODIFIED_DATE' => $arrival_date,
            'DB_SERVER' => $db_server,
            'USER_ID' => $userId,
            'MODE_ID' => $modeId,
            'NODE_ID' => $nodeId,
            $vehicle_column => $column_value,
            'CD_DATE' => $arrival_date,
            'CD_TIME' => $arrival_time,
            'CD_LT_RR_NO' => $cd_number,
            'ARRIVAL_TIME' => $arrival_time,
            'ORIGIN_OFFICE_ID' => $originOfficeId,
            'DEST_OFFICE_ID' => $destinationId,
            'DEST_OFFICE_TYPE' => $destinationOfficeType,
            'PHY_WEIGHT' => $phyWeight,
            'ORIGIN_OFFICE_TYPE' => $originOfficeType,
            'LOADER_ID' => $loader_id,
            'VENDOR_ID' => $vendor_id

        );

        $this->db->insert('dtdc_f_cd_recv_mnfst_dtls', $insert_data);

        if ($this->db->affected_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function count_bag_manifest_number($manifestNumber)
    {
        $query = "select * from dtdc_f_cd_recv_mnfst_dtls where BAG_MANIFEST_NUMBER = ?";
        $result = $this->db->query($query,[$manifestNumber]);

        return $result->num_rows();
    }

    public function saveincomingbagmanifest($input)
    {

        $central_server_date = $this->date;
        $central_server_time = $this->time;
        $central_server_date_time = $central_server_date . " " . $central_server_time;
        $save_response = array();
        $duplicate_response = array();
        $manifest_numbers_to_delete_array = array();
        foreach ($input as $key => $value) {
            try {
                if (empty($value) && ($value != "0")) {
                    throw new Exception("Error Processing Request " . $key . " is required.", 1);
                }
            } catch (Exception $e) {
                $this->error_response($e->getMessage());
                exit;
            }
        }

        $userId = isset($input['userId']) ? $input['userId'] : $this->error_response('Error: Expected userId from received data');
        $employeeId = isset($input['employeeId']) ? $input['employeeId'] : $this->error_response('Incomplete input: employeeId not received.');
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
        $destinationId = isset($input['destinationId']) ? $input['destinationId'] : $this->error_response('Error: Plese send loggedin office id!');
        $warDate = isset($input['warDate']) ? $input['warDate'] : null;
        $transactionTime = isset($input['transactionTime']) ? $input['transactionTime'] : $this->error_response('Error: transactionTime is not set');
        $transactionDate = isset($input['transactionDate']) ? $input['transactionDate'] : $this->error_response('Error: transactionDate is not set');
        $transactionDate = $this->server_date_time;
        $nodeId = isset($input['nodeId']) ? $input['nodeId'] : $this->error_response('Error: nodeId is not set');
        $manifests = isset($input['manifests']) ? $input['manifests'] : $this->error_response('Error: manifests is not set.');
        for ($i = 0; $i < count($manifests); $i++) {
            foreach ($manifests[$i] as $key_manifests => $value_manifests) {
                try {
                    if (empty($value_manifests) && ($value_manifests != '0')) {
                        throw new Exception("Error Processing Request " . $key . " is required.", 1);
                    }
                } catch (Exception $e) {
                    $this->error_response($e->getMessage());
                }
            }
//			$manifestNumber = isset( $manifests[ $i ]['manifestNumber'] ) ? $manifests[ $i ]['manifestNumber'] : $this->error_response( 'Error: Manifest number not set.' );
            $skip = isset($manifests[$i]['skip']) ? $manifests[$i]['skip'] : 'false';
            //NULL
            $totalWeightKgs = isset($manifests[$i]['totalWeightKgs']) ? $manifests[$i]['totalWeightKgs'] : $this->error_response('Error: totalWeightKgs is not set.');
            //Null
            $totalNoOfPackets = isset($manifests[$i]['totalNoOfPackets']) ? $manifests[$i]['totalNoOfPackets'] : $this->error_response('Error: totalNoOfPackets is not set.');
            //NUll
            $manifestOriginId = isset($manifests[$i]['manifestOriginId']) ? $manifests[$i]['manifestOriginId'] : $this->error_response('Error: manifestOriginId is not set.');
            //NULL
            $manifestDestinationId = isset($manifests[$i]['manifestDestinationId']) ? $manifests[$i]['manifestDestinationId'] : $this->error_response('Error: manifestDestinationId is not set.');
            $headerManifestTypeId = isset($manifests[$i]['headerManifestTypeId']) ? $manifests[$i]['headerManifestTypeId'] : $this->error_response('Error: headerManifestTypeId is not set.');
            $manifestDate = isset($manifests[$i]['manifestDate']) ? $manifests[$i]['manifestDate'] : $this->error_response('Error: manifestDate is not set.');
            $manifestTime = isset($manifests[$i]['manifestTime']) ? $manifests[$i]['manifestTime'] : $this->error_response('Error: manifestTime is not set.');
            $weighingType = isset($manifests[$i]['weighingType']) ? $manifests[$i]['weighingType'] : $this->error_response('Error: weighingType is not set.');
            $consignments = isset($manifests[$i]['consignments']) ? $manifests[$i]['consignments'] : $this->error_response('Error: consignments is not set.');

            //Changing manifest date
            $manifestDate = $central_server_date;
            $manifestTime = $central_server_time;

            // $totalNoOfPackets = count($consignments);

            for ($j = 0; $j < count($consignments); $j++) {
                foreach ($consignments[$j] as $key_consignments => $value_consigments) {
                    try {
                        if (empty($value_consigments) && ($value_consigments != "0")) {
                            throw new Exception("Error Processing Request " . $key_consignments . " is required.", 1);
                        }
                    } catch (Exception $e) {
                        $this->error_response($e->getMessage());
                    }
                }
                $consignmentNumber = isset($consignments[$j]['consignmentNumber']) ? $consignments[$j]['consignmentNumber'] : $this->error_response('Error: consignmentNumber is not set.');
                $individualWeightKgs = isset($consignments[$j]['individualWeightKgs']) ? $consignments[$j]['individualWeightKgs'] : $this->error_response('Error: individualWeightKgs is not set.');
                $depsCategory = isset($consignments[$j]['depsCategory']) ? $consignments[$j]['depsCategory'] : $this->error_response('Error: depsCategory is not set.');
                if($depsCategory === 'NULL'){
                    $depsCategory = null;
                }

                $consignmentOriginId = isset($consignments[$j]['consignmentOriginId']) ? $consignments[$j]['consignmentOriginId'] : $this->error_response('Error: consignmentOriginId is not set.');
                // echo $consignmentOriginId;

                $manifestNumber = $this->getManifestNumberFromConsignment($consignmentNumber, $destinationId);

//                if ($skip == 'true') {
//                    $originOfficeId = $this->get_origin_branch_id_from_consignment_number($consignmentNumber, $destinationId);
//                    if (!$originOfficeId) {
////                        $originOfficeId = null;
//                        $originOfficeId = $destinationId;
//                    }
//                } else {
//                    $originOfficeId = $this->get_origin_id_from_branch_id($manifestOriginId);
//                    if ($originOfficeId == 'NOT_IN_DTDC_D_OFFICE') {
//                        $originOfficeId = $this->get_origin_branch_id_from_dtdc_f_manifest($manifestNumber, false);
//                        if (!$originOfficeId) {
////                            $originOfficeId = null;
//                            $originOfficeId = $destinationId;
//                        }
//                    }
//                }


                //NULL
                $consignmentDestinationId = isset($consignments[$j]['consignmentDestinationId']) ? $consignments[$j]['consignmentDestinationId'] : $this->error_response('Error: consignmentDestinationId is not set.');
                //NULL
//                $manifestTypeId = isset($consignments[$j]['manifestTypeId']) ? $consignments[$j]['manifestTypeId'] : $this->error_response('Error: manifestTypeId is not set.');
//                if ($manifestTypeId == '0') {
//                    $manifestTypeId = null;
//                }
//                $manifestTypeDefinition = $this->get_manifest_code($manifestTypeId);
//                if (!$manifestTypeDefinition) {
//                    $manifestTypeDefinition = null;
//                }
                // echo $manifestTypeId;
                //NULL
//                $documentId = isset($consignments[$j]['documentId']) ? $consignments[$j]['documentId'] : $this->error_response('Error: documentId is not set.');
//
//                if ($documentId == '0') {
//                    $documentId = $this->get_document_id_from_manifest($consignmentNumber);
//                    if (!$documentId) {
//                        $documentId = null;
//                    }
//                }
                // echo $documentId;
                $consignmentDate = isset($consignments[$j]['consignmentDate']) ? $consignments[$j]['consignmentDate'] : $this->error_response('Error: consignmentDate is not set.');
                $consignmentTime = isset($consignments[$j]['consignmentTime']) ? $consignments[$j]['consignmentTime'] : $this->error_response('Error: consignmentTime is not set.');

                $supportModel = new Support_model();
                $manifestData = $supportModel->getManifestDetails($consignmentNumber,$destinationId);
                if($manifestData){
                    $modeId = $manifestData['MODE_ID'];
                    $documentId = $manifestData['DOCUMENT_ID'];
                    $originOfficeId = $manifestData['ORIG_BRNCH_ID'];
                    $manifestTypeId = $manifestData['MNFST_TYPE_ID'];
                    $manifestTypeDefinition = $manifestData['MANIFEST_TYPE_DEFN'];
                } else {
	                $originOfficeId = $destinationId;
	                $manifestTypeId = 5;
	                $modeId = 1;
	                $documentId = 1;
	                $manifestTypeDefinition = 'BMD';
                }

                //Chances of NULL

                //hardcoded values
                $manifestStatus = 'M';
                $manifestType = 'I';

                $db_server = 'N';

	            $query_save_incoming_bag_manifest = array(
	            	'MANIFEST_DATE' => $manifestDate,
		            'MANIFEST_TIME' => $manifestTime,
		            'MANIFEST_NUMBER' => $manifestNumber,
		            'CONSG_NUMBER' => $consignmentNumber,
		            'TOT_WEIGHT_KGS' => $totalWeightKgs,
		            'DOCUMENT_ID' => $documentId,
		            'DEPS_CATEGORY' => $depsCategory,
		            'INDV_WEIGHT_KGS' => $individualWeightKgs,
		            'ORIG_BRNCH_ID' => $originOfficeId,
		            'DEST_BRNCH_ID' => $destinationId,
		            'EMPLOYEE_ID' => $employeeId,
		            'MNFST_TYPE_ID' => $manifestTypeId,
		            'DB_SERVER' => $db_server,
		            'NO_OF_PACKETS' => $totalNoOfPackets,
		            'RECV_OFFICE_ID' => $destinationId,
		            'DESP_BRNCH_OFF' => $originOfficeId,
		            'MNFST_STATUS' => $manifestStatus,
		            'MANIFEST_TYPE' => $manifestType,
		            'MANIFEST_TYPE_DEFN' => $manifestTypeDefinition,
		            'WEIGHING_TYPE' => $weighingType,
		            'TRANS_CREATE_DATE' => $transactionDate,
		            'TRANS_LAST_MODIFIED_DATE' => $transactionDate,
		            'USER_ID' => $userId,
		            'NODE_ID' => $nodeId,
		            'MODE_ID' => $modeId,
		            'RECORD_ENTRY_DATETIME' => $central_server_date_time,
		            'ARRIVAL_DATE_TIME' => $central_server_date_time,
		            'WAR_DATE' => $warDate
	            );

//                $query_save_incoming_bag_manifest = "insert into dtdc_f_manifest" .
//                    "(MANIFEST_DATE," .
//                    "MANIFEST_TIME," .
//                    "MANIFEST_NUMBER," .
//                    "CONSG_NUMBER," .
//                    "TOT_WEIGHT_KGS," .
//                    "DOCUMENT_ID," .
//                    "DEPS_CATEGORY," .
//                    "INDV_WEIGHT_KGS," .
//                    "ORIG_BRNCH_ID," .
//                    "DEST_BRNCH_ID," .
//                    "EMPLOYEE_ID," .
//                    "MNFST_TYPE_ID," .
//                    "DB_SERVER," .
//                    "NO_OF_PACKETS," .
//                    "RECV_OFFICE_ID," .
//                    "DESP_BRNCH_OFF," .
//                    "MNFST_STATUS," .
//                    "MANIFEST_TYPE," .
//                    "MANIFEST_TYPE_DEFN," .
//                    "WEIGHING_TYPE," .
//                    "TRANS_CREATE_DATE," .
//                    "TRANS_LAST_MODIFIED_DATE," .
//                    "USER_ID," .
//                    "NODE_ID," .
//                    "RECORD_ENTRY_DATETIME," .
//                    "ARRIVAL_DATE_TIME) values ('"
//                    . $manifestDate . "','"
//                    . $manifestTime . "','"
//                    . $manifestNumber . "','"
//                    . $consignmentNumber . "',"
//                    . $totalWeightKgs . ","
//                    . $documentId . ",'"
//                    . $depsCategory . "',"
//                    . $individualWeightKgs . ","
//                    . $originOfficeId . ","
//                    . $destinationId . ","
//                    . $employeeId . ",$manifestTypeId,'"
//                    // .$manifestTypeId."','"
//                    . $db_server . "',"
//                    . $totalNoOfPackets . ","
//                    . $destinationId . ","
//                    . $destinationId . ",'"
//                    . $manifestStatus . "','"
//                    . $manifestType . "','"
//                    . $manifestTypeDefinition . "','"
//                    . $weighingType . "','"
//                    . $transactionDate . "','"
//                    . $transactionDate . "',"
//                    . $userId . ",'"
//                    . $nodeId . "','"
//                    . $central_server_date_time . "','"
//                    . $central_server_date_time . "')";

                if (!$this->count_consgn_numbers_in_dtdc_f_manifest($consignmentNumber, $manifestType, $destinationId)) {

                    if ($this->db->insert('dtdc_f_manifest',$query_save_incoming_bag_manifest)) {
                        array_push($save_response, $consignmentNumber);
                    } else {
                        $this->error_response('Query failed while saving');
                    }
                } else {
                    array_push($duplicate_response, $consignmentNumber);
                }
            }
            array_push($manifest_numbers_to_delete_array, $manifestNumber);
        }
        $response = array(
            'status' => 1,
            'manifest_numbers_to_delete' => $manifest_numbers_to_delete_array,
            'saved' => $save_response,
            'duplicates' => $duplicate_response
        );

        return $response;
    }

    public function getManifestNumberFromConsignment($consg_number, $dest_branch_id)
    {
        $sql = "select MANIFEST_NUMBER  from dtdc_f_manifest where CONSG_NUMBER = ? and MANIFEST_TYPE = 'O' and DEST_BRNCH_ID = ?";
        $query = $this->db->query($sql, [$consg_number, $dest_branch_id]);
        if ($query->num_rows() > 0) {
            $result = $query->result_array()[0];

            return $result['MANIFEST_NUMBER'];
        } else {
            $date_obj = $this->date_obj;

            return 'Y' . $date_obj->format('dmHis');
        }
    }

    public function getManifestNumberFromConsignmentForIPM($consg_number, $dest_branch_id, $office_code, $first_value_office)
    {
        $sql = "select MANIFEST_NUMBER, TOT_WEIGHT_KGS, ORIG_BRNCH_ID, MODE_ID,
                       REP_OFF_ID,DEST_CITY_ID,DEST_PINCODE,HANDLE_INST_ID,TOT_WGHT_PACKETS,
                       DESP_REG_OFF,LINE_ITEM_SEQ_NO,FR_SYNC,WVC_FLAG,SERVICE_ID,PRODUCT_ID
                       from dtdc_f_manifest where CONSG_NUMBER = ? and MANIFEST_TYPE = 'O' and DEST_BRNCH_ID = ?
  UNION
  select MANIFEST_NUMBER, TOT_WEIGHT_KGS, ORIG_BRNCH_ID, MODE_ID,
                       REP_OFF_ID,DEST_CITY_ID,DEST_PINCODE,HANDLE_INST_ID,TOT_WGHT_PACKETS,
                       DESP_REG_OFF,LINE_ITEM_SEQ_NO,FR_SYNC,WVC_FLAG,SERVICE_ID,PRODUCT_ID
                       from dtdc_f_manifest where CONSG_NUMBER = ? and MANIFEST_TYPE = 'O' and DEST_BRNCH_ID IN ( SELECT OFFICE_ID FROM dtdc_d_office WHERE PRIN_PLACE_OF_BUSINESS= ? AND LEFT(OFFICE_CODE,1)= ? AND OFFICE_NAME LIKE '%T/S%'  AND BRANCH_NUM_CODE IS NOT NULL ) ";
        $query = $this->db->query($sql, [$consg_number, $dest_branch_id,$consg_number, $office_code, $first_value_office]);
        if ($query->num_rows() > 0) {
            $result = $query->result_array()[0];

            return $result;
        } else {
            return [];
        }
    }

 

    public function getOriginDetailsFromBookingForIPM($consg_number)
    {
        $sql = "select BRNCH_OFF_ID, MODE_ID from dtdc_f_booking where CONSG_NUMBER = ?";
        $query = $this->db->query($sql, [$consg_number]);
        if ($query->num_rows() > 0) {
            $result = $query->result_array()[0];

            return $result;
        } else {
            return [];
        }
    }

    public function generateYSeriesManifestNumber()
    {
        $date_obj = $this->date_obj;

        return 'Y' . $date_obj->format('dmHis');
    }


    public function get_origin_branch_id_from_consignment_number($consignmentNumber, $loggedInOfficeId)
    {
        $query = "select orig_brnch_id from dtdc_ctbs_plus.dtdc_f_manifest where CONSG_NUMBER = ? and manifest_type = 'O' and dest_brnch_id = ?";
        $result = $this->db->query($query,[$consignmentNumber,$loggedInOfficeId]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();

            return $result_array[0]['orig_brnch_id'];
        } else {
            return null;
        }
    }

    public function get_origin_id_from_branch_id($branch_id)
    {
        $query = "SELECT OFFICE_ID FROM dtdc_d_office where BRANCH_NUM_CODE = ?";
        // echo $query;
        $result = $this->db->query($query,[$branch_id]);
        if ($result->num_rows() > 0) {
            $origin_office_id_array = $result->result_array();
            $originOfficeId = $origin_office_id_array[0]['OFFICE_ID'];
        } else {
            $originOfficeId = 'NOT_IN_DTDC_D_OFFICE';
        }

        return $originOfficeId;
    }

    public function get_origin_branch_id_from_dtdc_f_manifest($manifestNumber, $destinationId)
    {
        if (!$destinationId) {
            $query = "SELECT ORIG_BRNCH_ID from dtdc_f_manifest wheRE manifest_nuMBER = '".$this->db->escape_str($manifestNumber)."' AND MANIFEST_TYPE='O'";
        } else {
            $query = "SELECT ORIG_BRNCH_ID from dtdc_f_manifest wheRE manifest_nuMBER = '".$this->db->escape_str($manifestNumber)."' AND MANIFEST_TYPE='O' AND DEST_BRNCH_ID='".$this->db->escape_str($destinationId)."' LIMIT 1";
        }

        // echo $query;
        $result = $this->db->query($query);
        try {
            if ($result->num_rows() > 0) {
                $result_array = $result->result_array();

                return $result_array[0]['ORIG_BRNCH_ID'];
            } else {
                return false;
            }
        } catch (Exception $e) {
            $this->error_response($e->getMessage());
        }
    }

    public function get_manifest_code($manifestTypeId)
    {
        $query = "select mnfst_code from dtdc_d_mnfst_type where mnfst_type_id = ?";
        $result = $this->db->query($query,[$manifestTypeId]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();

            return $result_array[0]['mnfst_code'];
        } else {
            return null;
        }
    }

    public function get_document_id_from_manifest($consg_Number)
    {
        // if $document_id = 'null', ddc_f_manifest , mainfest_type = '0' where cons_number = 'form ui'
        // $query = "select document_id from dtdc_f_manifest where manifest_type = 'O' and consg_number = 'N96836384'";
        $query = "SELECT DOCUMENT_ID FROM dtdc_f_manifest WHERE MANIFEST_TYPE = 'O' AND CONSG_NUMBER = ? LIMIT 1";
        $result = $this->db->query($query,[$consg_Number]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();

            return $result_array[0]['DOCUMENT_ID'];
        } else {
            return false;
        }
    }

    public function count_consgn_numbers_in_dtdc_f_manifest($consignmentNumber, $manifestType, $destOfficeId)
    {
        $query = "select * from dtdc_f_manifest where consg_number = ?  and manifest_type = ? and dest_brnch_id = ?";
        // $query = "select * from dtdc_f_manifest where consg_number = ? and manifest_number = ? and manifest_type = ? and dest_brnch_id = ?";
        $result = $this->db->query($query,[$consignmentNumber, $manifestType, $destOfficeId]);
        if ($result->num_rows() > 0) {
            return $result->num_rows();
        }
        return false;
    }

    public function saveincomingpacketmanifest($input)
    {
        $central_server_date = $this->date;
        $central_server_time = $this->time;
        $central_server_date_time = $central_server_date . " " . $central_server_time;
        $save_response = array();
        $duplicate_response = array();
        $manifest_numbers_to_delete_array = array();
        $CI =& get_instance();
        $CI->load->model('User_model');
        /*foreach ($input as $key => $value) {
            try {
                if (empty($value) && ($value != "0")) {
                    throw new Exception("Error Processing Request " . $key . " is required.", 1);
                }
            } catch (Exception $e) {
                $this->error_response($e->getMessage());
                exit;
            }
        }*/

        $userId = isset($input['userId']) ? $input['userId'] : $this->error_response('Error: Expected userId from received data');
        $employeeId = isset($input['employeeId']) ? $input['employeeId'] : $this->error_response('Incomplete input: employeeId not received.');
        $officeCode = isset($input['officeCode']) ? $input['officeCode'] : $this->error_response('Incomplete input: officeCode not received.');
        $firstOfficeCode = isset($input['firstOfficeCode']) ? $input['firstOfficeCode'] : $this->error_response('Incomplete input: officeCode not received.');
        $officeType = isset($input['officeType']) ? $input['officeType'] : $this->error_response('Incomplete input: officeType not received.');
        $warDate = isset($input['warDate']) ? $input['warDate'] : $this->error_response('Incomplete input: warDate not received.');
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
        $destinationId = isset($input['destinationId']) ? $input['destinationId'] : $this->error_response('');
        $transactionTime = isset($input['transactionTime']) ? $input['transactionTime'] : $this->error_response('Error: transactionTime is not set');
        $transactionDate = isset($input['transactionDate']) ? $input['transactionDate'] : $this->error_response('Error: transactionDate is not set');
        $nodeId = isset($input['nodeId']) ? $input['nodeId'] : $this->error_response('Error: nodeId is not set');
        $manifests = isset($input['manifests']) ? $input['manifests'] : $this->error_response('Error: manifests is not set.');
        for ($i = 0; $i < count($manifests); $i++) {
            /*foreach ($manifests[$i] as $key_manifests => $value_manifests) {
                try {
                    if (empty($value_manifests) && ($value_manifests != '0')) {
                        throw new Exception("Error Processing Request " . $key . " is required.", 1);
                    }
                } catch (Exception $e) {
                    $this->error_response($e->getMessage());
                }
            }*/
//			$manifestNumber = isset( $manifests[ $i ]['manifestNumber'] ) ? $manifests[ $i ]['manifestNumber'] : $this->error_response( 'Error: Manifest number not set.' );
            $totalWeightKgs = isset($manifests[$i]['totalWeightKgs']) ? $manifests[$i]['totalWeightKgs'] : $this->error_response('Error: totalWeightKgs is not set.');
            // $totalNoOfPackets = isset($manifests[$i]['totalNoOfPackets']) ? $manifests[$i]['totalNoOfPackets'] : $this->error_response('Error: totalNoOfPackets is not set.');
            $manifestOriginId = isset($manifests[$i]['manifestOriginId']) ? $manifests[$i]['manifestOriginId'] : $this->error_response('Error: manifestOriginId is not set.');
            $skip = isset($manifests[$i]['skip']) ? $manifests[$i]['skip'] : 'false';
            $manifestDestinationId = isset($manifests[$i]['manifestDestinationId']) ? $manifests[$i]['manifestDestinationId'] : $this->error_response('Error: manifestDestinationId is not set.');
            $manifestDate = isset($manifests[$i]['manifestDate']) ? $manifests[$i]['manifestDate'] : $this->error_response('Error: manifestDate is not set.');
            $manifestTime = isset($manifests[$i]['manifestTime']) ? $manifests[$i]['manifestTime'] : $this->error_response('Error: manifestTime is not set.');
            //$weighingType = isset($manifests[$i]['weighingType']) ? $manifests[$i]['weighingType'] : $this->error_response('Error: weighingType is not set.');
            $headerManifestTypeId = isset($manifests[$i]['headerManifestTypeId']) ? $manifests[$i]['headerManifestTypeId'] : $this->error_response('Error: headerManifestTypeId is not set.');
            $consignments = isset($manifests[$i]['consignments']) ? $manifests[$i]['consignments'] : $this->error_response('Error: consignments is not set.');

            //Replacing manifestDate, manifestTime
            $manifestDate = $central_server_date;
            $manifestTime = $central_server_time;

            $tot_consg_num = count($consignments);
            //TOT_CONSG_NUM
            for ($j = 0; $j < count($consignments); $j++) {
                /*foreach ($consignments[$j] as $key_consignments => $value_consigments) {
                    try {
                        if (empty($value_consigments) && ($value_consigments != "0")) {
                            throw new Exception("Error Processing Request " . $key_consignments . " is required.", 1);
                        }
                    } catch (Exception $e) {
                        $this->error_response($e->getMessage());
                    }
                }*/
                $consignmentNumber = isset($consignments[$j]['consignmentNumber']) ? $consignments[$j]['consignmentNumber'] : $this->error_response('Error: consignmentNumber is not set.');
                $remarks = $consignments[$j]['remarks'];
                $weighingType = $consignments[$j]['weightEntryType'];
                $descGoods = $consignments[$j]['descGoods'] ? $consignments[$j]['descGoods'] : null;
                $pincode = $consignments[$j]['pincode'];
                $isAutoinScan = $consignments[$j]['isAutoInscan'];
                $ewb_status = $consignments[$j]['ewb_status'];
                if($ewb_status){

                    if ($this->checkConsignIsEway($consignmentNumber)) {

                        if (!$this->checkEwbDataExists($consignmentNumber, $destinationId)) {
                            $this->insertIntoEwbTableUpdateData($consignmentNumber, $destinationId, $userId, 'CD IN SCAN');
                        }

                    }
                }

                //Get the origBranchId from the device
                $origBranchId = $consignments[$j]['origBranchId'] ? $consignments[$j]['origBranchId'] : null;
                $individualWeightKgs = isset($consignments[$j]['individualWeightKgs']) ? $consignments[$j]['individualWeightKgs'] : $this->error_response('Error: individualWeightKgs is not set.');

                $result = $this->getManifestNumberFromConsignmentForIPM($consignmentNumber, $destinationId, $officeCode, $firstOfficeCode );

                if (count($result) == 0) {
                    $manifestNumber = $this->generateYSeriesManifestNumber();
                    $result2 = $this->getOriginDetailsFromBookingForIPM($consignmentNumber);
                    if (count($result2) > 0) {
                        $origBranchId = $result2['BRNCH_OFF_ID'];
                        $modeId = $result2['MODE_ID'];
                    } else {
                        $origBranchId = $origBranchId ? $origBranchId : $destinationId;
                        $modeId = 1;
                    }
                    $totalWeightKgs = $individualWeightKgs;
                } else {
                    $manifestNumber = $result['MANIFEST_NUMBER'];
                    $totalWeightKgs = $result['TOT_WEIGHT_KGS'];
                    //If data avaialbe replace the value sent by device
                    $origBranchId = $result['ORIG_BRNCH_ID'];
                    $modeId = $result['MODE_ID'];
                }

                if (($individualWeightKgs == 'null') || ($individualWeightKgs == '0')) {
                    $individualWeightKgs = $this->get_individual_weights($consignmentNumber, $destinationId, 'O');
                }
                $depsCategory = isset($consignments[$j]['depsCategory']) ? $consignments[$j]['depsCategory'] : $this->error_response('Error: depsCategory is not set.');
                $consignmentOriginId = isset($consignments[$j]['consignmentOriginId']) ? $consignments[$j]['consignmentOriginId'] : $this->error_response('Error: consignmentOriginId is not set.');

//                if ($skip == 'true') {
//                    $originOfficeId = $this->get_origin_branch_id_from_consignment_number($consignmentNumber, $destinationId);
//                    // $originOfficeId = $this->get_origin_branch_id_from_dtdc_f_manifest($manifestNumber,false);
//                    if (!$originOfficeId) {
//                        $originOfficeId = 'null';
//                    }
//                } else {
//                    // $originOfficeId = $this->get_origin_id_from_branch_id($manifestOriginId);
//                    $originOfficeId = $this->get_origin_branch_id_from_consignment_number($consignmentNumber, $destinationId);
//                    // $originOfficeId = $this->get_origin_branch_id_from_dtdc_f_manifest($manifestNumber,false);
//                    if (!$originOfficeId) {
//                        $originOfficeId = 'null';
//                    }
//                    // $originOfficeId = $this->get_origin_branch_id_from_dtdc_f_manifest($manifestNumber,false);
//                    // if($originOfficeId == 'NOT_IN_DTDC_D_OFFICE'){
//                    //   $originOfficeId = $this->get_origin_branch_id_from_dtdc_f_manifest($manifestNumber,false);
//                    //   if(!$originOfficeId){
//                    //     $originOfficeId = 'null';
//                    //   }
//                    // }
//                }


                $consignmentDestinationId = isset($consignments[$j]['consignmentDestinationId']) ? $consignments[$j]['consignmentDestinationId'] : $this->error_response('Error: consignmentDestinationId is not set.');
                $manifestTypeId = isset($consignments[$j]['manifestTypeId']) ? $consignments[$j]['manifestTypeId'] : $this->error_response('Error: manifestTypeId is not set.');

                $documentId = isset($consignments[$j]['documentId']) ? $consignments[$j]['documentId'] : $this->error_response('Error: documentId is not set.');

                if ($documentId == '0') {
                    $documentId = $this->get_document_id_from_manifest($consignmentNumber);
                    if (!$documentId) {
                        $documentId = "null";
                    }
                }
                $consignmentDate = isset($consignments[$j]['consignmentDate']) ? $consignments[$j]['consignmentDate'] : $this->error_response('Error: consignmentDate is not set.');
                $consignmentTime = isset($consignments[$j]['consignmentTime']) ? $consignments[$j]['consignmentTime'] : $this->error_response('Error: consignmentTime is not set.');
                $action = isset($consignments[$j]['action']) ? $consignments[$j]['action'] : null;
                //hardcoded values
                $manifestStatus = 'M';
                $manifestType = 'I';
                $db_server = 'N';

                if ($manifestTypeId == '0') {
                    $manifestTypeId = null;
                }
                $manifestTypeDefinition = $this->get_manifest_code($manifestTypeId);
                if (!$manifestTypeDefinition) {
                    $manifestTypeDefinition = null;
                }
                $no_of_pieces = 1;
                // echo $destinationId;
                //NO_OF_PIECES

                if ($remarks == 1) {
                    $remarks = 'BVRL';
                } elseif ($remarks == 2) {
                    $processType = 'MANIFEST-I';
                    $CI->User_model->updateStatusCodeForConsignment($consignmentNumber, $officeCode, $userId, $nodeId, $officeType, $processType);
                    $remarks = 'DTCU';
                } else {
                    $remarks = null;
                }
                
                $packet_intact = null;
                $rep_off_id = null;
                $dest_city_id =  null;
                $handle_inst_id = null;
                $tot_wght_packets = null;
                $desp_reg_off = null;
                $line_item_seq = null;
                $fr_sync = null;
                $wvc_flag = null;
                $dest_branch_off = $destinationId;
                $service_id = null;
                $product_id = null;

                if($isAutoinScan == 1){
                    
                    $remarks = "AUTOINSCAN"; 
                    $packet_intact = "Y";
               
                }
                if($result){
                    $rep_off_id = $result['REP_OFF_ID'];
                    $dest_city_id =  $result['DEST_CITY_ID'];
                    $pincode = $result['DEST_PINCODE'];
                    $handle_inst_id = $result['HANDLE_INST_ID'];
                    $tot_wght_packets = $result['TOT_WGHT_PACKETS'];
                    if($tot_wght_packets == null){
                        $tot_wght_packets = $totalWeightKgs;
                    }
                    $desp_reg_off = $result['DESP_REG_OFF'];
                    if($desp_reg_off == null){
                        $desp_reg_off = $rep_off_id;
                    }
                    $line_item_seq = $j+1;
                    $fr_sync = $result['FR_SYNC'];
                    $wvc_flag = $result['WVC_FLAG'];
                    $service_id = $result['SERVICE_ID'];
                    $product_id = $result['PRODUCT_ID'];
            }

                    $query_save_incoming_bag_manifest_insert = array(
                        "MANIFEST_DATE" => $manifestDate,
                        "MANIFEST_TIME" => $manifestTime,
                        "MANIFEST_NUMBER" => $manifestNumber,
                        "CONSG_NUMBER" => $consignmentNumber,
                        "REMARKS" => $remarks,
                        "PACKET_INTACT" => $packet_intact,
                        "TOT_WEIGHT_KGS" => $totalWeightKgs,
                        "DEPS_CATEGORY" => $depsCategory,
                        "INDV_WEIGHT_KGS" => $individualWeightKgs,
                        "ORIG_BRNCH_ID" => $origBranchId,
                        "REP_OFF_ID" => $rep_off_id,
                        "DEST_BRNCH_ID" => $destinationId,
                        "DEST_CITY_ID" => $dest_city_id,
                        "DOCUMENT_ID" => $documentId,
                        "EMPLOYEE_ID" => $employeeId,
                        "MNFST_TYPE_ID" => $manifestTypeId,
                        "NO_OF_PIECES" => $no_of_pieces,
                        "TOT_CONSG_NUM" => $tot_consg_num,
                        "RECV_OFFICE_ID" => $destinationId,
                        "TOT_WGHT_PACKETS" => $tot_wght_packets,
                        "DESP_REG_OFF" => $desp_reg_off,
                        "LINE_ITEM_SEQ_NO" => $line_item_seq,
                        "FR_SYNC" => $fr_sync,
                        "WVC_FLAG" => $wvc_flag,
                        "DESP_BRNCH_OFF" => $dest_branch_off,
                        "MNFST_STATUS" => $manifestStatus,
                        "DB_SERVER" => $db_server,
                        "MANIFEST_TYPE" => $manifestType,
                        "MANIFEST_TYPE_DEFN" => $manifestTypeDefinition,
                        "WEIGHING_TYPE" => $weighingType,
                        "TRANS_CREATE_DATE" => $this->server_date_time,
                        "TRANS_LAST_MODIFIED_DATE" => $this->server_date_time,
                        "USER_ID" => $userId,
                        "NODE_ID" => $nodeId,
                        "WAR_DATE" => $warDate,
                        "MODE_ID" => $modeId,
                        "RECORD_ENTRY_DATETIME" => $this->server_date_time,
                        "ARRIVAL_DATE_TIME" => $this->server_date_time,
                        "DEST_PINCODE" => $pincode,
                        "HANDLE_INST_ID" => $handle_inst_id,
                        "SERVICE_ID" => $service_id,
                        "PRODUCT_ID" => $product_id,
                        "DESC_GOODS" => $descGoods,
                        "ACTION" => $action
                    );


                if (!$this->count_consgn_numbers_in_dtdc_f_manifest( $consignmentNumber, $manifestType, $destinationId)) {
                    $this->db->insert('dtdc_f_manifest', $query_save_incoming_bag_manifest_insert);
                    $insert_id = $this->db->insert_id();
                    if ($insert_id) {
                        array_push($save_response, $consignmentNumber);
                    } else {
                        $this->error_response('Something happened');
                    }
                } else {
                    array_push($duplicate_response, $consignmentNumber);
                }

            }
            array_push($manifest_numbers_to_delete_array, $manifestNumber);
        }
        $response = array(
            'status' => 1,
            'manifest_numbers_to_delete' => $manifest_numbers_to_delete_array,
            'saved' => $save_response,
            'duplicates' => $duplicate_response
        );

        return $response;
    }

    

    public function get_individual_weights($consignmentNumber, $officeId, $manifestType)
    {
        $query = "SELECT INDV_WEIGHT_KGS FROM dtdc_f_manifest WHERE CONSG_NUMBER= ? AND MANIFEST_TYPE= ? AND DEST_BRNCH_ID= ?";
        // echo $query;
        $result = $this->db->query($query,[$consignmentNumber,$manifestType,$officeId]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();

            return $result_array[0]['INDV_WEIGHT_KGS'];
        } else {
            return 0;
        }
    }

    public function savebdm($input)
    {
        $server_date = $this->date;
        $server_time = $this->time;

        $server_date_time = $server_date . ' ' . $server_time;
        $save_response = array();
        $duplicate_response = array();
        $runsheet_numbers_to_delete_array = array();

        $currentLoginInfo = $input['currentLoginInfo'];
        /*foreach ($currentLoginInfo as $key => $value) {
            try {
                if (empty($value) && ($value != "0")) {
                    throw new Exception("Error Processing Request " . $key . " is required.", 1);
                }
            } catch (Exception $e) {
                $this->error_response($e->getMessage());
                exit;
            }
        }*/
        $deviceMacAddress = isset($currentLoginInfo['deviceMacAddress']) ? $currentLoginInfo['deviceMacAddress'] : $this->error_response('Technical error: Missing key deviceMacAddress');
        $loginUserId = isset($currentLoginInfo['loginUserId']) ? $currentLoginInfo['loginUserId'] : $this->error_response('Technical error: Missing key loginUserId');
        $local_db_ip = isset($currentLoginInfo['local_db_ip']) ? $currentLoginInfo['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
        $transactionTime = isset($currentLoginInfo['transactionTime']) ? $currentLoginInfo['transactionTime'] : $this->error_response('Technical error: Missing key transactionTime');
        $transactionDate = isset($currentLoginInfo['transactionDate']) ? $currentLoginInfo['transactionDate'] : $this->error_response('Technical error: Missing key transactionDate');
        $loginUserOfficeId = isset($currentLoginInfo['loginUserOfficeId']) ? $currentLoginInfo['loginUserOfficeId'] : $this->error_response('Technical error: Missing key loginUserOfficeId');
        $vehicleNo = isset($currentLoginInfo['vehicleNo']) ? $currentLoginInfo['vehicleNo'] : null;
        $vehicleMode = isset($currentLoginInfo['vehicleMode']) ? $currentLoginInfo['vehicleMode'] : $this->error_response('Technical error: Missing key vehicleMode');

        $bdm = isset($input['bdm']) ? $input['bdm'] : $this->error_response('Technical error: Missing key bdm');

        foreach ($bdm as $run_sheet_key => $run_sheet_value) {
            $runSheetNumber = $run_sheet_key;
            $bdmConsignents = isset($run_sheet_value['bdmConsignents']) ? $run_sheet_value['bdmConsignents'] : $this->error_response('Technical error: Missing key bdmConsignents');
            $totalCns = isset($run_sheet_value['totalCns']) ? $run_sheet_value['totalCns'] : $this->error_response('Technical error: Missing key totalCns');
            $totalWeight = isset($run_sheet_value['totalWeight']) ? $run_sheet_value['totalWeight'] : $this->error_response('Expected totalWeight. This could be JSON key error.');
            $employeeCode = isset($run_sheet_value['employeeCode']) ? $run_sheet_value['employeeCode'] : $this->error_response('Expected employeeCode. This could be JSON key error.');
            $employeeId = $this->get_employee_id($employeeCode);
            $user_id = isset($run_sheet_value['userId']) ? $run_sheet_value['userId'] : $this->error_response('Expected userId. This could be JSON key error.');

            for ($i = 0; $i < count($bdmConsignents); $i++) {
                $captureTime = isset($bdmConsignents[$i]['captureTime']) ? $bdmConsignents[$i]['captureTime'] : $this->error_response('Technical error : Missing key captureTime');
                $captureDate = isset($bdmConsignents[$i]['captureDate']) ? $bdmConsignents[$i]['captureDate'] : $this->error_response('Technical error: Missing key captureDate');
                $codAmount = isset($bdmConsignents[$i]['codAmount']) ? $bdmConsignents[$i]['codAmount'] : NULL;
                $status = isset($bdmConsignents[$i]['status']) ? $bdmConsignents[$i]['status'] : $this->error_response('Technical error: Missing key status');
                $consigNumber = isset($bdmConsignents[$i]['consigNumber']) ? $bdmConsignents[$i]['consigNumber'] : $this->error_response('Technical error: Missing key consigNumber');
                $consigneeName = isset($bdmConsignents[$i]['consigneeName']) ? $bdmConsignents[$i]['consigneeName'] : $this->error_response('Technical error: Missing key consigneeName');
                $delivery_status = isset($bdmConsignents[$i]['deliveryStatus']) ? $bdmConsignents[$i]['deliveryStatus'] : $this->error_response('Technical error: Missing key deliveryStatus');
                $weight = isset($bdmConsignents[$i]['weight']) ? $bdmConsignents[$i]['weight'] : $this->error_response('Technical error: Missing key weight');
                $remarks = isset($bdmConsignents[$i]['remarks']) ? $bdmConsignents[$i]['remarks'] : null;
                $product_id = isset($bdmConsignents[$i]['product_id']) ? $bdmConsignents[$i]['product_id'] : $this->error_response('Technical error: Product id expected');
                if ($weight == '0') {
                    $weight = $this->getWeightForConsignment($consigNumber, $loginUserOfficeId);
                }

                if (empty($consigneeName)) {
                    $consigneeName = " ";
                }

                if (($weight == 'null') || ($weight == '0')) {
                    $weight = $this->get_individual_weights($consigNumber, $loginUserOfficeId, 'I');
                    /*if(is_null($weight) || empty($weight)){
                        $weight = 0.01;
                    }*/
                }

                $app_date_time = $captureDate . ' ' . $captureTime;
                //Replace with server date time
                $app_date_time = $this->server_date_time;
                // $delivery_status = 'O';
                $attempt_number = 1;
                $number_of_pieces = 1;
                $delivery_code = 'BDM';
                $no_of_pieces = 1;
                //$remarks          = 'N';
                $db_server = 'N';

                $attempt_result = $this->getAttemptNumberValue($consigNumber);
                if($attempt_result){
                    if($attempt_result[0]['ATTEMPT_NUMBER']!='' && $attempt_result[0]['ATTEMPT_NUMBER'] !=null)
                    {
                        $attempt_number = $attempt_result[0]['ATTEMPT_NUMBER']+1;
                    } 
                }


                /*$query_save_bdm = "insert into dtdc_f_delivery" .
                    "(DELIVERY_STATUS," .
                    "CONSIGNEE_NAME," .
                    "COD_AMOUNT," .
                    "CONSG_NUMBER," .
                    "CONSG_STATUS," .
                    "CONSG_WEIGHT," .
                    "TOTAL_NO_PIECES," .
                    "ATTEMPT_NUMBER," .
                    "RUN_SHEET_NUMBER," .
                    "TOTAL_WEIGHT," .
                    "REMARKS," .
                    "EMPLOYEE_ID," .
                    "OFFICE_ID," .
                    "REP_OFFICE_ID," .
                    "NO_OF_PIECES," .
                    "DB_SERVER," .
                    "DELIVERY_CODE," .
                    "PREPARATION_DATE_TIME," .
                    "TRANS_CREATE_DATE," .
                    "TRANS_LAST_MODIFIED_DATE," .
                    "USER_ID," .
                    "NODE_ID," .
                    "ARRIVAL_DATE_TIME) values ('"
                    . $delivery_status . "','"
                    . $consigneeName . "',"
                    . $codAmount . ",'"
                    . $consigNumber . "','"
                    . $status . "',"
                    . $weight . ","
                    . $totalCns . ","
                    . $attempt_number . ",'"
                    . $runSheetNumber . "',"
                    . $totalWeight . ",'"
                    . $remarks . "',"
                    . $employeeId . ","
                    . $loginUserOfficeId . ","
                    // .$totalNoOfPackets."','"
                    . $loginUserOfficeId . ","
                    . $no_of_pieces . ",'"
                    . $db_server . "','"
                    . $delivery_code . "','"
                    . $app_date_time . "','"
                    . $server_date_time . "','"
                    . $server_date_time . "',"
                    . $user_id . ",'"
                    . $deviceMacAddress . "','"
                    . $server_date_time . "')";*/

                $codig_insert_data = array(
                    "DELIVERY_STATUS" => $delivery_status,
                    "CONSIGNEE_NAME" => $consigneeName,
                    "COD_AMOUNT" => $codAmount,
                    "CONSG_NUMBER" => $consigNumber,
                    "CONSG_STATUS" => $status,
                    "CONSG_WEIGHT" => $weight,
                    "TOTAL_NO_PIECES" => $totalCns,
                    "ATTEMPT_NUMBER" => $attempt_number,
                    "RUN_SHEET_NUMBER" => $runSheetNumber,
                    "TOTAL_WEIGHT" => $totalWeight,
                    "REMARKS" => $remarks,
                    "EMPLOYEE_ID" => $employeeId,
                    "OFFICE_ID" => $loginUserOfficeId,
                    "REP_OFFICE_ID" => $loginUserOfficeId,
                    "NO_OF_PIECES" => $no_of_pieces,
                    "DB_SERVER" => $db_server,
                    "DELIVERY_CODE" => $delivery_code,
                    "PREPARATION_DATE_TIME" => $app_date_time,
                    "TRANS_CREATE_DATE" => $server_date_time,
                    "TRANS_LAST_MODIFIED_DATE" => $server_date_time,
                    "USER_ID" => $user_id,
                    "NODE_ID" => $deviceMacAddress,
                    "ARRIVAL_DATE_TIME" => $server_date_time,
                    "MANIFEST_DATE" => $server_date_time,
                    'PRODUCT_ID' => $product_id,
                    "DLV_FMEASURE1" => $vehicleNo,
                    "DLV_FMEASURE3" => $vehicleMode

                );

                /// if (!$this->count_consgn_numbers_in_dtdc_f_delivery($consigNumber) || $this->count_consgn_numbers_in_dtdc_f_delivery($consigNumber)) {
                if (!$this->count_consgn_numbers_in_dtdc_f_delivery($consigNumber, $loginUserOfficeId)) {
                    //if ($this->db->query($query_save_bdm)) {
                    if ($this->db->insert('dtdc_f_delivery', $codig_insert_data)) {
                        array_push($save_response, $consigNumber);
                    } else {
                        $this->error_response('Error!');
                    }
                } else {
                    array_push($duplicate_response, $consigNumber);
                }
            }
            array_push($runsheet_numbers_to_delete_array, $runSheetNumber);
        }
        $response = array(
            'status' => 1,
            'runsheet_numbers_to_delete' => $runsheet_numbers_to_delete_array,
            'saved' => $save_response,
            'duplicates' => $duplicate_response
        );

        return $response;
    }

    public function get_employee_id($emp_code)
    {
        $query = "select employee_id from dtdc_d_employee where emp_code = ?";
        $result = $this->db->query($query,[$emp_code]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();

            return $result_array[0]['employee_id'];
        } else {
            return null;
        }
    }

    //FDM

    public function getWeightForConsignment($consignment_number, $logged_in_office_id)
    {
        $sql = "(select FINAL_WEIGHT from dtdc_f_booking where CONSG_NUMBER = ?)
                union
                (select INDV_WEIGHT_KGS from dtdc_f_manifest where DEST_BRNCH_ID = ? and CONSG_NUMBER = ? and MANIFEST_TYPE = 'I')
                union
                (select PHY_WEIGHT from dtdc_f_cd_recv_mnfst_dtls where DEST_OFFICE_ID = ? and BAG_MANIFEST_NUMBER = ?) order by FINAL_WEIGHT asc";

        $query = $this->db->query($sql, [
            $consignment_number,
            $logged_in_office_id,
            $consignment_number,
            $logged_in_office_id,
            $consignment_number
        ]);
        if ($query->num_rows() > 0) {
            return $query->result_array()[0]['FINAL_WEIGHT'];
        } else {
            return null;
        }
    }

    public function count_consgn_numbers_in_dtdc_f_delivery($consigNumber, $loginUserOfficeId)
    {
        $query = "select DELIVERY_STATUS from dtdc_f_delivery where CONSG_NUMBER = ? AND consg_status='A' and DELIVERY_STATUS in ('O','P')
        and office_id = ? ";
        // $query = "select * from dtdc_f_delivery where consg_number = ?";
        $result = $this->db->query($query,[$consigNumber, $loginUserOfficeId]);

        return $result->num_rows();
    }

    public function savefdm($input)
    {
        $server_date = $this->date;
        $server_time = $this->time;

        $server_date_time = $server_date . ' ' . $server_time;

        $currentLoginInfo = $input['currentLoginInfo'];
        /*foreach ($currentLoginInfo as $key => $value) {
            try {
                if (empty($value) && ($value != "0")) {
                    throw new Exception("Error Processing Request " . $key . " is required.", 1);
                }
            } catch (Exception $e) {
                $this->error_response($e->getMessage());
                exit;
            }
        }*/
        $deviceMacAddress = isset($currentLoginInfo['deviceMacAddress']) ? $currentLoginInfo['deviceMacAddress'] : $this->error_response('Technical error: Missing key deviceMacAddress');
        $loginUserId = isset($currentLoginInfo['loginUserId']) ? $currentLoginInfo['loginUserId'] : $this->error_response('Technical error: Missing key loginUserId');
        $local_db_ip = isset($currentLoginInfo['local_db_ip']) ? $currentLoginInfo['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        $warDate     = isset($currentLoginInfo['warDate']) ? $currentLoginInfo['warDate'] : null;

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
        $transactionTime = isset($currentLoginInfo['transactionTime']) ? $currentLoginInfo['transactionTime'] : $this->error_response('Technical error: Missing key transactionTime');
        $transactionDate = isset($currentLoginInfo['transactionDate']) ? $currentLoginInfo['transactionDate'] : $this->error_response('Technical error: Missing key transactionDate');
        $loginUserOfficeId = isset($currentLoginInfo['loginUserOfficeId']) ? $currentLoginInfo['loginUserOfficeId'] : $this->error_response('Technical error: Missing key loginUserOfficeId');
        //$frCode = isset($currentLoginInfo['frCode']) ? $currentLoginInfo['frCode'] : $this->error_response('Technical error: Missing key frCode');


        $fdm = isset($input['fdm']) ? $input['fdm'] : $this->error_response('Technical error: Missing key bdm');

        $fdm_response_insert_array = array();
        $fdm_response_update_array = array();
        foreach ($fdm as $run_sheet_key => $run_sheet_value) {

            //runSheetNumber is fdmNumber
            $runSheetNumber = $run_sheet_key;
            $fdmConsignents = isset($run_sheet_value['fdmConsignents']) ? $run_sheet_value['fdmConsignents'] : $this->error_response('Technical error: Missing key fdmConsignents');
            $totalCns = isset($run_sheet_value['totalCns']) ? $run_sheet_value['totalCns'] : $this->error_response('Technical error: Missing key totalCns');
            $totalWeight = isset($run_sheet_value['totalWeight']) ? $run_sheet_value['totalWeight'] : $this->error_response('Expected totalWeight. This could be JSON key error.');
            $delivery_status = isset($run_sheet_value['deliveryStatus']) ? $run_sheet_value['deliveryStatus'] : $this->error_response('Expected deliveryStatus. This could be JSON key error.');
            $frCode = isset($run_sheet_value['frCode']) ? $run_sheet_value['frCode'] : $this->error_response('Expected frCode. This could be JSON key error.');
            $cutOff = isset($run_sheet_value['cutOff']) ? $run_sheet_value['cutOff'] : $this->error_response('Expected cutOff. This could be JSON key error.');
            $repOfficeId = isset($run_sheet_value['repOfficeId']) ? $run_sheet_value['repOfficeId'] : $this->error_response('Expected repOfficeId. This could be JSON key error.');
            $get_franchisee_id_query = "SELECT FRANCHISEE_ID FROM dtdc_d_franchisee WHERE FRANCHISEE_CODE = '$frCode' limit 1";

            $result_franchisee_id_object = $this->db->query($get_franchisee_id_query);

            $fr_result =  $this->getFRDelivery($frCode);

            if ($result_franchisee_id_object->num_rows() > 0) {
                $franchisee_id_array = $result_franchisee_id_object->result_array();

                $franchiseeId = $franchisee_id_array[0]['FRANCHISEE_ID'];
                // echo $franchiseeId;
            } else {
                $franchiseeId = 1;
            }

            $dateObj = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $handover_num = $franchiseeId.$dateObj->format('dmyHis');

            

            if ($this->check_fdm_in_database($runSheetNumber)) {
                if ($this->update_fdm_in_database($delivery_status, $runSheetNumber, $fdmConsignents)) {
                    array_push($fdm_response_update_array, $runSheetNumber);
                }
            } else {

                for ($i = 0; $i < count($fdmConsignents); $i++) {
                    $captureTime = isset($fdmConsignents[$i]['captureTime']) ? $fdmConsignents[$i]['captureTime'] : $this->error_response('Technical error : Missing key captureTime');
                    $weight = isset($fdmConsignents[$i]['weight']) ? $fdmConsignents[$i]['weight'] : $this->error_response('Technical error: Missing key weight');
                    $captureDate = isset($fdmConsignents[$i]['captureDate']) ? $fdmConsignents[$i]['captureDate'] : $this->error_response('Technical error: Missing key captureDate');
                    $codAmount = isset($fdmConsignents[$i]['codAmount']) ? $fdmConsignents[$i]['codAmount'] : NULL;
                    $status = isset($fdmConsignents[$i]['status']) ? $fdmConsignents[$i]['status'] : $this->error_response('Technical error: Missing key status');
                    $consigNumber = isset($fdmConsignents[$i]['consigNumber']) ? $fdmConsignents[$i]['consigNumber'] : $this->error_response('Technical error: Missing key consigNumber');
                    $delivery_status_child = isset($fdmConsignents[$i]['deliveryStatusChild']) ? $fdmConsignents[$i]['deliveryStatusChild'] : $this->error_response('Expected deliveryStatusChild. This could be JSON key error.');
                    $remarks = isset($fdmConsignents[$i]['remarks']) ? $fdmConsignents[$i]['remarks'] : null;
                    $product_id = isset($fdmConsignents[$i]['product_id']) ? $fdmConsignents[$i]['product_id'] : $this->error_response('Expected Product id.');
                    $fr_delivery = isset($fdmConsignents[$i]['fr_delivery']) ? $fdmConsignents[$i]['fr_delivery'] : $this->error_response('Technical error: fr_delivery should not be null');
                    $app_date_time = $captureDate . ' ' . $captureTime;
                    $app_date_time = $this->server_date_time;
                   
                    $pincodeId = isset($fdmConsignents[$i]['pincodeId']) ? $fdmConsignents[$i]['pincodeId'] : null;
                    // $delivery_status = ;
                    $attempt_number = 1;
                    $number_of_pieces = 1;
                    $delivery_code = 'FDM';
                    $no_of_pieces = 1;
                    $db_server = 'N';

                    ///$product_id = null;
                    $document_id = null;
                    $service_id = null;
                    $serviceDetails = $this->getServiceProductDocumentDetails($consigNumber,$loginUserOfficeId);
                   
                    if($serviceDetails){
                        $service_id  = $serviceDetails[0]['SERVICE_ID'];
                        $document_id = $serviceDetails[0]['DOCUMENT_ID'];
                     // $product_id = $serviceDetails[0]['PRODUCT_ID'];
                    }else{
                        $document_id = '2';
                    }

                    if ($weight == '0') {
                        $weight = $this->getWeightForConsignment($consigNumber, $loginUserOfficeId);
                        /*if(is_null($weight) || empty($weight)){
                            $weight = 0.01;
                        }*/
                    }

                    if($this->isConsgNumberExists($consigNumber)){
                          $this->updateDeliveryStatus($consigNumber);
                    }


                    if ($delivery_status == 'O') {
                        if ($this->getFranchiseeAdmStatus($frCode)) {
                            return $this->error_response('FDM handover is not allowed for ADM codes');
                        }
                        /*$query_save_fdm = "insert into dtdc_f_delivery" .
                            "(DELIVERY_STATUS," 
                            "COD_AMOUNT," .
                            "CONSG_NUMBER," .
                            "CONSG_STATUS," .
                            "CONSG_WEIGHT," .
                            "TOTAL_NO_PIECES," .
                            "ATTEMPT_NUMBER," .
                            // "RUN_SHEET_NUMBER,".
                            "CONSG_COUNT," .
                            "TOTAL_WEIGHT," .
                            "HANDOVER_DATE_TIME," .
                            "MANIFEST_DATE," .
                            "USER_ID," .
                            "OFFICE_ID," .
                            "REP_OFFICE_ID," .
                            "FRANCHISEE_ID," .
                            "FDM_NUMBER," .
                            "NO_OF_PIECES," .
                            "DB_SERVER," .
                            "DELIVERY_CODE," .
                            "PREPARATION_DATE_TIME," .
                            "TRANS_CREATE_DATE," .
                            "TRANS_LAST_MODIFIED_DATE," .
                            // "USER_ID,".
                            "NODE_ID," .
                            "HANDOVER_NUM," .
                            "CUTOFF," .
                            "ARRIVAL_DATE_TIME," .
                            "REMARKS) values ('"
                            . $delivery_status_child . "',"
                            . $codAmount . ",'"
                            . $consigNumber . "','"
                            . $status . "',"
                            . $weight . ","
                            . $totalCns . ","
                            . $attempt_number . ","
                            // .$runSheetNumber."','"
                            . $totalCns . ","
                            . $totalWeight . ",'"
                            . $app_date_time . "','"
                            . $app_date_time . "',"
                            . $loginUserId . ","
                            . $loginUserOfficeId . ","
                            // .$totalNoOfPackets."','"
                            . $repOfficeId . ",'"
                            . $franchiseeId . "','"
                            . $runSheetNumber . "',"
                            . $no_of_pieces . ",'"
                            . $db_server . "','"
                            . $delivery_code . "','"
                            . $app_date_time . "','"
                            . $server_date_time . "','"
                            . $server_date_time . "','"
                            // .$loginUserId.",'"
                            . $deviceMacAddress . "','"
                            . $runSheetNumber . "','"
                            . $cutOff . "','"
                            . $server_date_time . "','"
                            . $remarks .
                            "')";*/
                        $codig_insert_data = array(
                            "DELIVERY_STATUS" => $delivery_status_child,
                            "COD_AMOUNT" => $codAmount,
                            "CONSG_NUMBER" => $consigNumber,
                            "CONSG_STATUS" => $status,
                            "CONSG_WEIGHT" => $weight,
                            "TOTAL_NO_PIECES" => $totalCns,
                            "ATTEMPT_NUMBER" => $attempt_number,
                            "CONSG_COUNT" => $totalCns,
                            "TOTAL_WEIGHT" => $totalWeight,
                            "HANDOVER_DATE_TIME" => $app_date_time,
                            "MANIFEST_DATE" => $server_date_time,
                            "USER_ID" => $loginUserId,
                            "OFFICE_ID" => $loginUserOfficeId,
                            "REP_OFFICE_ID" => $repOfficeId,
                            "FRANCHISEE_ID" => $franchiseeId,
                            "FDM_NUMBER" => $runSheetNumber,
                            "NO_OF_PIECES" => $no_of_pieces,
                            "DB_SERVER" => $db_server,
                            "DELIVERY_CODE" => $delivery_code,
                            "PREPARATION_DATE_TIME" => $app_date_time,
                            "TRANS_CREATE_DATE" => $server_date_time,
                            "TRANS_LAST_MODIFIED_DATE" => $server_date_time,
                            // "USER_ID,".
                            "NODE_ID" => $deviceMacAddress,
                            "HANDOVER_NUM" => $handover_num,
                            "CUTOFF" => $cutOff,
                            "ARRIVAL_DATE_TIME" => $server_date_time,
                            "DEST_PINCODE_ID" => $pincodeId,
                            "REMARKS" => $remarks,
                            "WAR_DATE" => $warDate,
                            "SERVICE_ID" => $service_id,
                            "PRODUCT_ID" => $product_id,
                            "DOCUMENT_ID" => $document_id,
                            "FDM_PREPARED_USER_ID" => $loginUserId,
                            "DEST_24_48" => $fr_delivery

                        );
                    }

                    if ($delivery_status == 'P') {

                         $handover_date_time = null;
                        
                        $attempt_result = $this->getAttemptNumberValue($consigNumber);
                        if($attempt_result){
                            if($attempt_result[0]['ATTEMPT_NUMBER']!='' && $attempt_result[0]['ATTEMPT_NUMBER'] !=null)
                            {
                                $attempt_number = $attempt_result[0]['ATTEMPT_NUMBER']+1;
                            } 
                        }

                     
                        /*$query_save_fdm = "insert into dtdc_f_delivery" .
                            "(DELIVERY_STATUS," .
                            "COD_AMOUNT," .
                            "CONSG_NUMBER," .
                            "CONSG_STATUS," .
                            "CONSG_WEIGHT," .
                            "TOTAL_NO_PIECES," .
                            "ATTEMPT_NUMBER," .
                            // "RUN_SHEET_NUMBER,".
                            "CONSG_COUNT," .
                            "TOTAL_WEIGHT," .
                            "HANDOVER_DATE_TIME," .
                            "MANIFEST_DATE," .
                            "USER_ID," .
                            "OFFICE_ID," .
                            "REP_OFFICE_ID," .
                            "FRANCHISEE_ID," .
                            "FDM_NUMBER," .
                            "NO_OF_PIECES," .
                            "DB_SERVER," .
                            "DELIVERY_CODE," .
                            "PREPARATION_DATE_TIME," .
                            "TRANS_CREATE_DATE," .
                            "TRANS_LAST_MODIFIED_DATE," .
                            // "USER_ID,".
                            "NODE_ID," .
                            "CUTOFF," .
                            "ARRIVAL_DATE_TIME) values ('"
                            . $delivery_status_child . "',"
                            . $codAmount . ",'"
                            . $consigNumber . "','"
                            . $status . "',"
                            . $weight . ","
                            . $totalCns . ","
                            . $attempt_number . ","
                            // .$runSheetNumber."','"
                            . $totalCns . ","
                            . $totalWeight . ",'"
                            . $app_date_time . "','"
                            . $app_date_time . "',"
                            . $loginUserId . ","
                            . $loginUserOfficeId . ","
                            // .$totalNoOfPackets."','"
                            . $repOfficeId . ",'"
                            . $franchiseeId . "','"
                            . $runSheetNumber . "',"
                            . $no_of_pieces . ",'"
                            . $db_server . "','"
                            . $delivery_code . "','"
                            . $app_date_time . "','"
                            . $server_date_time . "','"
                            . $server_date_time . "','"
                            // .$loginUserId.",'"
                            . $deviceMacAddress . "','"
                            . $cutOff . "','"
                            . $server_date_time . "')";*/

                        $codig_insert_data = array(
                            "DELIVERY_STATUS" => $delivery_status_child,
                            "COD_AMOUNT" => $codAmount,
                            "CONSG_NUMBER" => $consigNumber,
                            "CONSG_STATUS" => $status,
                            "CONSG_WEIGHT" => $weight,
                            "TOTAL_NO_PIECES" => $totalCns,
                            "ATTEMPT_NUMBER" => $attempt_number,
                            "CONSG_COUNT" => $totalCns,
                            "TOTAL_WEIGHT" => $totalWeight,
                            "HANDOVER_DATE_TIME" => $handover_date_time,
                            "MANIFEST_DATE" => $app_date_time,
                            "USER_ID" => $loginUserId,
                            "OFFICE_ID" => $loginUserOfficeId,
                            "REP_OFFICE_ID" => $repOfficeId,
                            "FRANCHISEE_ID" => $franchiseeId,
                            "FDM_NUMBER" => $runSheetNumber,
                            "NO_OF_PIECES" => $no_of_pieces,
                            "DB_SERVER" => $db_server,
                            "DELIVERY_CODE" => $delivery_code,
                            "PREPARATION_DATE_TIME" => $app_date_time,
                            "TRANS_CREATE_DATE" => $server_date_time,
                            "TRANS_LAST_MODIFIED_DATE" => $server_date_time,
                            "NODE_ID" => $deviceMacAddress,
                            "CUTOFF" => $cutOff,
                            "ARRIVAL_DATE_TIME" => $server_date_time,
                            "DEST_PINCODE_ID" => $pincodeId,
                            "REMARKS" => $remarks,
                            "WAR_DATE" => $warDate,
                            "SERVICE_ID" => $service_id,
                            "PRODUCT_ID" => $product_id,
                            "DOCUMENT_ID" => $document_id,
                            "FDM_PREPARED_USER_ID" => $loginUserId,
                            "DEST_24_48" => $fr_delivery
                        );
                    }


                    if ($this->db->insert('dtdc_f_delivery',$codig_insert_data)) {
                        array_push($fdm_response_insert_array, $runSheetNumber);
                    } else {
                        $this->error_response('Error!');
                    }
                }
            }
        }
        $delete = array_merge($fdm_response_insert_array, $fdm_response_update_array);
        $response = array('status' => '1', 'message' => 'FDM saved!', 'delete' => $delete);

        return $response;
    }

    public function getFranchiseeId($frCode){
        $query = "SELECT FRANCHISEE_ID FROM dtdc_d_franchisee WHERE FRANCHISEE_CODE = ? limit 1";
        $result = $this->db->query($query,[$frCode])->result_array();
        if($result){
           return $result[0]['FRANCHISEE_ID'];
        }
        return 1;

    }

    public function isConsgNumberExists($consgNumber){

        $query = "SELECT DELIVERY_STATUS FROM DTDC_F_DELIVERY WHERE CONSG_NUMBER= ? AND CONSG_STATUS='A' AND DELIVERY_STATUS='N'";
        $result = $this->db->query($query,[$consgNumber]);
        if ($result) {
            return true;
        } else {
            return false;
        }

    }

    public function getAttemptNumberValue($consgNumber){
        $query = "select CONSG_NUMBER,ATTEMPT_NUMBER ,ATTEMPT_TYPE from dtdc_f_delivery where consg_number= ? 
                  and delivery_status = 'O' order by ATTEMPT_NUMBER desc limit 1";
        $result = $this->db->query($query,[$consgNumber]);
        $result_array = $result->result_array();
        if ($result) {
            return $result_array;
        } else {
            return false;
        }



    }
    public function updateDeliveryStatus($consgNumber){

        $query = "UPDATE DTDC_F_DELIVERY SET CONSG_STATUS='I' WHERE CONSG_NUMBER= ? AND CONSG_STATUS='A' AND DELIVERY_STATUS='N'";
        $update = $this->db->query($query,[$consgNumber]);
        if ($update) {
            return true;
        } else {
            return false;
        }

    }

    public function getServiceProductDocumentDetails($consg_number, $loggedInOfficeId){
       
        $dest_branch_id = number_format($loggedInOfficeId);
        $query = "select '1' as t,SERVICE_ID,DOCUMENT_ID from dtdc_f_booking WHERE CONSG_NUMBER= ?  
                    union
                    select '1' as t,SERVICE_ID,DOCUMENT_ID from dtdc_f_manifest WHERE CONSG_NUMBER= ?  AND DEST_BRNCH_ID = ?
                    order by t asc limit 1";
        //19-03-2020 query changed instruction given by shashi
        // $query = "select SERVICE_ID,PRODUCT_ID,DOCUMENT_ID from dtdc_f_manifest WHERE CONSG_NUMBER= ? AND DEST_BRNCH_ID = ? ORDER BY  MANIFEST_ID DESC LIMIT 1";
        $result = $this->db->query($query,[$consg_number, $consg_number, $dest_branch_id]);
       
        return $result->result_array();
        
    }
    public function getFRDelivery($frcode){

        $sql = "select FR_DELIVERY from dtdc_d_franchisee where FRANCHISEE_CODE = ? ";
        $result = $this->db->query($sql, [$frcode]);
        $result_array = $result->result_array();
        return $result_array;

    }
    public function check_fdm_in_database($fdm_number)
    {
        $query = "select count(*) from dtdc_f_delivery where fdm_number = ? and delivery_code = 'FDM'";
        $result = $this->db->query($query,[$fdm_number]);
        $result_array = $result->result_array();
        $count = $result_array[0]['count(*)'];
        if ($count > 0) {
            return true;
        } else {
            return false;
        }
    }

    //21-December-2016 - Harish asked to create new api
    // $delivery_status, $runSheetNumber, $fdmConsignents
    public function update_fdm_in_database($delivery_status, $fdm_number, $fdmConsignents)
    {
        if ($delivery_status == 'P') {
            $query = "update dtdc_f_delivery set delivery_status = '".$this->db->escape_str($delivery_status)."' where fdm_number = '".$this->db->escape_str($fdm_number)."'";
        }
        if ($delivery_status == 'O') {
            $query = "update dtdc_f_delivery set delivery_status = '".$this->db->escape_str($delivery_status)."', HANDOVER_NUM = '".$this->db->escape_str($fdm_number)."' where fdm_number = '".$this->db->escape_str($fdm_number)."'";
        }


        if ($this->db->query($query)) {

            for ($i = 0; $i < count($fdmConsignents); $i++) {
                $consigNumber = isset($fdmConsignents[$i]['consigNumber']) ? $fdmConsignents[$i]['consigNumber'] : $this->error_response('Technical error: Missing key consigNumber');
                $delivery_status_child = isset($fdmConsignents[$i]['deliveryStatusChild']) ? $fdmConsignents[$i]['deliveryStatusChild'] : $this->error_response('Expected deliveryStatusChild. This could be JSON key error.');
                if ($delivery_status_child == 'R') {
                    $query1 = "update dtdc_f_delivery set delivery_status = '$delivery_status_child' where CONSG_NUMBER = '$consigNumber'";
                    $this->db->query($query1);
                }
            }

            return true;
        } else {
            return false;
        }
    }

    public function getFranchiseeAdmStatus($franchisee_code)
    {
        $sql = "select * from dtdc_d_franchisee where franchisee_code = ? and franch_type='DLA'";
        $query = $this->db->query($sql, [$franchisee_code]);
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function incomingpacketmanifestautoinscan($input)
    {
        $manifestNumber = isset($input['manifestNumber']) ? $input['manifestNumber'] : $this->error_response('Manifest number is required');
        $officeId = isset($input['loggedInOfficeId']) ? $input['loggedInOfficeId'] : $this->error_response('Logged in office id is not set');
        $officeCode = isset($input['officeCode']) ? $input['officeCode'] : $this->error_response('officeCode id is not set');
        $firstOfficeCode = isset($input['firstOfficeCode']) ? $input['firstOfficeCode'] : $this->error_response('firstOfficeCode id is not set');
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');

        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }
        //On 25 Jan 2017, Harish told to remove dest_branch_id from and condition
        // $query = "select * from dtdc_f_manifest where manifest_number = '$manifestNumber' and manifest_type = 'O' and document_id in (1,3)";

        //On 20 Feb 2017, Harish told to change it
        //$query = "select * from dtdc_f_manifest where MANIFEST_NUMBER = ? and MANIFEST_TYPE = 'O' and MNFST_TYPE_ID in (3,6,8) and DOCUMENT_ID =1";
        $query = "select * from dtdc_f_manifest where MANIFEST_NUMBER = ? and MANIFEST_TYPE = 'O' and MNFST_TYPE_ID in (3,6,8) and DOCUMENT_ID =1 AND 
DEST_BRNCH_ID = ? UNION SELECT * FROM DTDC_F_MANIFEST WHERE MANIFEST_NUMBER= ? AND DEST_BRNCH_ID IN ( SELECT OFFICE_ID FROM dtdc_d_office WHERE PRIN_PLACE_OF_BUSINESS= ? AND LEFT(OFFICE_CODE,1)= ? AND OFFICE_NAME LIKE '%T/S%'  AND BRANCH_NUM_CODE IS NOT NULL ) AND MANIFEST_TYPE='O' AND MNFST_TYPE_ID=3";
     
        $result = $this->db->query($query,[$manifestNumber, $officeId, $manifestNumber, $officeCode, $firstOfficeCode ]);
        // echo $query;
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();
            $dest_brnch_id = $result_array[0]['DEST_BRNCH_ID']; //MODE_ID
            $mode_id = $result_array[0]['MODE_ID'];

            //office
            $office_query = "select office_code, office_name from dtdc_d_office where office_id = ? limit 1";
            $office_result = $this->db->query($office_query,[$dest_brnch_id]);
            $office_array = $office_result->result();

            //mode
            $mode_query = "select mode_id, mode_name from dtdc_d_mode where mode_id = ?";
            $mode_result = $this->db->query($mode_query,[$mode_id]);
            $mode_array = $mode_result->result_array();

            return $response = array('result' => $result_array, 'office' => $office_array, 'mode' => $mode_array);
        } else {
            return $response = array('result' => array());
        }
    }

    public function getWeightIncomingPacketManifest($input)
    {
        $consgNum = isset($input['consgNum']) ? $input['consgNum'] : $this->error_response('consgNum is required');
        $logOffId = isset($input['logOffId']) ? $input['logOffId'] : $this->error_response('logOffId is required');
        $local_db_ip = isset($input['local_db_ip']) ? $input['local_db_ip'] : $this->error_response('Error: local_db_ip is not set.');
        if ($local_db_ip != 'null') {
            $connect = new Connection_model();
            $connect->custom($local_db_ip);
        } else {
            $connect = new Connection_model();
            $connect->central();
        }

        $query = "select indv_weight_kgs from dtdc_f_manifest where consg_number= ? and manifest_type='O' and dest_brnch_id = ? ";
        $result = $this->db->query($query,[$consgNum,$logOffId]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();
            $indv_weight_kgs = $result_array[0]['indv_weight_kgs'];
            $response = array('status' => 1, 'indv_weight_kgs' => $indv_weight_kgs);
        } else {
            $this->error_response('Records not found');
        }

        return $response;
    }

    public function getDeliveryStatusBeforeManifest($consignment_number)
    {
        $sql = "select DELIVERY_STATUS from dtdc_f_delivery where CONSG_NUMBER = ? AND consg_status='A' and DELIVERY_STATUS in ('O','P')";

        $query = $this->db->query($sql, [$consignment_number]);

        if ($query->num_rows() > 0) {

            return true;

        } else {

            return false;
        }

    }

    public function getDeliveredStatus($consignment_number)
    {
        $sql = "select DELIVERY_STATUS from dtdc_f_delivery where CONSG_NUMBER = ? AND consg_status='A' and DELIVERY_STATUS = 'D'";

        $query = $this->db->query($sql, [$consignment_number]);

        if ($query->num_rows() > 0) {

            return 1;

        } else {

            return 0;
        }
    }

    public function checkNumberOfAttempts($consignment_number,$max_delivery_attempts)
    {
        $query = "select CONSG_NUMBER,ATTEMPT_NUMBER ,ATTEMPT_TYPE from dtdc_f_delivery where consg_number= ?
                  and delivery_status = 'O' order by ATTEMPT_NUMBER desc limit 1";
        $result = $this->db->query($query,[$consignment_number]);
        $data = $result->result_array();
        if(!$data){
            return false;
        }
        if ($data[0]['ATTEMPT_NUMBER'] > $max_delivery_attempts ) {
            return true;
        } else {
            return false;
        }
    }

    public function getBagAvailableStatus($office_id, $consignment_number)
    {
        // $sql = "(select BAG_MANIFEST_NUMBER, PHY_WEIGHT from dtdc_f_cd_recv_mnfst_dtls where DEST_OFFICE_ID = ? and BAG_MANIFEST_NUMBER = ?)
        //         union
        //         (select CONSG_NUMBER, INDV_WEIGHT_KGS from dtdc_f_manifest where DEST_BRNCH_ID = ? and CONSG_NUMBER = ? and MANIFEST_TYPE = 'I')
        //         union
        //         (select CONSG_NUMBER, FINAL_WEIGHT from dtdc_f_booking where BRNCH_OFF_ID = ? and CONSG_NUMBER = ?)";

        // done by janagiraman
        $sql = "(select BAG_MANIFEST_NUMBER, PHY_WEIGHT from dtdc_f_cd_recv_mnfst_dtls where DEST_OFFICE_ID = ? and BAG_MANIFEST_NUMBER = ?)
                union
                (select CONSG_NUMBER, IF(INDV_WEIGHT_KGS IS NULL or INDV_WEIGHT_KGS = 0, VOLUMETRIC_WEIGHT, INDV_WEIGHT_KGS) as PHY_WEIGHT from dtdc_f_manifest where DEST_BRNCH_ID = ? and CONSG_NUMBER = ? and MANIFEST_TYPE = 'I')
                union
                (select CONSG_NUMBER, IF(FINAL_WEIGHT IS NULL or FINAL_WEIGHT = 0, VOLUMETRIC_WGHT, FINAL_WEIGHT) as PHY_WEIGHT from dtdc_f_booking where BRNCH_OFF_ID = ? and CONSG_NUMBER = ? );";

        $query = $this->db->query($sql, [
            $office_id,
            $consignment_number,
            $office_id,
            $consignment_number,
            $office_id,
            $consignment_number
        ]);

        if ($query->num_rows() > 0) {

            return $query->result_array();

        } else {

            return [];
        }
    }

    public function getThePincodeDetails($consgNumber, $loggedInOfficeId) {

        $pincodeId = $this->getPincodeIdFromBooking($consgNumber);
        if(!$pincodeId) {
          return [];
        }
        $sql = "select PINCODE_ID, PIN_CODE from dtdc_d_pincode where OFFICE_ID = ? and PINCODE_ID = ? ";
        // $sql = "select PINCODE_ID, PIN_CODE from dtdc_d_pincode where OFFICE_ID = ? and PINCODE_ID = ? and SERVICEABLE = 'Y';";
        $query = $this->db->query( $sql, [$loggedInOfficeId, $pincodeId] );

    		if ( $query->num_rows() > 0 ) {
          $result = [
            'pincodeId' => $query->result_array()[0]['PINCODE_ID'],
            'pincode' => $query->result_array()[0]['PIN_CODE']
          ];
    			return $result;
    		} else {
    			return $this->getThePincodeDetailsIfBranchIsPB($loggedInOfficeId, $pincodeId);
    		}

    }

    public function getPincodeIdFromBooking($consgNumber) {
        $sql = "select DEST_PINCODE_ID from dtdc_f_booking where consg_number = ?";
        $query = $this->db->query( $sql, [$consgNumber] );
        if ( $query->num_rows() > 0 ) {
    			return $query->result_array()[0]['DEST_PINCODE_ID'];
    		} else {
    			return false;
    		}
    }

    public function getThePincodeDetailsIfBranchIsPB($loggedInOfficeId, $pincodeId) {
    //   $sql = "select pincode from dtdc_d_pincode_pb_product_mapping where PARCEL_BRANCH_CODE = (select OFFICE_CODE from dtdc_d_office where office_id = ?) and
    //         PINCODE = (select pin_code from dtdc_d_pincode where PINCODE_ID = ? and SERVICEABLE = 'Y');";
     
      // 22-03-2020
      $sql = "select pincode from dtdc_d_pincode_pb_product_mapping where PARCEL_BRANCH_CODE = (select OFFICE_CODE from dtdc_d_office where office_id = ?) and
            PINCODE = (select pin_code from dtdc_d_pincode where PINCODE_ID = ? )";
      $query = $this->db->query( $sql, [$pincodeId, $pincodeId] );

      if ( $query->num_rows() > 0 ) {
        $result = [
          'pincodeId' => $pincodeId,
          'pincode' => $query->result_array()[0]['pincode']
        ];
        return $result;
      } else {
        return [];
      }
    }

    public function getJustThePincodeServiceStatus($pincode) {

        $sql = "select PINCODE_ID from dtdc_d_pincode where PIN_CODE = ? and SERVICEABLE = 'Y'";
        $query = $this->db->query( $sql, [$pincode] );

        if ( $query->num_rows() > 0 ) {
            return $result = [
                'status' => 1,
                'pincodeId' => $query->result_array()[0]['PINCODE_ID']
            ];
        } else {
            return $result = [
                'status' => 0
            ];
        }
    }

    public function getJustThePincodeServiceStatusTemp($pincode) {

        $sql = "select PINCODE_ID from dtdc_d_pincode where PIN_CODE = ? ";
        $query = $this->db->query( $sql, [$pincode] );

        if ( $query->num_rows() > 0 ) {
            return $result = [
                'status' => 1,
                'pincodeId' => $query->result_array()[0]['PINCODE_ID']
            ];
        } else {
            return $result = [
                'status' => 0
            ];
        }
    }



    public function checkPincodeServiceabilityInDelivery($isApex, $pincode, $loggedInOfficeId, $loggedInOfficeCode, $productCode) {

        if($isApex) {
            return $this->getJustThePincodeServiceStatus($pincode);
        }
      $sql = "(select PINCODE_ID from dtdc_d_pincode where OFFICE_ID = ? and PIN_CODE = ? and SERVICEABLE = 'Y')
              union all
              (select pin.PINCODE_ID from dtdc_d_pincode_pb_product_mapping map, dtdc_d_pincode pin where pin.PIN_CODE = map.PINCODE and
              PARCEL_BRANCH_CODE = ? and pin.PIN_CODE = ? and pin.SERVICEABLE = 'Y' and PRODUCT = ? limit 1)";
      $query = $this->db->query( $sql, [$loggedInOfficeId, $pincode, $loggedInOfficeCode, $pincode, $productCode] );

      if ( $query->num_rows() > 0 ) {
        return $result = [
          'status' => 1,
          'pincodeId' => $query->result_array()[0]['PINCODE_ID']
        ];
      } else {
        return $result = [
          'status' => 0
        ];
      }

    }

    public function checkPincodeServiceabilityInDeliveryTemp($isApex, $pincode, $loggedInOfficeId, $loggedInOfficeCode, $productCode) {

        if($isApex) {
            return $this->getJustThePincodeServiceStatusTemp($pincode);
        }
      $sql = "(select PINCODE_ID from dtdc_d_pincode where OFFICE_ID = ? and PIN_CODE = ?  limit 1)
                union all
                (select pin.PINCODE_ID from dtdc_d_pincode_pb_product_mapping map, dtdc_d_pincode pin where pin.PIN_CODE = map.PINCODE and
                PARCEL_BRANCH_CODE = ? and pin.PIN_CODE = ? and PRODUCT = ? limit 1)";
      $query = $this->db->query( $sql, [$loggedInOfficeId, $pincode, $loggedInOfficeCode, $pincode, $productCode] );

      if ( $query->num_rows() > 0 ) {
        return $result = [
          'status' => 1,
          'pincodeId' => $query->result_array()[0]['PINCODE_ID']
        ];
      } else {
        return $result = [
          'status' => 0
        ];
      }

    }

    public function getEwbStatusForDelivery($consignment_number, $logged_in_office_id)
    {
        $consignment_number_9_digit = substr($consignment_number, 0, 9);

        $sql = "SELECT CONSG_NUMBER FROM dtdc_f_ewb_info WHERE CONSG_NUMBER = ? AND ewb_status = 'N' AND TRANS_OFFICE_ID = ?";

        $query = $this->db->query($sql, [$consignment_number_9_digit, $logged_in_office_id]);

        if ($query->num_rows() > 0) {

            return true;

        } else {

            return false;
        }
    }

    public function getPendingFdms($franchisee_code)
    {
        $sql = " select distinct FDM_NUMBER from dtdc_f_delivery where FRANCHISEE_ID = (select FRANCHISEE_ID from dtdc_d_franchisee where FRANCHISEE_CODE = ?) AND DELIVERY_STATUS = 'P'";
        $query = $this->db->query($sql, [$franchisee_code]);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return [];
        }
    }

    public function handOverFdm($handover_num, $franchisee_code, $fdm, $loginUserId)
    {

        $sql = "update dtdc_f_delivery set HANDOVER_NUM = ?, HANDOVER_DATE_TIME = ?, DELIVERY_STATUS = 'O', USER_ID = ? where FRANCHISEE_ID = (select FRANCHISEE_ID from dtdc_d_franchisee where FRANCHISEE_CODE = ?) AND FDM_NUMBER = ?";
        $this->db->query($sql, [$handover_num, $this->server_date_time, $loginUserId, $franchisee_code, $fdm]);
        if ($this->db->affected_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function getManifestNumForPacketManifest($consg_number, $dest_branch_id, $office_code){
       
        $bag_saved_status = $this->consignmentAlreadySaved($consg_number, $dest_branch_id);
        if ($bag_saved_status === 1) {
            return [
                'bag_saved_status' => 1
            ];
        }

        $isMotherConsignmentStatus = 0;

        $bookingModel = new Booking_model();
        if($bookingModel->getBookingIdFromConsgNumber($consg_number)){
            $isMotherConsignmentStatus = 1;
            return [
                'mother_consignment_status' => $isMotherConsignmentStatus
            ];
        }

        $manifest_number = $this->getManifestNumber($consg_number, $dest_branch_id);
        if($manifest_number){
            return[
                'status' => 1,
                'manifest_number' => $manifest_number
            ];
        }

        return[
            'status' => 0,
            'message' => "Data Not Found"
        ];

    }

    public function getManifestNumForPacketManifestCentral($consg_number){

        $sql = "select manifest_number,manifest_date from dtdc_f_manifest where
                            CONSG_NUMBER = ? and MANIFEST_TYPE = 'O' 
                            order by manifest_date desc limit 1";
        $query = $this->db->query($sql, [$consg_number]);
        if ($query->num_rows() > 0) {
            return [
                'status' => 1,
                'manifest_number' => $query->result_array()[0]['manifest_number'],
                'manifest_date' => $query->result_array()[0]['manifest_date']
            ];
            
        } else {
            return [
                'status' => 0,
                'message' => "Data Not Found"
            ];
        }


    }
    public function getInScanValues($consg_number, $dest_branch_id, $office_code, $manifest_number)
    {
        ## STOP status new api created hence commenting ##
        /*$CI =& get_instance();
        $CI->load->model('Booking_model');
        if($CI->Booking_model->checkTheConsignmentIsStopped($consg_number)){
            return [
                'stop_status' => 1
            ];
        }*/
        $isMotherConsignmentStatus = 1;
        /**
         * 09-07-2020
         * as per prasad sir requirement we have created multiple api for the below conditions
         */
       /* $bag_saved_status = $this->consignmentAlreadySaved($consg_number, $dest_branch_id);
        if ($bag_saved_status === 1) {
            return [
                'bag_saved_status' => 1
            ];
        }

        $isMotherConsignmentStatus = 0;

        $bookingModel = new Booking_model();
        if($bookingModel->getBookingIdFromConsgNumber($consg_number)){
            $isMotherConsignmentStatus = 1;
            return [
                'mother_consignment_status' => $isMotherConsignmentStatus
            ];
        }



        $manifest_number = $this->getManifestNumber($consg_number, $dest_branch_id);
        */
        if (!is_null($manifest_number)) {
            $manifast_inscan_status = $this->getManifestInscanStatus($manifest_number, $dest_branch_id, $consg_number);
            if (!$manifast_inscan_status) {
                return [
                    'manifast_inscan_status' => 0,
                    'manifast_number' => $manifest_number,
                    'mother_consignment_status' => $isMotherConsignmentStatus,
                    'mnfest_type' => $isMotherConsignmentStatus
                ];
            }

        }
        $booked = $this->checkBooked($consg_number);
        $booked_weight = 0.0;
        $booked_picode_id = '';
        $branch_office_id = '';
        $document_id = null;

        if ($booked === 0) {
            $sql1 = "select HED_REASON_ID from dtdc_f_hb_exception_dtl where CONSG_NOS like  ?  and HED_REASON_ID = 314 and OFFICE_CODE = ?";
            $query1 = $this->db->query($sql1, ["%$consg_number%", $office_code]);
            if ($query1->num_rows() > 0) {
                $booked = 1;
            }
        }

        $data = [];

        if ($booked || (substr($consg_number, 0, 4) == '0000')) {
            $sql = "select manifest.MANIFEST_NUMBER, manifest.DEST_PINCODE, manifest.MNFST_TYPE_ID, manifest.INDV_WEIGHT_KGS, manifest.ORIG_BRNCH_ID, manifest.DEST_BRNCH_ID, manifest.MANIFEST_ID, manifest.DOCUMENT_ID from
dtdc_f_manifest manifest where manifest.CONSG_NUMBER = ? and manifest.MANIFEST_TYPE = 'O'";
            $query = $this->db->query($sql, [$consg_number]);
            if ($query->num_rows() > 0) {
                $data = $query->result_array();
            } else {
                $sql2 = "select ACTUAL_WEIGHT, BRNCH_OFF_ID, DOCUMENT_ID, DEST_PINCODE_ID from DTDC_F_BOOKING where CONSG_NUMBER = ?";
                $query2 = $this->db->query($sql2, [$consg_number]);
                if ($query2->num_rows() > 0) {
                    $booked_weight = $query2->result_array()[0]['ACTUAL_WEIGHT'];
                    $branch_office_id = $query2->result_array()[0]['BRNCH_OFF_ID'];
                    $document_id = $query2->result_array()[0]['DOCUMENT_ID'];
                    $booked_picode_id = $query2->result_array()[0]['DEST_PINCODE_ID'];
                }
            }
        }
 
        $consg_number_start = substr($consg_number,0,2);

        if($consg_number_start == 'I3' || $consg_number_start == '70' ){
            $ewb_status = $this->checkConsignIsEway($consg_number);
        }else{
            $consgNumber_nine = substr($consg_number,0,9);
            $ewb_status = $this->checkConsignIsEway($consgNumber_nine);
        }

        

        return [
            'booked_weight' => $booked_weight,
            'branch_office_id' => $branch_office_id,
	        'document_id' => $document_id,
            'booked' => $booked,
            'booked_pincode_id' => $booked_picode_id,
            'data' => $data,
            'bag_saved_status' => 0,
            'manifast_inscan_status' => 1,
            'mother_consignment_status' => $isMotherConsignmentStatus,
            'ewb_status' => $ewb_status
        ];

    }

    public function consignmentAlreadySaved($consignment_number, $dest_brnch_id)
    {
        $sql = "select MANIFEST_ID from dtdc_f_manifest where DEST_BRNCH_ID = ? and MANIFEST_TYPE = 'I' and CONSG_NUMBER = ?";
        $query = $this->db->query($sql, [$dest_brnch_id, $consignment_number]);
        if ($query->num_rows() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public function checkBooked($consignment_number)
    {
        $sql = "SELECT CONSG_NUMBER from dtdc_f_booking where CONSG_NUMBER = ?";
        $query = $this->db->query($sql, [$consignment_number]);
        if ($query->num_rows() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public function getManifestNumberReceivedStatus($consignment_number, $dest_branch_id)
    {
        $sql = "select MANIFEST_ID from dtdc_f_manifest where DEST_BRNCH_ID = ? and MANIFEST_TYPE = 'I' and CONSG_NUMBER = ?";
        $query = $this->db->query($sql, [$dest_branch_id, $consignment_number]);
        if ($query->num_rows() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public function getManifestNumberSavedStatus($consignment_number, $dest_branch_id)
    {
        $sql = "select MANIFEST_ID from dtdc_f_manifest where DEST_BRNCH_ID = ? and MANIFEST_TYPE = 'I' and MANIFEST_NUMBER = ?";
        $query = $this->db->query($sql, [$dest_branch_id, $consignment_number]);
        if ($query->num_rows() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public function getConsgSavedStatusInIBM($consg_number, $dest_branch_id)
    {
        $sql = "select manifest_id,manifest_number from dtdc_f_manifest where consg_number = ?
				and DEST_BRNCH_ID = ? and manifest_type = 'I'";
        $query = $this->db->query($sql, [$consg_number, $dest_branch_id]);
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function getBagReceivedOrNot($consg_number, $dest_branch_id)
    {
       
        $sql = "select BAG_MANIFEST_NUMBER from dtdc_f_cd_recv_mnfst_dtls where BAG_MANIFEST_NUMBER IN (select MANIFEST_NUMBER from dtdc_f_manifest where CONSG_NUMBER = ? and MANIFEST_TYPE = 'O') and DEST_OFFICE_ID = ? and PHY_WEIGHT > 0";
        $query = $this->db->query($sql, [$consg_number, $dest_branch_id]);
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function checkOutgoingRecordExistsOrNot($consgNumber) {

      $sql = "select distinct(MANIFEST_NUMBER),mnfst_type_id ,manifest_date from dtdc_f_manifest where manifest_number = ? and MANIFEST_TYPE = 'O' and mnfst_type_id in (3,4,8)";  
      $query = $this->db->query($sql, [$consgNumber]);
    //   $sql =   "select MANIFEST_NUMBER,mnfst_type_id,manifest_date from dtdc_f_manifest where CONSG_NUMBER = ? and MANIFEST_TYPE = 'O'
    //     union
    //     select distinct(MANIFEST_NUMBER),mnfst_type_id ,manifest_date from dtdc_f_manifest where manifest_number = ? and MANIFEST_TYPE = 'O'
    //     ";
    //   $query = $this->db->query($sql, [$consgNumber, $consgNumber]);
      if ($query->num_rows() > 0) {
        return $query->result_array();
      } else {
          return false;
      }
    }

    public function checkOutgoingDataCentralIBM($consgNumber){
        $sql = "select distinct(MANIFEST_NUMBER),mnfst_type_id ,manifest_date from dtdc_f_manifest where manifest_number = ? and MANIFEST_TYPE = 'O' and mnfst_type_id in (3,4,8)";  
        $query = $this->db->query($sql, [$consgNumber]);
        // $sql =   "select MANIFEST_NUMBER,mnfst_type_id,manifest_date from dtdc_f_manifest where CONSG_NUMBER = ? and MANIFEST_TYPE = 'O'
        //         union 
        //         select distinct(MANIFEST_NUMBER),mnfst_type_id ,manifest_date from dtdc_f_manifest where manifest_number = ? and MANIFEST_TYPE = 'O'";
        // $sql ="select MANIFEST_NUMBER,mnfst_type_id,manifest_date from dtdc_f_manifest where CONSG_NUMBER = ? and MANIFEST_TYPE = 'O' and mnfst_type_id IN (3,4,8)
        // union
        // select distinct(MANIFEST_NUMBER),mnfst_type_id ,manifest_date from dtdc_f_manifest where manifest_number = ? and MANIFEST_TYPE = 'O' and mnfst_type_id IN (3,4,8)";
        
        //$sql = "select MANIFEST_NUMBER from dtdc_f_manifest where CONSG_NUMBER = ? and MANIFEST_TYPE = 'O';";
    //   $query = $this->db->query($sql, [$consgNumber, $consgNumber]);
      if ($query->num_rows() > 0) {
        return $query->result_array();
      } else {
          return false;
      }
    }

    public function getLoggedInOfficeReportingBranches($logged_in_office_id)
    {
        $sql = "SELECT OFFICE_ID, OFFICE_CODE, OFFICE_NAME from DTDC_D_OFFICE where REPORT_REGOFF_ID = ? AND RECORD_STATUS = 'A'";
        $query = $this->db->query($sql, [$logged_in_office_id]);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return [];
        }
    }

    public function getActivefranchiseesOfBranch($office_id)
    {
        // $sql = "select franchisee_id, franchisee_code, business_name, fr_delivery from dtdc_d_franchisee 
        // where closed_status<> 'Y' and FR_FDM <>'N'
        // AND OFFICE_ID = ?
        // AND franch_type <> 'PUP'";

        $sql = "select franchisee_id, franchisee_code, business_name, fr_delivery from dtdc_d_franchisee 
        where closed_status<> 'Y' and FR_FDM <>'N'
        AND CUR_STATUS = 'A'
        AND OFFICE_ID = ?
        AND franch_type <> 'PUP'";
        //25-02-2020 below query commented
       // $sql = "select franchisee_id, franchisee_code, business_name, fr_delivery from dtdc_d_franchisee where closed_status<> 'Y' and FR_FDM <>'N' AND OFFICE_ID = ?";
        $query = $this->db->query($sql, [$office_id]);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return [];
        }
    }

    public function getFreedomFranchisees()
    {
        // $sql = "select franchisee_id, franchisee_code, business_name, office_id, fr_delivery from dtdc_d_franchisee where closed_status<> 'Y' and FR_FDM <>'N' AND franchisee_code like 'MM%'";
        $sql = "select franchisee_id, franchisee_code, business_name, office_id, fr_delivery,CUR_STATUS from dtdc_d_franchisee
        where closed_status<> 'Y' 
        and CUR_STATUS = 'A'
        and FR_FDM <>'N' AND franchisee_code like 'MM%'";
        $query = $this->db->query($sql);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return [];
        }
    }


    protected function _get_last_cd_receive_dispatch_id()
    {
        $query = "select CD_RECEIVE_DISPATCH_ID from dtdc_f_cd_receive order by CD_RECEIVE_DISPATCH_ID desc limit 1";
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();

            return $result_array[0]['CD_RECEIVE_DISPATCH_ID'];
        }
    }

    public function getManifestNumber($consg_number, $dest_branch_id)
    {
        $query = "select manifest_number from dtdc_f_manifest where
CONSG_NUMBER = ? and DEST_BRNCH_ID = ? and MANIFEST_TYPE = 'O' order by manifest_date desc limit 1";
        $result = $this->db->query($query,[$consg_number,$dest_branch_id]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();

            return $result_array[0]['manifest_number'];
        } else {
            return null;
        }
    }

    public function getManifestInscanStatus($manifest_number, $dest_branch_id, $consg_number)
    {
        // $sql = "(select BAG_MANIFEST_NUMBER from dtdc_f_cd_recv_mnfst_dtls where BAG_MANIFEST_NUMBER = ? and DEST_OFFICE_ID = ? and PHY_WEIGHT > 0)
        // union
        // (select manifest_number from dtdc_f_manifest where consg_number = ? and DEST_BRNCH_ID = ? and MANIFEST_TYPE = 'I')
        // union
        // (select BAG_MANIFEST_NUMBER from dtdc_f_cd_recv_mnfst_dtls where BAG_MANIFEST_NUMBER = ? and DEST_OFFICE_ID = ? and PHY_WEIGHT > 0)";
      
        // $sql = "(select BAG_MANIFEST_NUMBER from dtdc_f_cd_recv_mnfst_dtls where BAG_MANIFEST_NUMBER = ? and DEST_OFFICE_ID = ? and PHY_WEIGHT > 0)
        // union
        // (select manifest_number from dtdc_f_manifest where consg_number = ? and DEST_BRNCH_ID = ? and MANIFEST_TYPE = 'I')";
        
        $sql = "select '2' as MNFEST_TYPE ,BAG_MANIFEST_NUMBER from dtdc_f_cd_recv_mnfst_dtls where BAG_MANIFEST_NUMBER = ? and DEST_OFFICE_ID = ? and PHY_WEIGHT > 0
                union
                select  '1' as MNFEST_TYPE, manifest_number from dtdc_f_manifest where consg_number = ? and DEST_BRNCH_ID = ? and MANIFEST_TYPE = 'I';";

        $query = $this->db->query($sql,[$manifest_number,$dest_branch_id,$manifest_number,$dest_branch_id]);
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function isConsgNumberisSavedInDmc($consg_number, $office_id)
    {
        $sql = "select consg_number from dtdc_f_dmc where consg_number = ? and office_id= ? and rto_consg_number is not null";
        $query = $this->db->query($sql, [$consg_number, $office_id]);
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function getDeliveryStatusOfConsgForDmc($consg_number, $office_id)
    {
        $sql = "select REASON_ID, FRANCHISEE_ID, EMPLOYEE_ID from DTDC_F_DELIVERY where consg_number= ? and  delivery_status ='N' and consg_status='A' and (office_id= ? or rep_office_id = ?)";
        $result = $this->db->query($sql, [$consg_number, $office_id,$office_id]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();
            return $result_array[0];
        } else {
            return null;
        }
    }

    public function getReasonFromId($reason_id)
    {
        $sql = "select reason_id, reason_code, reason_name from dtdc_d_reason where reason_id = ?";
        $result = $this->db->query($sql, [$reason_id]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();
            return $result_array[0];
        } else {
            return null;
        }
    }

    public function getFranchiseFromId($franchise_id)
    {
        $sql = "select franchisee_id, franchisee_code, first_name from dtdc_d_franchisee where  franchisee_id = ?";
        $result = $this->db->query($sql, [$franchise_id]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();
            return $result_array[0];
        } else {
            return null;
        }
    }

    public function getCustomerFromId($customer_id)
    {
        $sql = "SELECT CUSTOMER_ID, CUSTOMER_CODE, BUSINESS_NAME FROM dtdc_d_customer WHERE CUSTOMER_ID = ?";
        $result = $this->db->query($sql, [$customer_id]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();
            return $result_array[0];
        } else {
            return null;
        }
    }

    public function getEmployeeFromId($employee_id)
    {
        $sql = "select employee_id, emp_code, first_name from dtdc_d_employee where employee_id = ?";
        $result = $this->db->query($sql, [$employee_id]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();
            return $result_array[0];
        } else {
            return null;
        }
    }

    public function getNumberOfAttemptsCount($consg_number, $office_id)
    {
        $sql = "select count(*) as cnt from DTDC_F_DELIVERY where consg_number= ? and  delivery_status ='N' and office_id= ?";
        $result = $this->db->query($sql, [$consg_number, $office_id]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();
            return $result_array[0]['cnt'];
        } else {
            return null;
        }
    }

    public function getBookingDataForDmcConsg($consg_number)
    {
        $sql = "select final_weight, no_of_pieces, cod_amount, inv_value, channel_type_id, customer_id, mode_id, product_id, document_id, franchisee_id, brnch_off_id, commodity_id from dtdc_f_booking where consg_number = ?";
        $result = $this->db->query($sql, [$consg_number]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();
            return $result_array[0];
        } else {
            return null;
        }
    }

    public function getThePincodeFromBranchOfficeId($branchOfficeId) {

        $sql = "SELECT pin_code FROM dtdc_d_pincode WHERE PINCODE_ID = (select pincode_id FROM DTDC_D_AREA WHERE AREA_ID = (select area_id from dtdc_d_office where office_id = ?));";
        $result = $this->db->query($sql, [$branchOfficeId]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();
            return $result_array[0]['pin_code'];
        } else {
            return null;
        }

    }

    public function getCpdpcccDetails($res)
    {
        $channel_type_id = $res['channel_type_id'];
        if ($channel_type_id == 2) {
            $sql = 'select franchisee_id, franchisee_code, first_name from dtdc_d_franchisee where franchisee_id = ?';
            $param = $res['franchisee_id'];
        } elseif ($channel_type_id == 1 || $channel_type_id == 7) {
            $sql = 'select customer_id, customer_code, first_name from dtdc_d_customer where customer_id = ?';
            $param = $res['customer_id'];
        } else {
            $sql = 'select office_id, office_code, office_name from dtdc_d_office where office_id = ?';
            $param = $res['brnch_off_id'];
        }
        $result = $this->db->query($sql, [$param]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();
            return $result_array[0];
        } else {
            return null;
        }
    }

    public function getCommodityDetails($commodity_id)
    {
        $sql = "select commodity_id, commodity_code, commodity_name from dtdc_d_commodity where commodity_id = ?";
        $result = $this->db->query($sql, [$commodity_id]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();
            return $result_array[0];
        } else {
            return null;
        }
    }

    public function getBranchDetails($office_id)
    {
        $sql = 'select office_id, office_code, office_name from dtdc_d_office where office_id = ?';
        $result = $this->db->query($sql, [$office_id]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();
            return $result_array[0];
        } else {
            return null;
        }
    }

    public function saveDmcData($input)
    {
        $insert_data = [
            'CONSG_NUMBER' => $input['consgNumber'],
            'CALL_DATE' => $this->date,
            'ATTEMPT_TYPE' => 2,
            'FRANCHISEE_ID' => $input['franchiseeId'],
            'OFFICE_ID' => $input['officeId'],
            'CALL_REMARKS' => $input['callRemarks'],
            'ATTEMPT_NUMBER' => $input['attemptNumber'],
            'RE_ATTEMPT_DATE' => $input['attemptDate'],
            'ATTEMPTING_FR_ID' => $input['attemptingFranchiseeId'],
            'ATTEMPTING_EMP_ID' => $input['attemptingEmpId'],
            'TRANS_CREATED_DATE' => $this->server_date_time,
            'DI_FLAG' => 'P',
            'DB_SERVER' => 'N',
            'EMPLOYEE_ID' => $input['attemptingEmpId'],
            'RECORD_STATUS' => 'A',
            'RTO_CONSG_NUMBER' => $input['rtoConsgNumber'],
            'DEST_PINCODE_ID' => $input['destPincodeId'],
            'NO_OF_PIECES' => $input['noOfPieces'],
            'ACTUAL_WEIGHT' => $input['actualWeight'],
            'DOCUMENT_ID' => $input['documentId'],
            'MODE_ID' => $input['modeId'],
            'PRODUCT_ID' => $input['productId'],
            'COMMODITY_ID' => $input['commodityId'],
            'COD_AMOUNT' => $input['codAmount'],
            'INV_VALUE' => $input['invValue'],
            'CURRENT_PIECE' => $input['currentPiece'],
            'CUSTOMER_CODE' => $input['cusomerCode'],
        ];

        $this->db->insert('dtdc_f_dmc', $insert_data);
        return $this->db->insert_id();
    }

    public function getRtoStock($branch_code){
        $sql = "SELECT CSC_ID, CSC_START_CNNO, CSC_END_CNNO, CSC_STOCK FROM dtdc_f_cn_stock_ctrl where CSC_START_CNNO like '00%' and csc_branch_code= ? and csc_stock>0  and length(CSC_START_CNNO)=12 and status='A'  order by csc_stock asc
limit 1";
        $result = $this->db->query($sql, [$branch_code]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();
            return $result_array[0];
        } else {
            return null;
        }
    }

    public function updateStock($csc_id,$stock_count){
        $sql= "update dtdc_f_cn_stock_ctrl set CSC_STOCK = ? where CSC_ID = ?";
        $this->db->query($sql, [$stock_count, $csc_id]);

    }

    public function checkBagSavedInIBM($cong_number,$loggedInOfficeId){
        $sql = "SELECT MANIFEST_ID FROM dtdc_f_manifest WHERE CONSG_NUMBER =? and DEST_BRNCH_ID = ? AND MANIFEST_TYPE = 'I'";
        $result = $this->db->query($sql, [$cong_number, $loggedInOfficeId]);
        return $result->num_rows() > 0;
    }

    public function getAllTheConsignmentNumbersAssociated($consgNumber) {

        $sql = "select consg_number from dtdc_f_booking where PARENT_CONSG_NO = (select PARENT_CONSG_NO from dtdc_f_booking where CONSG_NUMBER = ?)";
        $query = $this->db->query($sql, [$consgNumber]);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return [];
        }
    }

    public function getCheckSetRtoWeight($consgNumber) {
        $sql = "select consg_number,PARENT_CONSG_NO,actual_weight as weight from dtdc_f_booking where consg_number= ? order by weight desc limit 1";
        $query = $this->db->query($sql, [$consgNumber]);
        if ($query->num_rows() > 0) {
            return $query->result_array()[0]['weight'];
        } else {
            return false;
        }
    }

    public function getEcomCustomer($consgNumber) {
//         $sql = "SELECT CONSG_NUMBER,CUSTOMER_ID,FRANCHISEE_ID,
// CASE WHEN CUSTOMER_ID IS NOT NULL THEN (SELECT ecom_customer FROM dtdc_d_customer WHERE dtdc_d_customer.CUSTOMER_ID=DTDC_F_BOOKING.CUSTOMER_ID LIMIT 1)
// END ecom_customer FROM DTDC_F_BOOKING WHERE CONSG_NUMBER= ?";

        // $sql = "SELECT b.CONSG_NUMBER,b.CUSTOMER_ID,b.FRANCHISEE_ID,c.ecom_customer
        //         FROM DTDC_F_BOOKING B,dtdc_d_customer c
        //         WHERE b.CONSG_NUMBER = ? and b.customer_id=c.customer_id";

        // 07 -03-2020 commented
        // $sql = "SELECT b.CONSG_NUMBER,b.CUSTOMER_ID,b.FRANCHISEE_ID,ifnull(c.ecom_customer,'N') as ecom_customer
        //         FROM DTDC_F_BOOKING B LEFT JOIN dtdc_d_customer c
        //         ON b.customer_id=c.customer_id
        //         where
        //         b.CONSG_NUMBER = ? ";

        // 09-03-2020 replaced
        $sql = "SELECT b.CONSG_NUMBER,b.CUSTOMER_ID,b.FRANCHISEE_ID,
        case when b.FRANCHISEE_ID is not null then (select 'Y')
        else (
        select ifnull(c.ecom_customer,'N')
        ) end ecom_customer
                     FROM DTDC_F_BOOKING B LEFT JOIN dtdc_d_customer c
                     ON b.customer_id=c.customer_id
                     where
                     b.CONSG_NUMBER = ?
        and B.channel_type_id IN (1,2)";

        $query = $this->db->query($sql, [$consgNumber]);
        if ($query->num_rows() > 0) {
            return $query->result_array()[0]['ecom_customer'];
        } else {
            return false;
        }
    }

    public function checkSetRtoAttemptType($consgNumber) {
        $sql = "select attempt_type, re_attempt_date, set_rto_flag, set_rto_attempt, canceled_rto  from dtdc_f_dmc where consg_number= ? order by dmc_id desc";
        $query = $this->db->query($sql, [$consgNumber]);
        if ($query->num_rows() > 0) {
            return $query->result_array()[0];
        } else {
            return false;
        }
    }

    public function getBikerDetailsForBDM($loggedInOfficeId){
//        $sql = "select a.AAD_USERCODE, e.FIRST_NAME,e.EMP_CODE,e.EMPLOYEE_ID
//                from dtdc_d_app_auth_dtls a
//                inner join dtdc_d_employee e on e.`EMP_CODE`=a.`AAD_USERCODE`
//                where a.TRANS_STATUS='A'
//                and a.AAD_OFFTYPE='BR'
//                and a.AAD_APP_TYPE='FAR'
//                and e.`RECORD_STATUS`='A'
//                and a.`AAD_OFFCODE`= ? ";
        $sql = "select e.EMPLOYEE_ID,e.EMP_CODE,e.FIRST_NAME,e.LAST_NAME,e.SUR_NAME from dtdc_d_employee e
                inner join dtdc_d_app_auth_dtls a on e.EMP_CODE = a.AAD_USERCODE where a.TRANS_STATUS='A'
                and a.AAD_OFFTYPE='BR' and a.AAD_APP_TYPE='FAR' and e.RECORD_STATUS='A' and e.OFFICE_ID= ?
                UNION
                select e.EMPLOYEE_ID,e.EMP_CODE,e.FIRST_NAME,e.LAST_NAME,e.SUR_NAME from dtdc_d_employee e
                where e.RECORD_STATUS='A' and e.DESIGNATION like '%BIKE%' and e.OFFICE_ID= ?";
        $query = $this->db->query($sql, [$loggedInOfficeId,$loggedInOfficeId]);

        $result = $query->result_array();
        if ($result) {
            $response = [
                'status' => '1',
                'message' => 'Success',
                'data' =>   $result
            ];
           return $response;
        }
       return $response = [
            'status' => '0',
            'message' => 'Employee data not available',
            'data' => []
          
        ];
        

    }

    public function getManifestNumberForConsgNumber($consg_number,$dest_branch_id){

        $sql = "select manifest_number from dtdc_f_manifest where consg_number = ? and dest_brnch_id = ? ";
        $query = $this->db->query($sql, [$consg_number, $dest_branch_id ]);
        $result =  $query->result_array();
        if($result){
              return $result[0]['manifest_number'];
        }
        return $consg_number;
    }

   

}