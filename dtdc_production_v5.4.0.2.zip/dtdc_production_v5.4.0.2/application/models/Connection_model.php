<?php

/**
 *
 */
class Connection_model extends CI_Model
{

    public $config = array();

    public function __construct()
    {
        if (isset($this->db)) {
            $this->db->close();
        }
        // $this->db->close();
        $this->config['username'] = 'dtdc';
        $this->config['password'] = 'permit';
        $this->config['database'] = 'dtdc_ctbs_plus';
        $this->config['dbdriver'] = 'mysqli';
        $this->config['dbprefix'] = '';
        $this->config['pconnect'] = FALSE;
        $this->config['db_debug'] = TRUE;
        $this->config['cache_on'] = FALSE;
        $this->config['cachedir'] = '';
        $this->config['char_set'] = 'utf8';
        $this->config['dbcollat'] = 'utf8_general_ci';

    }

    public function custom($hostname)
    {
        $this->config['hostname'] = $hostname;
        $this->connect();
    }

    public function central()
    {
         // When central is live version v5.4.0.2
          $this->config['hostname'] = '10.10.5.15';
          $this->config['username'] = 'cellhandler'; 
          $this->config['password'] = 'G6AnDCe11#AnD136';  

    //  When central is test version v5.6.9.2
    //  $this->config['hostname'] = '10.10.5.60';
    //  $this->config['username'] = 'dtdc';
    //  $this->config['password'] = 'permit';

        $this->connect();
    }

    public function localhost()
    {
        $this->config['hostname'] = 'localhost';
        $this->config['username'] = 'root';
        $this->config['password'] = 'root';
        $this->connect();
    }

    public function slave()
    {
        $this->config['hostname'] = '10.10.5.12';
        $this->connect();
    }

    public function connect()
    {
        $this->load->database($this->config);
    }

}
