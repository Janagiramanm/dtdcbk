<?php

defined('BASEPATH') OR exit('No direct script access allowed');


class Master_details_model extends CI_Model

{
    public function __construct()
    {

    }

    public function get_flight_details($office_id)
    {
        $flights = array();
        $query = "select distinct t.flight_id,t.route_id, (select orig_office_id from dtdc_d_route where route_id = t.route_id) as orig_office_id, (select dest_office_id from dtdc_d_route where route_id = t.route_id) as dest_office_id, t.vehicle_dep_time, t.vehicle_arr_time, f.flight_number from dtdc_d_trns_time t,dtdc_d_flight f where route_id in (
select route_id from dtdc_d_route where (dest_office_id= ? or ORIG_OFFICE_ID = ?) and cur_status='A') and mode_id=1
and f.flight_id = t.flight_id";
// echo $query;
        $result = $this->db->query($query,[$office_id,$office_id]);
        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $flights[$i] = $result_array[$i];
        }
        $result = $flights;
        return $result;
    }

    public function get_train_details($office_id)
    {
        $trains = array();
        $query = "select distinct t.train_id,t.route_id,(select orig_office_id from dtdc_d_route where route_id = t.route_id) as orig_office_id, (select dest_office_id from dtdc_d_route where route_id = t.route_id) as dest_office_id,t.vehicle_dep_time, t.vehicle_arr_time, f.train_number from dtdc_ctbs_plus.dtdc_d_trns_time t,dtdc_d_train f where route_id in (
        select route_id from dtdc_ctbs_plus.dtdc_d_route where (dest_office_id= ? or ORIG_OFFICE_ID = ?) and cur_status='A') and mode_id=10
        and f.train_id = t.train_id";

        $result = $this->db->query($query,[$office_id,$office_id]);
        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $trains[$i] = $result_array[$i];
        }
        $result = $trains;
        return $result;
    }

    public function get_vehicle_details($office_id)
    {
        $vehicles = array();
        // $query = "select distinct t.train_id as vehicle_id, t.vehicle_dep_time, t.vehicle_arr_time, f.train_number as vehicle_number from dtdc_ctbs_plus.dtdc_d_trns_time t,dtdc_d_train f where route_id in (
        //   select route_id from dtdc_ctbs_plus.dtdc_d_route where dest_office_id='$office_id' and cur_status='A') and mode_id=10
        //   and f.train_id = t.train_id";

        $query = "select distinct t.HIRED_VEHICLE_NO,t.route_id,(select orig_office_id from dtdc_d_route where route_id = t.route_id) as orig_office_id, (select dest_office_id from dtdc_d_route where route_id = t.route_id) as dest_office_id,t.vehicle_dep_time, t.vehicle_arr_time from
dtdc_ctbs_plus.dtdc_d_trns_time t where route_id in (
select route_id from dtdc_ctbs_plus.dtdc_d_route where (dest_office_id= ? or ORIG_OFFICE_ID = ?) and cur_status='A') and mode_id=2
AND HIRED_VEHICLE_NO <> ''";

        $result = $this->db->query($query,[$office_id,$office_id]);
        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $vehicles[$i] = $result_array[$i];
        }
        $result = $vehicles;
        return $result;
    }

    public function get_franchisee_details($office_id)
    {
        $franchisees = array();
        $query = "select franchisee_id, franchisee_code, business_name from dtdc_d_franchisee where closed_status<> 'Y'  and FR_FDM <>'N' AND OFFICE_ID= ?";
        $result = $this->db->query($query,[$office_id]);

        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $franchisees[$i] = $result_array[$i];
        }

        $result = $franchisees;
        return $result;
    }

    public function get_dtdc_d_routing_master()
    {
        $routing_details = array();
        $query = "SELECT route_id, rm_code, rm_product_id, rm_mode_id, rm_entity_type,rm_transaction FROM dtdc_d_routing_master";
        $result = $this->db->query($query);

        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $routing_details[$i] = $result_array[$i];
        }

        $result = $routing_details;
        return $result;
    }

    public function sync_dtdc_d_routing_master($lastSyncDate)
    {
        $routing_details = array();
        //11-02-2020 reverted back as it was slowing down the login process
        $query = "select route_id, rm_code, rm_product_id, rm_mode_id, rm_entity_type,rm_transaction from dtdc_d_routing_master where record_entry_datetime < NOW() and record_entry_datetime > ?";
        // updated- 17/01/2020
        // $query = "select route_id, rm_code, rm_product_id, rm_mode_id, rm_entity_type,rm_transaction from dtdc_d_routing_master where MOD_DATE_TIME < NOW() and MOD_DATE_TIME > ?";
        $result = $this->db->query($query,[$lastSyncDate]);

        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $routing_details[$i] = $result_array[$i];
        }

        $result = $routing_details;
        return $result;
    }

    public function get_dtdc_d_office_master()
    {
        $dtdc_d_office_details = array();
        $query = "SELECT o.office_id, c.city_code, o.branch_alias, o.office_code, o.office_name, o.off_type, o.off_location, o.city_id, o.branch_num_code, o.report_regoff_id, o.off_type, o.record_status FROM dtdc_d_office o INNER JOIN dtdc_d_city c ON o.city_id = c.city_id";

        $result = $this->db->query($query);

        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $dtdc_d_office_details[$i] = $result_array[$i];
        }

        $result = $dtdc_d_office_details;
        return $result;
    }

    //The record_entry_datetime field in database is not of timestamp,
    //sync may not work.
    public function sync_dtdc_d_office_master($lastSyncDate)
    {
        $dtdc_d_office_details = array();
         //11-02-2020 reverted back as it was slowing down the login process
         $query = "select o.office_id, c.city_code, o.branch_alias, o.office_code, o.office_name, o.off_type, o.city_id, o.branch_num_code, o.report_regoff_id, o.off_type, o.record_status from dtdc_d_office o inner join dtdc_d_city c on o.city_id = c.city_id where o.record_entry_datetime < NOW() and o.record_entry_datetime > ?";
        // updated- 17/01/2020
        //$query = "select o.office_id, c.city_code, o.branch_alias, o.office_code, o.office_name, o.off_type, o.city_id, o.branch_num_code, o.report_regoff_id, o.off_type, o.record_status from dtdc_d_office o inner join dtdc_d_city c on o.city_id = c.city_id where o.MOD_DATE_TIME < NOW() and o.MOD_DATE_TIME > ?";

        $result = $this->db->query($query,[$lastSyncDate]);

        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $dtdc_d_office_details[$i] = $result_array[$i];
        }

        $result = $dtdc_d_office_details;
        return $result;
    }

    public function get_dtdc_d_pincode()
    {
        $dtdc_d_pincode = array();
        $query = "SELECT pincode_id, pin_code, office_id FROM dtdc_d_pincode";
        $result = $this->db->query($query);

        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $dtdc_d_pincode[$i] = $result_array[$i];
        }

        $result = $dtdc_d_pincode;
        return $result;
    }

    public function sync_dtdc_d_pincode($lastSyncDate)
    {
        $dtdc_d_pincode = array();
         //11-02-2020 reverted back as it was slowing down the login process
         $query = "select pincode_id, pin_code, office_id from dtdc_d_pincode where record_entry_datetime < NOW() and record_entry_datetime > ?";
        // updated- 17/01/2020
        //$query = "select pincode_id, pin_code, office_id from dtdc_d_pincode where MOD_DATE_TIME < NOW() and MOD_DATE_TIME > ?";
        $result = $this->db->query($query,[$lastSyncDate]);

        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $dtdc_d_pincode[$i] = $result_array[$i];
        }

        $result = $dtdc_d_pincode;
        return $result;
    }

    public function get_service_type_direct_connection($office_id, $report_regoff_id)
    {
        $dtdc_d_service_type_direction_connections = array();
        //office_id = $report_regoff_id || $office_id
        $query = "select vendor_id,vendor_code, business_name from dtdc_d_vendor where vendor_type = 'D' and office_id in (?,?)";
        $result = $this->db->query($query,[$report_regoff_id,$office_id]);

        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $dtdc_d_service_type_direction_connections[$i] = $result_array[$i];
        }

        $result = $dtdc_d_service_type_direction_connections;
        return $result;
    }

    public function get_service_type_otc($office_id)
    {

        $dtdc_d_get_service_type_otc = array();

        $query = "select DISTINCT c.OTC_CODE, c.private_otc_name, t.trnst_time_id from dtdc_ctbs_plus.dtdc_d_trns_time t, dtdc_ctbs_plus.dtdc_d_otc_master c where route_id in (

select route_id from dtdc_ctbs_plus.dtdc_d_route where ORIG_OFFICE_ID= ? and cur_status='A') and c.OTC_CODE = t.TRNST_CODE

and t.CUR_STATUS='A'";
// echo $query;
        $result = $this->db->query($query,[$office_id]);

        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $dtdc_d_get_service_type_otc[$i] = $result_array[$i];
        }

        $result = $dtdc_d_get_service_type_otc;
        return $result;
    }

    public function get_service_type_co_loader($office_id, $modeId)
    {

        $array = array();

        $query = "select DISTINCT c.LOADER_id, c.LOADER_code, c.loader_name, t.trnst_time_id from dtdc_ctbs_plus.dtdc_d_trns_time t, dtdc_ctbs_plus.dtdc_d_coloader c where route_id in (

select route_id from dtdc_ctbs_plus.dtdc_d_route where ORIG_OFFICE_ID= ? and cur_status='A') and mode_id= ? and c.LOADER_ID = t.CO_LOADER_ID

and t.CUR_STATUS='A'";
        // echo $query;
        $result = $this->db->query($query,[$office_id,$modeId]);

        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $array[$i] = $result_array[$i];
        }

        $result = $array;
        return $result;

    }

    public function get_reasons()
    {
        $reason_array = array();
        $query = "SELECT DISTINCT reason_id,reason_code,reason_name FROM dtdc_d_reason WHERE non_delv_type = 'REMOVAL SCAN'";
        $result = $this->db->query($query);
        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $reason_array[$i] = $result_array[$i];
        }
        return $reason_array;
    }

    public function sync_dtdc_d_reason($lastSyncDate)
    {
        $reason_array = array();
         //11-02-2020 reverted back as it was slowing down the login process
         $query = "select distinct reason_id,reason_code,reason_name from dtdc_d_reason where non_delv_type = 'REMOVAL SCAN' and (record_entry_datetime < NOW() and record_entry_datetime > ?)";
        // updated- 17/01/2020
        // $query = "select distinct reason_id,reason_code,reason_name from dtdc_d_reason where non_delv_type = 'REMOVAL SCAN' and (MOD_DATE_TIME < NOW() and MOD_DATE_TIME > ?)";
        $result = $this->db->query($query,[$lastSyncDate]);
        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $reason_array[$i] = $result_array[$i];
        }
        return $reason_array;
    }

    public function get_all_coloader()
    {
        $coloader_array = array();
        $query = "SELECT loader_id,loader_code,loader_name FROM dtdc_d_coloader";
        $result = $this->db->query($query);
        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $coloader_array[$i] = $result_array[$i];
        }
        return $coloader_array;
    }

    public function sync_dtdc_d_coloader($lastSyncDate)
    {
        $coloader_array = array();
         //11-02-2020 reverted back as it was slowing down the login process
         $query = "select loader_id,loader_code,loader_name from dtdc_d_coloader where record_entry_datetime < NOW() and record_entry_datetime > ?";
        // updated- 17/01/2020
        // $query = "select loader_id,loader_code,loader_name from dtdc_d_coloader where MOD_DATE_TIME < NOW() and MOD_DATE_TIME > ?";
        $result = $this->db->query($query,[$lastSyncDate]);
        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $coloader_array[$i] = $result_array[$i];
        }
        return $coloader_array;
    }

    public function get_all_trns_time()
    {
        $trns_time_array = array();
        $query = "SELECT trnst_time_id, co_loader_id, trnst_code, cur_status, route_id, mode_id FROM dtdc_d_trns_time";
        $result = $this->db->query($query);
        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $trns_time_array[$i] = $result_array[$i];
        }
        return $trns_time_array;
    }

    public function sync_all_trns_time($lastSyncDate)
    {
        $trns_time_array = array();
         //11-02-2020 reverted back as it was slowing down the login process
        $query = "select trnst_time_id, co_loader_id, trnst_code, cur_status, route_id, mode_id from dtdc_d_trns_time where record_entry_datetime < NOW() and record_entry_datetime > ?";
        // updated- 17/01/2020
        // $query = "select trnst_time_id, co_loader_id, trnst_code, cur_status, route_id, mode_id from dtdc_d_trns_time where MOD_DATE_TIME < NOW() and MOD_DATE_TIME > ?";
        $result = $this->db->query($query,[$lastSyncDate]);
        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $trns_time_array[$i] = $result_array[$i];
        }
        return $trns_time_array;
    }

    public function get_all_route()
    {
        $route_array = array();
        $query = "SELECT route_id,orig_office_id,cur_status FROM dtdc_d_route";
        $result = $this->db->query($query);
        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $route_array[$i] = $result_array[$i];
        }
        return $route_array;
    }

    public function sync_dtdc_d_route($lastSyncDate)
    {
        $route_array = array();
         //11-02-2020 reverted back as it was slowing down the login process
        $query = "select route_id,orig_office_id,cur_status from dtdc_d_route where record_entry_datetime < NOW() and record_entry_datetime > ?";
        // updated- 17/01/2020
        // $query = "select route_id,orig_office_id,cur_status from dtdc_d_route where MOD_DATE_TIME < NOW() and MOD_DATE_TIME > ?";
        $result = $this->db->query($query,[$lastSyncDate]);
        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $route_array[$i] = $result_array[$i];
        }
        return $route_array;
    }

    public function get_all_otc_master()
    {
        $otc_array = array();
        $query = "SELECT otc_id, otc_code, private_otc_name FROM dtdc_d_otc_master";
        $result = $this->db->query($query);
        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $otc_array[$i] = $result_array[$i];
        }
        return $otc_array;
    }

    public function sync_dtdc_d_otc_master($lastSyncDate)
    {
        $otc_array = array();
         //11-02-2020 reverted back as it was slowing down the login process
         $query = "select otc_id, otc_code, private_otc_name from dtdc_d_otc_master where record_entry_datetime < NOW() and record_entry_datetime > ?";
        // updated- 17/01/2020
        // $query = "select otc_id, otc_code, private_otc_name from dtdc_d_otc_master where MOD_DATE_TIME < NOW() and record_entry_datetime > ?";
        $result = $this->db->query($query,[$lastSyncDate]);
        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $otc_array[$i] = $result_array[$i];
        }
        return $otc_array;
    }

    public function get_all_direct_connections()
    {
        $direct_connections_array = array();
        $query = "SELECT vendor_id,vendor_code, business_name,vendor_type,office_id FROM dtdc_d_vendor";
        $result = $this->db->query($query);
        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $direct_connections_array[$i] = $result_array[$i];
        }
        return $direct_connections_array;
    }

    public function sync_dtdc_d_vendor($lastSyncDate)
    {
        $direct_connections_array = array();
         //11-02-2020 reverted back as it was slowing down the login process
         $query = "select vendor_id,vendor_code, business_name,vendor_type,office_id from dtdc_d_vendor where record_entry_datetime < NOW() and record_entry_datetime > ?";
        // updated- 17/01/2020
        // $query = "select vendor_id,vendor_code, business_name,vendor_type,office_id from dtdc_d_vendor where MOD_DATE_TIME < NOW() and MOD_DATE_TIME > ?";
        $result = $this->db->query($query,[$lastSyncDate]);
        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $direct_connections_array[$i] = $result_array[$i];
        }
        return $direct_connections_array;
    }

    public function get_mysql_server_ip($branch_code)
    {
        // $mysql_server_ip_array = array();
        $query = "select AUTHORIZED_EMPCODE from cg_d_system_auth where branch_code= ?";
        $result = $this->db->query($query,[$branch_code]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();
            $mysql_server_ip = $result_array[0]['AUTHORIZED_EMPCODE'];
            if (!$mysql_server_ip) {
                $mysql_server_ip = 'null';
            }
        } else {
            $mysql_server_ip = 'null';
        }
        return $mysql_server_ip;
    }

    public function get_app_server_ip($branch_code)
    {
        $query = "select APP_SERVER_IP,nodal_enabled from cg_d_system_auth where branch_code= ?";
        $result = $this->db->query($query,[$branch_code]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();
            return $result_array;
            // $app_server_ip = $result_array[0]['APP_SERVER_IP'];
            // if (!$app_server_ip) {
            //     $app_server_ip = 'null';
            // }
        } 
        else {
            $$result_array[0]['APP_SERVER_IP'] = 'null';
            $$result_array[0]['nodal_enabled'] = 'null';
        }
        return $result_array;
    }


    public function get_ts_mapping($office_id)
    {

        $branch_num_code = $this->get_branch_num_code($office_id);
        if (strlen($branch_num_code) == 1) {
            $branch_num_code = "00" . $branch_num_code;
        }
        if (strlen($branch_num_code) == 2) {
            $branch_num_code = "0" . $branch_num_code;
        }

        $ts_mapping_array = array();
        if($branch_num_code != null){
            //RTM_ORG_OFF_ID, RTM_DEST_OFF_ID, RTM_TS1
            $query = "select rtm_org_off_id, rtm_dest_off_id, rtm_ts1, rtm_ts2, rtm_ts3,MOD_DATE_TIME from route_ts_mapping where rtm_org_off_id like '%".$this->db->escape_like_str($branch_num_code)."%'";
            $result = $this->db->query($query);
            if ($result->num_rows() > 0) {
                $result_array = $result->result_array();
                $ts_mapping_array = $result_array;
            }
        }
        return $ts_mapping_array;
    }

    public function get_branch_num_code($office_id)
    {

        $query = "select branch_num_code from dtdc_d_office where office_id = ?";
        $result = $this->db->query($query,[$office_id]);
        if ($result->num_rows() > 0) {
            $result_array = $result->result_array();
            $branch_num_code = $result_array[0]['branch_num_code'];

        } else {
            $branch_num_code = 'null';
        }
        return $branch_num_code;
    }

    public function get_status_code_master()
    {
        $sql = "SELECT * FROM dtdc_d_exception_reason_mas where ERM_STATUS = 'A';";
        $query = $this->db->query($sql);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return array();
        }

    }

    public function get_commodity_master(){
        $sql = " select commodity_id, commodity_name from dtdc_d_commodity where PARENT_COMM_CODE is null order by commodity_name";
        $query = $this->db->query($sql);
        return $query->result_array();
    }

    public function get_vas_master(){
        $sql = "select SERVICE_CODE, SERVICE_NAME from dtdc_d_service where service_type='VAS' AND MAIN_VAS_ID=1";
        $query = $this->db->query($sql);
        return $query->result_array();
    }

    public function get_service_mode_relation_master(){
        $sql = "select mode_id, service_id from dtdc_d_srv_mode_relation";
        $query = $this->db->query($sql);
        return $query->result_array();
    }

    //30-04-2020
    public function get_all_coloader_sec()
    {
        $coloader_array = array();
        $query = "SELECT loader_id,loader_code,loader_name FROM dtdc_d_coloader limit 2";
        $result = $this->db->query($query);
        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $coloader_array[$i] = $result_array[$i];
        }
        return $coloader_array;
    }

public function get_all_direct_connections_sec()
    {
        $direct_connections_array = array();
        $query = "SELECT vendor_id,vendor_code, business_name,vendor_type,office_id FROM dtdc_d_vendor limit 2";
        $result = $this->db->query($query);
        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $direct_connections_array[$i] = $result_array[$i];
        }
        return $direct_connections_array;
    }

public function get_all_otc_master_sec()
    {
        $otc_array = array();
        $query = "SELECT otc_id, otc_code, private_otc_name FROM dtdc_d_otc_master limit 2";
        $result = $this->db->query($query);
        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $otc_array[$i] = $result_array[$i];
        }
        return $otc_array;
    }

public function get_all_trns_time_sec()
    {
        $trns_time_array = array();
        $query = "SELECT trnst_time_id, co_loader_id, trnst_code, cur_status, route_id, mode_id FROM dtdc_d_trns_time limit 2";
        $result = $this->db->query($query);
        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $trns_time_array[$i] = $result_array[$i];
        }
        return $trns_time_array;
    }

public function get_all_route_sec()
    {
        $route_array = array();
        $query = "SELECT route_id,orig_office_id,cur_status FROM dtdc_d_route limit 2";
        $result = $this->db->query($query);
        for ($i = 0; $i < $result->num_rows(); $i++) {
            $result_array = $result->result_array();
            $route_array[$i] = $result_array[$i];
        }
        return $route_array;
    }

}