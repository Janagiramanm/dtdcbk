<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class MasterConDispatchServiceType_model extends CI_Model

{

  public $server_date;
  public $server_time;
  public $server_date_time;


  function __construct()
  {
    # code...
    parent::__construct();
    $dateObj = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
    $this->server_date = $dateObj->format('Y-m-d');
    $this->server_time = $dateObj->format('H:i');
    $this->server_date_time = $dateObj->format('Y-m-d H:i:s');
  }

  public function service_type($input){
    $officeId = isset($input['officeId']) ? $input['officeId'] : $this->error_response('not set officeId');
    $modeId = isset($input['mode']) ? $input['mode'] : $this->error_response('not set mode');
    $serviceBy = isset($input['serviceBy']) ? $input['serviceBy'] : $this->error_response('not set serviceBy');
    $reportRegoffId = isset($input['reportRegoffId']) ? $input['reportRegoffId'] : $this->error_response('not set reportRegoffId');
    $master_details = new Master_details_model();

    switch ($serviceBy) {
      case 'coloader':
        $response['coloader'] = $master_details->get_service_type_co_loader($officeId,$modeId);
        break;
      case 'otc':
        $response['otc'] = $master_details->get_service_type_otc($officeId);
        break;
      case 'direct connection':
        $response['direct_connection'] = $master_details->get_service_type_direct_connection($officeId,$reportRegoffId);
        break;
      default:
        # code...
        break;
    }

    return $response;
  }

    public function error_response($e){
      $response = array('status'=>0,'message'=>$e);
      echo json_encode($response);
      exit;
    }
}
