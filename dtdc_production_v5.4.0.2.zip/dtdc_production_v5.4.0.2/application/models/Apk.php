<?php
/**
 * Created by PhpStorm.
 * User: amal
 * Date: 19/5/18
 * Time: 11:57 AM
 */

class Apk extends CI_Model
{

    public function getApkDetails($apk_date, $apk_version, $office_id)
    {
        $sql = "select apk_ver from dtdc_d_war_details where (apk_date  > date(?) ) and office_id =?";
        $query = $this->db->query($sql, [$apk_date,$office_id]);
        return $query->result_array();
    }


	/**
	 *
	 */
    public function isApkDateAndVersionMore($apk_date, $apk_version, $office_id){
    	$sql = "select war_detail_id, office_id, apk_date, apk_ver from dtdc_d_war_details where ((apk_date is null or apk_date < date(?)) or ((apk_ver !=  ? and apk_date = date(?)) or apk_ver is null)) and office_id = ?";
    	$query = $this->db->query($sql,[$apk_date, $apk_version,$apk_date,$office_id]);
    	return ($query->num_rows() > 0) ? true : false;
    }

	/**
	 * Update the APK version
	 */
    public function updateApkVersion($apk_date, $apk_version, $office_id){
		$sql = "update dtdc_d_war_details set apk_date = ?, apk_ver = ? where office_id = ?";
		$query = $this->db->query($sql,[$apk_date,$apk_version,$office_id]);
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
    }

    public function isApkDateAndVersionLess($apk_date, $office_id){
		$sql = "select war_detail_id from dtdc_d_war_details where apk_date > date(?) and office_id = ?";
		$query = $this->db->query($sql,[$apk_date,$office_id]);
	    return ($query->num_rows() > 0) ? true : false;
    }

    public function isSessionActive($login_out_id){
    	$sql = "select LOG_IN_OUT_ID from cg_f_log_in_out_detl where LOG_IN_OUT_ID = ? and LOGOUT_DATE is null and LOGOUT_TIME is null";
	    $query = $this->db->query($sql,[$login_out_id]);
	    return ($query->num_rows() > 0) ? 1 : 0;
	}
	
	public function insertApkVersion($apk_date, $apk_version, $office_id){
		$sql ="insert into dtdc_ctbs_plus.dtdc_d_war_details(office_id,last_modified_date,RECORD_ENTRY_DATETIME,MOD_DATE_TIME,APK_DATE,APK_VER)
				values( ? , curdate() , CURRENT_TIMESTAMP() , CURRENT_TIMESTAMP() , ? , ? )";
		$query = $this->db->query($sql,[$office_id, $apk_date, $apk_version ]);
		if($query){
			return true;
		}
		return false;
	}

	

}